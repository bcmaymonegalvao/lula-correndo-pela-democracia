/* Tela Sobre/Créditos — UI isolada, sem alterar eventos de jogo. */
(() => {
 'use strict';
 const dialog=document.getElementById('aboutOverlay');
 const close=document.getElementById('aboutClose');
 const dismiss=document.getElementById('aboutDismiss');
 const card=dialog?.querySelector('.about-card');
 if(!dialog || !close || !dismiss || !card)return;
 let restoreFocus=null;
 const isOpen=()=>!dialog.classList.contains('hidden');
 function open(e){
  if(isOpen())return;
  restoreFocus=(e?.currentTarget instanceof HTMLElement)?e.currentTarget:document.activeElement;
  dialog.classList.remove('hidden');
  close.focus();
 }
 function hide(){
  if(!isOpen())return;
  dialog.classList.add('hidden');
  if(restoreFocus?.isConnected && !restoreFocus.closest('.hidden'))restoreFocus.focus();
  restoreFocus=null;
 }
 ['aboutFromStart','aboutFromPause'].forEach(id=>{
  document.getElementById(id)?.addEventListener('click',open);
 });
 close.addEventListener('click',hide);
 dismiss.addEventListener('click',hide);
 dialog.addEventListener('click',e=>{if(e.target===dialog)hide();});
 document.addEventListener('keydown',e=>{
  if(!isOpen())return;
  if(e.key==='Escape'){e.preventDefault();e.stopPropagation();hide();return;}
  if(e.key!=='Tab')return;
  const focusable=[...dialog.querySelectorAll('button:not(:disabled),a[href]')].filter(el=>el.getClientRects().length);
  if(!focusable.length){e.preventDefault();card.focus();return;}
  const first=focusable[0],last=focusable[focusable.length-1];
  if(e.shiftKey && document.activeElement===first){e.preventDefault();last.focus();}
  else if(!e.shiftKey && document.activeElement===last){e.preventDefault();first.focus();}
 });
})();
