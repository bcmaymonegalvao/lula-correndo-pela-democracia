/* Lula – Correndo pela Democracia · combate por fôlego (base Alpha 0.9.4)
 * Quatro movimentos por toque: soco 1 → soco 2 → chute esquerdo → soco 4 → soco 1.
 * Em vez da antiga trava de três golpes + 0,5s, o fôlego limita rajadas
 * e recupera durante pequenas pausas. Um comando pode ficar em buffer;
 * manter a tecla pressionada não dispara golpes automaticamente.
 */
window.GameCombat = (() => {
 const MOVES = Object.freeze([
  {
   name:'SOCO PRIMEIRA MÃO',clip:'left_punch',impact:'estrela_povo_1',flashColor:'#ff724d',duration:.48,damage:1,
   boxes:[{x:22,y:-94,w:50,h:42},{x:28,y:-97,w:62,h:48},
          {x:27,y:-95,w:66,h:49},{x:19,y:-92,w:49,h:44}]
  },
  {
   name:'SOCO OUTRA MÃO',clip:'front_punch',impact:'estrela_povo_2',flashColor:'#ff724d',duration:.49,damage:1,
   boxes:[{x:24,y:-97,w:56,h:46},{x:31,y:-97,w:74,h:48},
          {x:29,y:-96,w:78,h:50},{x:24,y:-92,w:58,h:49}]
  },
  {
   name:'CHUTE ESQUERDO',clip:'flying_kick',impact:'estrela_povo_3',flashColor:'#ff724d',duration:.59,damage:1,
   boxes:[{x:21,y:-104,w:63,h:75},{x:28,y:-112,w:81,h:87},
          {x:30,y:-120,w:90,h:100},{x:25,y:-108,w:72,h:85}]
  },
  {
   name:'SOCO DE RETORNO',clip:'left_punch',impact:'estrela_povo_4',flashColor:'#ff572f',duration:.51,damage:1,
   boxes:[{x:22,y:-94,w:50,h:42},{x:28,y:-97,w:62,h:48},
          {x:27,y:-95,w:66,h:49},{x:19,y:-92,w:49,h:44}]
  }
 ]);
 const COMBO_WINDOW=1.05;
 const MAX_STAMINA=100;
 const ATTACK_COST=18;
 const STAMINA_REGEN=65; // pontos por segundo após uma pausa real
 const REGEN_DELAY=.40; // não recupera energia entre toques muito rápidos
 const STAMINA_REFILL=95; // recarga mínima após fadiga
 const COOLDOWN_SECONDS=.25; // curto; nunca mais 0,5s após o 3º ataque
 const RECOVERY_GUARD=.34; // proteção curta contra contato / projéteis
 const INPUT_DEBOUNCE=.095;
 function create(){
  const state={step:0,left:0,queue:0,nextStep:1,serial:0,hitTargets:new Set(),
   chainCount:0,cooldown:0,debounce:0,idle:0,stamina:MAX_STAMINA,recoveryGuard:0};
  function reset(){Object.assign(state,{step:0,left:0,queue:0,nextStep:1,serial:0,
   hitTargets:new Set(),chainCount:0,cooldown:0,debounce:0,idle:0,
   stamina:MAX_STAMINA,recoveryGuard:0});}
  function startRecovery(){
   if(state.cooldown>0)return;
   state.step=0;state.left=0;state.queue=0;
   state.cooldown=COOLDOWN_SECONDS;
   state.recoveryGuard=RECOVERY_GUARD;
   state.chainCount=0;state.nextStep=1;state.idle=0;
  }
  function begin(step){
   if(!Number.isInteger(step)||step<1||step>MOVES.length||state.step||state.cooldown>0)return false;
   if(state.stamina<ATTACK_COST){startRecovery();return false;}
   state.stamina=Math.max(0,state.stamina-ATTACK_COST);
   state.step=step;state.left=MOVES[step-1].duration;
   state.chainCount++;state.idle=0;state.hitTargets=new Set();state.serial++;
   return true;
  }
  function press(key='combo'){
   if(key!=='combo'||state.cooldown>0||state.debounce>0)return false;
   if(state.step){
    if(state.queue)return false; // somente 1 golpe adiantado; evita macro por mashing
    state.queue=1;state.debounce=INPUT_DEBOUNCE;return true;
   }
   const succeeded=begin(state.nextStep);
   if(succeeded)state.debounce=INPUT_DEBOUNCE;
   return succeeded;
  }
  function update(dt){
   if(dt<=0)return;
   state.debounce=Math.max(0,state.debounce-dt);
   state.recoveryGuard=Math.max(0,state.recoveryGuard-dt);
   if(state.cooldown>0){
    state.cooldown=Math.max(0,state.cooldown-dt);
    if(state.cooldown===0){
     state.stamina=Math.max(state.stamina,STAMINA_REFILL);
     state.chainCount=0;state.nextStep=1;state.queue=0;state.idle=0;
    }
   }
   if(state.step){
    state.left-=dt;
    if(state.left<=0){
     const completed=state.step;state.step=0;state.left=0;
     // Os quatro movimentos visuais retornam ao soco 1.
     state.nextStep=completed%MOVES.length+1;
     if(state.stamina<ATTACK_COST){startRecovery();}
     else if(state.queue>0){state.queue=0;begin(state.nextStep);}
     else state.idle=0;
    }
   }else if(state.cooldown===0){
    state.idle+=dt;
    if(state.idle>=REGEN_DELAY)state.stamina=Math.min(MAX_STAMINA,state.stamina+STAMINA_REGEN*dt);
    if(state.chainCount>0&&state.idle>=COMBO_WINDOW){
     state.chainCount=0;state.nextStep=1;state.queue=0;
     // Mantém o relógio de repouso para seguir regenerando fôlego.
    }
   }
  }
  function move(){return state.step?MOVES[state.step-1]:null;}
  function frame(){const m=move();if(!m)return 0;
   const p=Math.max(0,Math.min(.999999,1-state.left/m.duration));return Math.floor(p*4);
  }
  function visualFrame(){const m=move();if(!m)return 0;
   const p=Math.max(0,Math.min(.999999,1-state.left/m.duration));return Math.floor(p*8);
  }
  function hitbox(world,feet){const m=move();if(!m)return null;
   const box=m.boxes[frame()];if(!box)return null;
   return {x:world+box.x,y:feet+box.y,w:box.w,h:box.h};
  }
  function isRecoveryProtected(){return state.recoveryGuard>0;}
  return {state,reset,begin,press,update,move,frame,visualFrame,hitbox,isRecoveryProtected};
 }
 return {MOVES,COMBO_WINDOW,MAX_STAMINA,ATTACK_COST,STAMINA_REGEN,STAMINA_REFILL,
  COOLDOWN_SECONDS,RECOVERY_GUARD,INPUT_DEBOUNCE,REGEN_DELAY,create};
})();
