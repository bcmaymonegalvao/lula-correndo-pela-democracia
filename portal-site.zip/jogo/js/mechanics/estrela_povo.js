/* ESTRELA DO POVO — KOF | Quatro contatos de quatro quadros.
 * O motor principal valida a colisão e cria eventos; este módulo só renderiza.
 * Sem RAF, sem efeitos simulados, sem dano e sem cenários adicionais. */
window.GameEstrelaPovo=(()=>{
 'use strict';
 const DURATIONS=Object.freeze([.25,.255,.307,.265]);
 const SIZE=Object.freeze([92,94,104,100]);
 function spawn(step,x,y,serial,targetId){
  if(!Number.isInteger(step)||step<1||step>4)return null;
  return {step,x,y,serial,targetId,age:0,duration:DURATIONS[step-1]};
 }
 function frameOf(event){
  const p=Math.min(.999999,Math.max(0,event.age/event.duration));
  return Math.floor(p*4);
 }
 function draw(ctx,frames,event,x,y){
  if(!ctx||!Array.isArray(frames)||event.age>=event.duration)return false;
  const frame=frameOf(event),img=frames[frame];
  if(!img||!(img.naturalWidth||img.width))return false;
  const size=SIZE[event.step-1],px=Math.round(x-size/2),py=Math.round(y-size/2);
  ctx.save();ctx.imageSmoothingEnabled=false;
  ctx.globalCompositeOperation='source-over';ctx.globalAlpha=.96;
  ctx.shadowColor='rgba(255,65,40,.62)';ctx.shadowBlur=7;
  ctx.drawImage(img,px,py,size,size);
  ctx.shadowBlur=0;ctx.globalCompositeOperation='screen';ctx.globalAlpha=.24;
  ctx.drawImage(img,px,py,size,size);
  ctx.restore();return true;
 }
 return Object.freeze({DURATIONS,SIZE,spawn,frameOf,draw});
})();
