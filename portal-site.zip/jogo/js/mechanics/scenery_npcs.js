/* NPCs decorativos de calçada — módulo de desenvolvimento paralelo.
 * Base para integração: Lula – Correndo pela Democracia, Alpha 0.9.4.
 * Não usa state.enemies, colisões, HP, pontos, timers globais ou RAF próprio.
 */
window.GameSceneryNpcs = (() => {
  'use strict';
  const CELL = 192;
  const BUILD = 'RGBA_V5_20261024';
  const debug = typeof location !== 'undefined' && new URLSearchParams(location.search).has('npcdebug');
  const FEET_X = 96;
  const FEET_Y = 176;
  const IDS = Object.freeze([
    'eleitores_l', 'trompetista', 'vira_voto', 'amor_contra_odio',
    'artista_pop', 'artista_tropical', 'artista_cancioneiro'
  ]);
  const DEFINITIONS = Object.freeze({
    eleitores_l: Object.freeze({ fps: 6, scale: .83, feetShiftY: 0 }),
    trompetista: Object.freeze({ fps: 7, scale: .78, feetShiftY: -6 }),
    vira_voto: Object.freeze({ fps: 5, scale: .80, feetShiftY: 8 }),
    amor_contra_odio: Object.freeze({ fps: 5, scale: .80, feetShiftY: 10 }),
    artista_pop: Object.freeze({ fps: 6, scale: .78, feetShiftY: -7 }),
    artista_tropical: Object.freeze({ fps: 6, scale: .78, feetShiftY: -6 }),
    artista_cancioneiro: Object.freeze({ fps: 5, scale: .80, feetShiftY: -2 })
  });

  function create({ spritePaths = {}, cameraSpeedFactor = 1.15,
    enabled = true, onAssetError } = {}) {
    const framesById = Object.fromEntries(IDS.map(id => [id, [null, null, null, null]]));
    let entries = [];
    let nextPosition = 0;
    let typeCursor = 0;
    let animationTime = 0;
    let previousWorld = 0;
    let active = Boolean(enabled);
    let disposed = false;
    let rng = 0x6a09e667;

    function random() {
      rng ^= rng << 13;
      rng ^= rng >>> 17;
      rng ^= rng << 5;
      return (rng >>> 0) / 4294967296;
    }
    function issue(id, url, reason) {
      if (typeof onAssetError === 'function') onAssetError(id, url, reason);
    }
    function loadImages() {
      if (typeof Image !== 'function') return;
      for (const id of IDS) {
        const urls = Array.isArray(spritePaths[id]) ? spritePaths[id] : [];
        for (let n = 0; n < 4; n++) {
          const url = urls[n];
          if (!url) { issue(id, '', `Frame ${n + 1} não configurado`); continue; }
          const img = new Image();
          img.onload = () => {
            if (disposed) return;
            if (img.naturalWidth !== CELL || img.naturalHeight !== CELL) {
              issue(id, url, 'Dimensões inválidas: esperado 192×192');
              return;
            }
            // Validate the ACTUAL top-left pixel, not an averaged downsample of
            // the entire sprite. Use the validated, uniquely named PNG RGBA files.
            try {
              const probe = document.createElement('canvas');
              probe.width = probe.height = 1;
              const probeCtx = probe.getContext('2d', {willReadFrequently: true});
              probeCtx.drawImage(img, 0, 0, 1, 1, 0, 0, 1, 1);
              if (probeCtx.getImageData(0, 0, 1, 1).data[3] !== 0) {
                issue(id, url, 'Fundo opaco no canto: PNG RGBA inválido');
                return;
              }
            } catch (error) {
              issue(id, url, 'Falha na verificação de transparência: ' + error.message);
              return;
            }
            framesById[id][n] = img;
            if (debug) console.info('[NPC RGBA V5] carregado', id, n + 1, new URL(url, document.baseURI).href);
          };
          img.onerror = () => { if (!disposed) issue(id, url, 'Erro ao carregar imagem'); };
          img.src = url + (url.includes('?') ? '&' : '?') + 'rev=rgba-v5-final';
        }
      }
    }
    function add(id, position) {
      entries.push({ id, position, phase: random() * .13 });
    }
    function reset(world = 0) {
      rng = 0x6a09e667;
      animationTime = 0;
      previousWorld = Number.isFinite(world) ? world : 0;
      const scroll = previousWorld * cameraSpeedFactor;
      const playerX = 190;
      entries = [];
      typeCursor = 0;
      add(IDS[typeCursor++], scroll + 450 - playerX);
      add(IDS[typeCursor++], scroll + 835 - playerX);
      nextPosition = scroll + 1240 - playerX;
    }
    function update(dt, world) {
      if (disposed || !active || !Number.isFinite(dt) || dt <= 0 || !Number.isFinite(world)) return;
      previousWorld = world;
      animationTime += dt;
      const scroll = world * cameraSpeedFactor;
      // Os NPCs seguem exatamente a velocidade relativa da textura da rua.
      entries = entries.filter(npc => npc.position - scroll + 190 > -210);
      const nearRightEdge = scroll + 960 + 180 - 190;
      while (nextPosition <= nearRightEdge && entries.length < 8) {
        add(IDS[typeCursor % IDS.length], nextPosition);
        typeCursor++;
        nextPosition += 365 + random() * 105;
      }
    }
    function render(ctx, { world = previousWorld, floorY = 423, screenWidth = 960,
      playerScreenX = 190, sidewalkOffsetY = -78, period = 'day' } = {}) {
      if (disposed || !active || !ctx || !Number.isFinite(world)) return;
      const baseY = floorY + sidewalkOffsetY;
      const scroll = world * cameraSpeedFactor;
      ctx.save();
      ctx.imageSmoothingEnabled = false;
      ctx.globalCompositeOperation = 'source-over';
      if (period === 'night') ctx.globalAlpha *= .82;
      else if (period === 'sunset') ctx.globalAlpha *= .93;
      for (const npc of entries) {
        const x = npc.position - scroll + playerScreenX;
        if (x < -220 || x > screenWidth + 220) continue;
        const cfg = DEFINITIONS[npc.id];
        const frames = framesById[npc.id];
        const frame = Math.floor((animationTime + npc.phase) * cfg.fps) % 4;
        const pic = frames[frame] || frames.find(Boolean);
        if (!pic) continue; // Recursos de cenário jamais bloqueiam o jogo.
        const s = cfg.scale;
        const dimension = Math.round(CELL * s);
        const footShiftY = (cfg.feetShiftY || 0) * s;
        ctx.drawImage(pic, Math.round(x - FEET_X * s),
          Math.round(baseY - FEET_Y * s + footShiftY), dimension, dimension);
      }
      ctx.restore();
    }
    function setEnabled(value) { active = Boolean(value); }
    function debugState() {
      return {
        spriteBuild: BUILD, active, disposed, animationTime, world: previousWorld,
        loaded: Object.fromEntries(IDS.map(id => [id, framesById[id].filter(Boolean).length])),
        entries: entries.map(({ id, position, phase }) => ({ id, position, phase }))
      };
    }
    function dispose() {
      disposed = true;
      entries = [];
      for (const id of IDS) framesById[id].fill(null);
    }
    loadImages();
    reset(0);
    return Object.freeze({ reset, update, render, setEnabled, debugState, dispose });
  }
  return Object.freeze({ create, definitions: DEFINITIONS, ids: IDS });
})();
