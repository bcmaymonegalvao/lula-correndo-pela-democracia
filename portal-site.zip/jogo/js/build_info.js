/* Identificacao publica e versao. Atualize este unico modulo a cada patch. */
(() => {
  'use strict';
  const build = Object.freeze({
    title: 'Lula – Correndo pela Democracia',
    version: 'Alpha 0.9.5',
    patch: 'QA4',
    label: 'Alpha 0.9.5 · Patch QA4',
    author: 'Bruno Galvão',
    credits: 'Desenvolvido por Bruno Galvão',
    copyright: '© 2026 Bruno Galvão · Todos os direitos reservados',
    github: '@bcmaymonegalvao',
    githubUrl: 'https://github.com/bcmaymonegalvao',
    license: 'Uso gratuito para jogar · Software proprietário',
  });
  window.GameBuildInfo = build;
  const values = Object.freeze({
    version: build.label, author: build.author, credits: build.credits,
    copyright: build.copyright, github: build.github, license: build.license,
  });
  function showBuildInfo() {
    document.querySelectorAll('[data-game-build]').forEach(node => {
      const value = values[node.getAttribute('data-game-build')];
      if (value) node.textContent = value;
    });
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', showBuildInfo, {once:true});
  } else {
    showBuildInfo();
  }
})();
