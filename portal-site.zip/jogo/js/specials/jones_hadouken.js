/* Hadouken de Livros de História (Jones Manoel)
 * Independently rendered cinematic, updated by the existing game requestAnimationFrame.
 * Assets: supplied 256x256 grid sprites and vertical portrait. No fake combat sprites.
 */
window.JonesHadouken = (() => {
 'use strict';
 const CELL = 256, HITS = 13, INTERVAL = .143, FLASH_TIME = .075;
 const PHASE = Object.freeze({FREEZE:'FREEZE', CUT_IN:'CUT_IN', ENTRADA:'ENTRADA', CARREGAMENTO:'CARREGAMENTO', DISPARO:'DISPARO', IMPACTOS:'IMPACTOS', FINALIZACAO:'FINALIZAÇÃO', RESTAURACAO:'RESTAURAÇÃO', IDLE:'IDLE'});
 const PATHS = Object.freeze({
  portrait:'assets/specials/jones/portrait.png', hero:'assets/specials/jones/hero.png',
  books:'assets/specials/jones/books.png', impact:'assets/specials/jones/tmp_fx_10.png',
  blast:'assets/specials/jones/tmp_fx_11.png', shock:'assets/specials/jones/tmp_fx_12.png'
 });
 const clamp=(x,a,b)=>Math.min(b,Math.max(a,x));
 const smooth=x=>{x=clamp(x,0,1);return x*x*(3-2*x);};
 function create(options={}){
  const images={}, errors=[];
  let preloading=null, ready=false, active=false, phase=PHASE.IDLE, elapsed=0, phaseAge=0;
  let hits=0, damageEvents=0, projectileX=0, projectileY=0, contactX=0, contactY=0, flashAge=99, bossSnapshot=null, bodyTop=226, shotFrame=0, contactLocked=false;
  const WIND_START=0, CUT_IN_START=.04, CUT_IN_END=1.18, ENTER_END=1.60, CHARGE_END=2.18, SPEED=560;
  const portraitX=-340;
  const hitLog=[];let lastResult=null;
  const errorLog=msg=>{errors.push(msg);console.warn('[Jones Hadouken] '+msg);};
  const read=source=>new Promise(resolve=>{
   const im=new Image();let done=false;
   const settle=(success)=>{if(done)return;done=true;clearTimeout(timer);resolve(success?im:null);};
   const timer=setTimeout(()=>{errorLog('Timeout: '+source);settle(false);},12000);
   im.onload=()=>settle(im.naturalWidth>0);
   im.onerror=()=>{errorLog('Imagem indisponível: '+source);settle(false);};
   im.src=new URL(source,document.baseURI).href;
  });
  function preload(){
   if(preloading)return preloading;
   preloading=Promise.all(Object.entries({...PATHS,...(options.assetPaths||{})}).map(async ([k,path])=>{images[k]=await read(path);}))
    .then(()=>{ready=!!(images.hero&&images.books&&images.portrait);if(!ready)errorLog('Sprites essenciais não carregados: especial Jones desabilitado, partida preservada.');return ready;})
    .catch(e=>{errorLog('Falha inesperada no preload: '+e.message);return false;});
   return preloading;
  }
  function reset(){active=false;phase=PHASE.IDLE;elapsed=0;phaseAge=0;hits=0;damageEvents=0;contactLocked=false;flashAge=99;hitLog.length=0;}
  function cancel(){reset();lastResult=null;return true;}
  function transition(next){phase=next;phaseAge=0;}
  function start(){
   if(active||!ready)return false;
   const b=options.getBoss?.(); const bounds=options.getBossBounds?.();
   if(!b||b.dead||!bounds||bounds.w<=0||bounds.h<=0)return false;
   reset();lastResult=null;active=true;transition(PHASE.FREEZE);
   bossSnapshot={...bounds};
   bodyTop=220; // 203px sprite remains grounded over Lula (base at y=423).
   projectileY=clamp(bounds.y+bounds.h*.76,bounds.y+55,bounds.y+bounds.h-40);
   projectileX=310;contactX=bounds.x+Math.min(78,bounds.w*.18);
   contactY=projectileY;shotFrame=0;
   return true;
  }
  function hit(){
   if(hits>=HITS)return;
   hits++;damageEvents++;flashAge=0;
   hitLog.push({hit:hits,at:elapsed,x:contactX,y:contactY});
   options.onHit?.(hits);
  }
  function update(dt){
   if(!active||dt<=0)return;
   dt=Math.min(dt,.05);elapsed+=dt;phaseAge+=dt;
   if(phase===PHASE.FREEZE && elapsed>=CUT_IN_START)transition(PHASE.CUT_IN);
   if(phase===PHASE.CUT_IN && elapsed>=CUT_IN_END)transition(PHASE.ENTRADA);
   if(phase===PHASE.ENTRADA && elapsed>=ENTER_END)transition(PHASE.CARREGAMENTO);
   if(phase===PHASE.CARREGAMENTO && elapsed>=CHARGE_END)transition(PHASE.DISPARO);
   if(phase===PHASE.DISPARO){
    // Horizontal projectile and rectangle collision against the boss's *frozen* visual bounds.
    projectileX+=SPEED*dt;
    shotFrame=(shotFrame+dt*9)%7;
    const radius=60;
    if(projectileX+radius>=contactX && projectileY>=bossSnapshot.y && projectileY<=bossSnapshot.y+bossSnapshot.h){
     projectileX=contactX-radius;contactLocked=true;transition(PHASE.IMPACTOS);
     hit();
    }
   }
   if(phase===PHASE.IMPACTOS){
    flashAge+=dt;
    while(hits<HITS&&phaseAge+1e-7>=hits*INTERVAL)hit();
    if(hits>=HITS&&phaseAge>=HITS*INTERVAL)transition(PHASE.FINALIZACAO);
   }
   if(phase===PHASE.FINALIZACAO&&phaseAge>=.52)transition(PHASE.RESTAURACAO);
   if(phase===PHASE.RESTAURACAO&&phaseAge>=.12){
    const summary={hits,damageEvents,duration:elapsed,hitLog:hitLog.slice()};lastResult=summary;reset();options.onComplete?.(summary);
   }
  }
  function drawFrame(ctx,img,k,cx,cy,size){
   if(!img)return;
   const max=Math.floor(img.width/CELL)-1;
   if(max<0)return;
   k=clamp(Math.floor(k),0,max);
   ctx.drawImage(img,k*CELL,0,CELL,CELL,Math.round(cx-size/2),Math.round(cy-size/2),size,size);
  }
  function wind(ctx){
   if(elapsed<=WIND_START)return;
   const power=clamp(elapsed/.26,0,1);
   ctx.save();ctx.beginPath();ctx.rect(0,0,960,420);ctx.clip();
   for(let i=0;i<26;i++){
    const y=(i*43+19)%420,x=960-((elapsed*660*(1+(i%3)*.15)+i*131)%1200);
    ctx.lineWidth=i%5===0?4:2;ctx.strokeStyle=`rgba(113,226,255,${(.07+(i%5)*.025)*power})`;
    ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+50+(i%5)*35,y-3);ctx.stroke();
   }
   ctx.restore();
  }
  function drawPortrait(ctx){
   if(elapsed>CUT_IN_END||!images.portrait)return;
   const enter=smooth(elapsed/.24), leave=smooth((elapsed-.82)/(.36));
   const w=322,h=430,x=Math.round(portraitX+(w+358)*enter-(w+358)*leave);
   ctx.save();ctx.shadowBlur=18;ctx.shadowColor='#6fe7ff';ctx.fillStyle='#04162c';ctx.fillRect(x-6,40,w+12,h+12);ctx.shadowBlur=0;
   ctx.drawImage(images.portrait,x,44,w,h);ctx.lineWidth=3;ctx.strokeStyle='#8eefff';ctx.strokeRect(x-3,41,w+6,h+6);ctx.restore();
  }
  function drawJones(ctx){
   if(elapsed<CUT_IN_END||phase===PHASE.RESTAURACAO)return;
   const prog=smooth((elapsed-CUT_IN_END)/(.42)),cx=98+203/2-(1-prog)*230;
   const frame=elapsed<1.6?0:elapsed<1.77?1:elapsed<1.93?2:elapsed<2.09?3:elapsed<2.38?4:phase===PHASE.IMPACTOS?6:elapsed<2.76?5:7;
   ctx.save();ctx.imageSmoothingEnabled=false;
   if(elapsed<1.6){for(let n=3;n>0;n--){ctx.globalAlpha=.1*n;drawFrame(ctx,images.hero,0,cx-n*27,bodyTop+101+n*2,203);}}
   ctx.globalAlpha=1;drawFrame(ctx,images.hero,frame,cx,bodyTop+101,203);
   if(phase===PHASE.CARREGAMENTO){
    const p=clamp(phaseAge/.6,0,1),a=.14+.18*Math.sin(elapsed*27)**2;
    const g=ctx.createRadialGradient(cx+77,bodyTop+95,5,cx+77,bodyTop+95,44+p*27);
    g.addColorStop(0,'#ffffff');g.addColorStop(.18,'#b0faff');g.addColorStop(1,'rgba(50,100,255,0)');
    ctx.globalAlpha=a;ctx.globalCompositeOperation='screen';ctx.fillStyle=g;ctx.fillRect(cx-18,bodyTop+5,186,180);
   }
   ctx.restore();
  }
  function drawProjectile(ctx){
   if(!images.books||!contactLocked&&phase!==PHASE.DISPARO)return;
   if(phase!==PHASE.DISPARO&&phase!==PHASE.IMPACTOS&&phase!==PHASE.FINALIZACAO)return;
   const index=phase===PHASE.DISPARO?Math.min(6,1+Math.floor(shotFrame)):6;
   const size=204;
   ctx.save();ctx.imageSmoothingEnabled=false;
   if(phase===PHASE.DISPARO){
    for(let n=4;n>=1;n--){ctx.globalAlpha=.08+n*.04;drawFrame(ctx,images.books,index,projectileX-n*32,projectileY,204);}
   }
   ctx.globalAlpha=phase===PHASE.FINALIZACAO?Math.max(0,1-phaseAge/.52):1;
   drawFrame(ctx,images.books,index,projectileX,projectileY,size);ctx.restore();
  }
  function bossFlash(ctx){
   if(phase!==PHASE.IMPACTOS||flashAge>=FLASH_TIME)return;
   const b=options.getBoss?.(), im=options.getBossSprite?.();if(!b||!im)return;
   const bounds=bossSnapshot;
   ctx.save();ctx.imageSmoothingEnabled=false;
   ctx.globalAlpha=.90*(1-flashAge/FLASH_TIME*.12);
   ctx.filter=hits%2?'brightness(0) invert(1)':'brightness(0) saturate(100%) invert(85%) sepia(29%) saturate(547%) hue-rotate(158deg)';
   const shake=Math.sin(flashAge*108)*6;
   ctx.drawImage(im,bounds.x+shake,bounds.y,bounds.w,bounds.h);
   ctx.restore();
  }
  function impacts(ctx){
   if(phase!==PHASE.IMPACTOS&&phase!==PHASE.FINALIZACAO)return;
   const x=contactX,y=contactY;
   if(phase===PHASE.IMPACTOS&&flashAge<FLASH_TIME){
    const q=1-flashAge/FLASH_TIME;
    ctx.save();ctx.globalCompositeOperation='screen';ctx.globalAlpha=.65*q;
    if(images.impact)ctx.drawImage(images.impact,x-90,y-89,180,178);
    if(images.blast)ctx.drawImage(images.blast,x-110,y-110,220,220);
    ctx.restore();
    ctx.save();ctx.globalAlpha=.14*q;ctx.fillStyle='#eafaff';ctx.fillRect(0,0,960,540);ctx.restore();
    ctx.save();ctx.textAlign='center';ctx.font='900 21px ui-monospace,monospace';ctx.lineWidth=5;ctx.strokeStyle='#051b33';ctx.strokeText(`HIT ${String(hits).padStart(2,'0')}`,x+24,y-84);ctx.fillStyle='#ffeb97';ctx.fillText(`HIT ${String(hits).padStart(2,'0')}`,x+24,y-84);ctx.restore();
   }
   if(phase===PHASE.FINALIZACAO){
    const q=clamp(phaseAge/.52,0,1);
    ctx.save();ctx.globalCompositeOperation='screen';ctx.globalAlpha=1-q;
    if(images.blast)ctx.drawImage(images.blast,x-(105+q*90),y-(105+q*90),210+q*180,210+q*180);
    if(images.shock)ctx.drawImage(images.shock,x-140-q*120,y-140-q*120,280+q*240,280+q*240);
    ctx.restore();
    ctx.save();ctx.globalAlpha=(1-q)*.88;ctx.strokeStyle='#9ce9ff';ctx.lineWidth=6*(1-q)+1;
    ctx.beginPath();ctx.ellipse(x,y,24+q*160,20+q*138,0,0,2*Math.PI);ctx.stroke();ctx.restore();
   }
  }
  function render(ctx){
   if(!active)return;
   ctx.save();ctx.fillStyle='rgba(4,12,30,0.46)';ctx.fillRect(0,0,960,540);
   wind(ctx);bossFlash(ctx);drawPortrait(ctx);drawJones(ctx);drawProjectile(ctx);impacts(ctx);
   if(elapsed>=CUT_IN_END){
    ctx.save();ctx.textAlign='center';ctx.font='900 25px system-ui';ctx.lineWidth=5;ctx.strokeStyle='#07182b';ctx.strokeText("MAROMBA'S COMUNIST",480,54);ctx.fillStyle='#ffe999';ctx.fillText("MAROMBA'S COMUNIST",480,54);
    if(hits){ctx.font='900 22px ui-monospace,monospace';const str=`${String(hits).padStart(2,'0')} / 13 HITS`;ctx.strokeText(str,480,90);ctx.fillStyle='#8ee9ff';ctx.fillText(str,480,90);}
    ctx.restore();
   }
   ctx.restore();
  }
  function getState(){return {active,ready,phase,elapsed,hits,damageEvents,projectileX,projectileY,contactX,contactY,flashAge,bossBounds:bossSnapshot?{...bossSnapshot}:null,hitLog:hitLog.slice(),loadingErrors:errors.slice(),lastResult:lastResult?{...lastResult,hitLog:lastResult.hitLog.slice()}:null};}
  return Object.freeze({preload,start,update,render,cancel,isActive:()=>active,isReady:()=>ready,getState});
 }
 return Object.freeze({create,PHASE,HITS,INTERVAL,PATHS});
})();
