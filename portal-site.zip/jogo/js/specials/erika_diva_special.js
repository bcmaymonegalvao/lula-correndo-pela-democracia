/* Adapted from erika_diva_special_v2_ErikaHilton.js; global entry point for this game's classic HTML scripts. */
(()=>{
'use strict';
/* Diva Guerreira — Bandeira da Diversidade • v2
 * Módulo ES: não substitui o loop do jogo nem atualiza o estado do mundo.
 * Congele o update do jogo enquanto isActive(); continue chamando update(dt)/render(ctx).
 * Passe drawWorld(ctx) SEM o chefão e drawBoss(ctx) separadamente para permitir seus flashes.
 * Aplique dano somente em onHit, uma vez por hit (id de evento exclusivo).
 */
const ERIKA_SPECIAL = Object.freeze({
  duration: 5.70,
  cutInEnd: 1.18,
  entryEnd: 1.60,
  chargeEnd: 2.28,
  contactAt: 3.20,
  hitCount: 13,
  hitInterval: 0.125,
  finalAt: 4.825,
  restoreAt: 5.55,
  width: 960, height: 540,
  heroSpriteCell: 320, projectileCell: 320, impactCell: 256
});
const C = ERIKA_SPECIAL;
const clamp = (n,a,b) => Math.min(b,Math.max(a,n));
const smooth = v => {v=clamp(v,0,1);return v*v*(3-2*v);};
const lerp = (a,b,q) => a+(b-a)*q;
const pad = n => String(n).padStart(2,'0');
const loadImage = src => new Promise((ok,fail) => {
  const im = new Image(); im.onload=()=>ok(im);
  im.onerror=()=>fail(new Error('Falha ao carregar imagem: '+src.substring(0,160)));
  im.src=src;
});

class ErikaDivaSpecial {
  constructor({ assetRoot='assets/special/erika_hilton/', inlineAssets=null,
    onHit=()=>{}, onEnd=()=>{} }={}) {
    this.assetRoot=assetRoot; this.inlineAssets=inlineAssets;
    this.onHit=onHit; this.onEnd=onEnd;
    this.img={}; this.ready=false;this.active=false;this.time=0;this.hits=0;
    this.finished=false;this._loading=null;this._session=0;
  }
  url(key,name){return this.inlineAssets?.[key]||this.assetRoot+name;}
  preload(){
    if(this._loading)return this._loading;
    const files={
      hero:'hero_8_frames.png',projectile:'rainbow_projectile_8_frames.png',
      impact:'rainbow_impact_6_frames.png',portrait:'erika_portrait.png'
    };
    this._loading=Promise.all(Object.entries(files).map(async ([key,name])=>[key,await loadImage(this.url(key,name))]))
      .then(values=>{this.img=Object.fromEntries(values);this.ready=true;return this;})
      .catch(error=>{this._loading=null;throw error;});
    return this._loading;
  }
  start(){
    if(!this.ready||this.active)return false;
    this.time=0;this.hits=0;this.finished=false;this.active=true;this._session++;
    return true;
  }
  isActive(){return this.active;}
  cancel(){this.active=false;this.finished=true;}
  hitsAt(t){return t<C.contactAt?0:clamp(Math.floor((t-C.contactAt)/C.hitInterval)+1,0,C.hitCount);}
  get phase(){let t=this.time;
    return t<C.cutInEnd?'cut-in':t<C.entryEnd?'entrada':t<C.chargeEnd?'carregamento':
      t<C.contactAt?'disparo':t<C.finalAt?'13 impactos':t<C.restoreAt?'finalizacao':'retorno';}
  update(dt){
    if(!this.active)return;
    // use the external game clock, capped against huge tab-resume jumps
    this.time=clamp(this.time+clamp(Number(dt)||0,0,.12),0,C.duration);
    const next=this.hitsAt(this.time);
    for(let hit=this.hits+1;hit<=next;hit++){
      try {this.onHit({hit,total:C.hitCount,damageEventId:`erika_diva_${this._session}_${hit}`});}
      catch(error){console.error('[Diva Guerreira] Falha em onHit',error);}
    }
    this.hits=next;
    if(this.time>=C.duration&&!this.finished){this.finished=true;this.active=false;try{this.onEnd();}catch(error){console.error('[Diva Guerreira] Falha em onEnd',error);}}
  }
  setPreviewTime(t){ // visual-only, for an offline test timeline; does not dispatch damage
    this.time=clamp(t,0,C.duration);this.hits=this.hitsAt(this.time);
  }
  frame(ctx,key,index,x,y,w,h){
    const cell=key==='impact'?256:320;
    const max=key==='impact'?6:8;
    const sheet=this.img[key];if(!sheet)return;
    ctx.drawImage(sheet,clamp(index,0,max-1)*cell,0,cell,cell,Math.round(x),Math.round(y),Math.round(w),Math.round(h));
  }
  wind(ctx,t,W,H){
    ctx.save();ctx.beginPath();ctx.rect(0,4,W,H-116);ctx.clip();
    for(let i=0;i<36;i++){
      const y=28+(i*43)%(H-150);
      const x=W-((t*(360+((i%3)*95)) + i*134)%(W+280));
      const len=66+(i%7)*23;
      ctx.globalAlpha=.12+(i%5)*.029;
      ctx.strokeStyle=i%3===0?'#fff0fc':i%2===0?'#8edfff':'#ff8be5';
      ctx.lineWidth=i%6===0?5:i%3===0?3:2;
      ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+len,y-3);ctx.stroke();
    }
    ctx.restore();
  }
  intro(ctx,t,H){
    const arrival=smooth(t/.23), retract=smooth((t-.86)/.32);
    const x=-355+357*arrival-357*retract;
    const h=H-20, w=320;
    ctx.save();ctx.shadowColor='#fa8ae9';ctx.shadowBlur=22;
    ctx.fillStyle='#3d1256';ctx.fillRect(x-7,8,w+14,h+4);ctx.shadowBlur=0;
    ctx.beginPath();ctx.rect(x,10,w,h);ctx.clip();
    ctx.drawImage(this.img.portrait,x,10,w,h);
    ctx.restore();
    ctx.save();ctx.globalAlpha=1-retract;
    const g=ctx.createLinearGradient(330,0,710,0);
    g.addColorStop(0,'rgba(122,30,133,.78)');g.addColorStop(1,'rgba(0,0,0,0)');
    ctx.fillStyle=g;ctx.fillRect(317,0,480,H);
    ctx.shadowColor='#ff8de8';ctx.shadowBlur=9;ctx.lineWidth=5;ctx.strokeStyle='#ffb2ef';
    for(let k=0;k<3;k++){ctx.beginPath();ctx.moveTo(355+k*42,130+k*80);ctx.lineTo(720+k*30,88+k*80);ctx.stroke();}
    ctx.textAlign='left';ctx.strokeStyle='#190822';
    ctx.lineWidth=5;ctx.font='900 28px system-ui';
    ctx.strokeText('ERIKA HILTON',340,212);ctx.fillStyle='#ffffff';ctx.fillText('ERIKA HILTON',340,212);
    ctx.lineWidth=6;ctx.font='900 41px system-ui';
    ctx.strokeText('DIVA',340,258);ctx.fillStyle='#ffe49b';ctx.fillText('DIVA',340,258);
    ctx.strokeText('GUERREIRA!',340,306);ctx.fillStyle='#ffbde9';ctx.fillText('GUERREIRA!',340,306);
    ctx.lineWidth=3;ctx.font='800 18px system-ui';ctx.strokeStyle='#2a0830';ctx.fillStyle='#ffe7ff';
    ctx.strokeText('BANDEIRA DA DIVERSIDADE',342,338);ctx.fillText('BANDEIRA DA DIVERSIDADE',342,338);
    ctx.restore();
  }
  heroFrame(t){
    if(t<C.entryEnd)return 0;
    if(t<1.78)return 1;
    if(t<1.94)return 2;
    if(t<2.08)return 3;
    if(t<2.23)return 4;
    if(t<2.52)return 5;
    if(t<C.finalAt)return 6;
    return 7;
  }
  drawHero(ctx,t,heroX,ground){
    const size=220; const y=ground-size;
    const enter=smooth((t-C.cutInEnd)/(C.entryEnd-C.cutInEnd));
    const x=heroX-(190*(1-enter));
    const f=this.heroFrame(t);
    if(t<C.entryEnd){
      for(let i=4;i>=1;i--){ctx.save();ctx.globalAlpha=.15-i*.027;
        ctx.filter='brightness(1.6) hue-rotate(35deg)';this.frame(ctx,'hero',f,x-i*36,y, size,size);ctx.restore();}
    }
    if(t>1.65 && t<2.45){
      ctx.save();ctx.globalCompositeOperation='screen';ctx.globalAlpha=.27;
      const pulse=35+22*Math.sin((t-1.65)*18);
      let g=ctx.createRadialGradient(x+166,y+126,4,x+166,y+126,75+pulse);
      g.addColorStop(0,'white');g.addColorStop(.25,'#ff83f7');g.addColorStop(.7,'#7b5bff');g.addColorStop(1,'transparent');
      ctx.fillStyle=g;ctx.fillRect(x+30,y,230,250);ctx.restore();
    }
    this.frame(ctx,'hero',f,x,y,size,size);
  }
  projectileX(t,startX,contactX){
    // purely horizontal projectile trajectory, no vertical component
    return lerp(startX,contactX,clamp((t-C.chargeEnd)/(C.contactAt-C.chargeEnd),0,1));
  }
  drawProjectile(ctx,t,heroX,ground,impactX){
    if(t<C.chargeEnd||t>=C.finalAt+.1)return;
    const cy=ground-111;
    const startX=heroX+198;
    const cx=this.projectileX(t,startX,impactX);
    const contact=t>=C.contactAt;
    const i=contact?7:Math.min(7,Math.floor((t-C.chargeEnd)*15)%8);
    const sz=192;
    if(!contact){
      for(let k=4;k>=1;k--){ctx.save();ctx.globalAlpha=.08+(5-k)*.035;
        this.frame(ctx,'projectile',i,cx-sz/2-k*24,cy-sz/2,sz,sz);ctx.restore();}
    }else{
      // hold projectile on contact; pulse but never move into other visual cells
      ctx.save();ctx.globalAlpha=.65+.15*Math.sin(t*42);
      this.frame(ctx,'projectile',7,cx-sz/2,cy-sz/2,sz,sz);ctx.restore();return;
    }
    this.frame(ctx,'projectile',i,cx-sz/2,cy-sz/2,sz,sz);
  }
  flashAt(t){
    if(t<C.contactAt || t>=C.finalAt)return {on:false,index:-1,phase:1};
    let n=(t-C.contactAt)/C.hitInterval;
    return {on:(n-Math.floor(n))<.53,index:Math.floor(n),phase:n-Math.floor(n)};
  }
  contactEffects(ctx,t,impactX,impactY,W,H){
    const hit=this.flashAt(t);
    if(hit.on){
      ctx.save();ctx.globalCompositeOperation='screen';ctx.globalAlpha=.86;
      this.frame(ctx,'impact',hit.index%6,impactX-105,impactY-104,210,210);
      ctx.restore();
      ctx.save();ctx.fillStyle=hit.index%2===0?'rgba(255,255,255,.17)':'rgba(243,95,242,.16)';ctx.fillRect(0,0,W,H);ctx.restore();
      ctx.save();ctx.translate(impactX,impactY);ctx.lineWidth=5;ctx.strokeStyle='#fff2c1';ctx.globalAlpha=.85;
      for(let i=0;i<8;i++){const a=i*Math.PI/4+t*3;
        ctx.beginPath();ctx.moveTo(Math.cos(a)*14,Math.sin(a)*14);
        ctx.lineTo(Math.cos(a)*70,Math.sin(a)*70);ctx.stroke();}
      ctx.restore();
    }
    if(t>=C.finalAt&&t<C.finalAt+.55){
      let p=(t-C.finalAt)/.55;
      ctx.save();ctx.globalAlpha=(1-p)*.9;ctx.lineWidth=12*(1-p)+1;
      ctx.strokeStyle='#ff85de';ctx.beginPath();ctx.ellipse(impactX,impactY,24+p*190,28+p*140,0,0,2*Math.PI);ctx.stroke();
      ctx.lineWidth=4;ctx.strokeStyle='#b5fbff';ctx.beginPath();ctx.ellipse(impactX,impactY,36+p*225,22+p*169,0,0,2*Math.PI);ctx.stroke();ctx.restore();
    }
  }
  render(ctx,{
    width=C.width,height=C.height,
    drawWorld=null,drawBoss=null,
    heroX=115,ground=423,
    bossRect={x:702,y:147,w:252,h:274},
  }={}) {
    if(!this.ready)return;
    const t=this.time,W=width,H=height;
    const impactX=bossRect.x+bossRect.w*.30,impactY=ground-111;
    ctx.save();ctx.imageSmoothingEnabled=false;
    // World callback should draw frozen stage and Lula but NOT render the boss.
    if(drawWorld)drawWorld(ctx);
    else {ctx.fillStyle='#13264b';ctx.fillRect(0,0,W,H);}
    ctx.fillStyle=`rgba(7,5,34,${t<C.cutInEnd?.61:.45})`;
    ctx.fillRect(0,0,W,H);
    this.wind(ctx,t,W,H);
    if(drawBoss){
      // World has already rendered its own boss. Redraw an OVERLAY only during a hit flash.
      // Prevent a second normal boss from appearing and making it look blurry/duplicated.
      const hit=this.flashAt(t);
      if(hit.on){ctx.save();ctx.translate(Math.sin(t*154)*7,Math.cos(t*113)*3);
        ctx.filter=hit.index%2===0?'brightness(0) invert(1)':'brightness(0) saturate(100%) invert(70%) sepia(40%) saturate(3500%) hue-rotate(260deg)';
        drawBoss(ctx);ctx.restore();}
    }
    if(t<C.cutInEnd)this.intro(ctx,t,H);
    else{
      this.drawHero(ctx,t,heroX,ground);
      this.drawProjectile(ctx,t,heroX,ground,impactX);
    }
    this.contactEffects(ctx,t,impactX,impactY,W,H);
    if(t>=C.cutInEnd){
      ctx.save();ctx.textAlign='center';ctx.lineWidth=6;ctx.strokeStyle='#1c0a2a';
      ctx.font='900 28px system-ui';ctx.strokeText('BANDEIRA DA DIVERSIDADE!',W/2,63);
      ctx.fillStyle='#ffe59f';ctx.fillText('BANDEIRA DA DIVERSIDADE!',W/2,63);
      if(this.hitsAt(t)>0){ctx.font='900 23px ui-monospace,monospace';
        ctx.strokeText(`${pad(this.hitsAt(t))} / 13 HITS`,W/2,97);
        ctx.fillStyle='#ffaee8';ctx.fillText(`${pad(this.hitsAt(t))} / 13 HITS`,W/2,97);}
      ctx.restore();
    }
    ctx.restore();
  }
}

window.ErikaDivaSpecial=Object.freeze({ErikaDivaSpecial,ERIKA_SPECIAL});
})();
