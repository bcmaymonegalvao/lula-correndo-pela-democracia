/* Módulo especial V3. Carregue motor_especiais_v3.js antes.
 * Uso: const sp=new AnaElizaSpecialV3(canvas,{onHit:onHit,onEnd:onEnd}); await sp.preload(); sp.start();
 * Atualize sp.update(dt) e sp.render() no loop do jogo enquanto a simulação do mundo fica congelada.
 */
(function(root){'use strict';
const opts={"id":"ana_eliza","name":"ANA ELIZA","card1":"JUSTIÇA","card2":"POPULAR","cardSize":49,"cardSize2":47,"screen":"ANA ELIZA • VOZES DA JUVENTUDE","tint":"#ff72d4","headline":"#ffb6e8","wind":"rgba(255,136,226,.24)","trail":"rgba(255,67,191,.69)","flash":"#ff91e6","cardBg":"#340d34","cardGradient":"rgba(142,20,112,.88)","assets":{"finish":"assets/specials/ana/finish.png","portrait":"assets/specials/ana/portrait.webp","idle1":"assets/specials/ana/idle1.png","idle2":"assets/specials/ana/idle2.png","charge0":"assets/specials/ana/charge0.png","charge1":"assets/specials/ana/charge1.png","charge2":"assets/specials/ana/charge2.png","charge3":"assets/specials/ana/charge3.png","attack0":"assets/specials/ana/attack0.png","justiceicon":"assets/specials/ana/justiceicon.png","projectile0":"assets/specials/ana/projectile0.png","attack2":"assets/specials/ana/attack2.png","attack1":"assets/specials/ana/attack1.png","attack3":"assets/specials/ana/attack3.png","projectile2":"assets/specials/ana/projectile2.png","projectile3":"assets/specials/ana/projectile3.png","burst":"assets/specials/ana/burst.png","projectile1":"assets/specials/ana/projectile1.png","crowd":"assets/specials/ana/crowd.png"},"finish":"JUSTIÇA POPULAR!","overlay":true};
class AnaElizaSpecialV3 extends root.EspecialCinematico{
  constructor(canvas,callbacks={}){super(canvas,JSON.parse(JSON.stringify(opts)),callbacks);}
}
root.AnaElizaSpecialV3=AnaElizaSpecialV3;
})(typeof window!=='undefined'?window:globalThis);
