/* Módulo especial V3. Carregue motor_especiais_v3.js antes.
 * Uso: const sp=new JanonesSpecialV3(canvas,{onHit:onHit,onEnd:onEnd}); await sp.preload(); sp.start();
 * Atualize sp.update(dt) e sp.render() no loop do jogo enquanto a simulação do mundo fica congelada.
 */
(function(root){'use strict';
const opts={"id":"janones","name":"JANONES","card1":"MOBILIZAÇÃO","card2":"POPULAR","cardSize":36,"cardSize2":51,"screen":"JANONES • ONDA DA MOBILIZAÇÃO","tint":"#62cfff","headline":"#c2eaff","wind":"rgba(117,211,255,.30)","trail":"rgba(66,163,255,.7)","flash":"#74ceff","cardBg":"#082852","cardGradient":"rgba(9,77,168,.83)","assets":{"finish":"assets/specials/janones/finish.png","finish_clean":"assets/specials/janones/finish_clean.png","portrait":"assets/specials/janones/portrait.webp","idle1":"assets/specials/janones/idle1.png","idle2":"assets/specials/janones/idle2.png","charge0":"assets/specials/janones/charge0.png","charge1":"assets/specials/janones/charge1.png","charge2":"assets/specials/janones/charge2.png","charge3":"assets/specials/janones/charge3.png","attack0":"assets/specials/janones/attack0.png","flagfx":"assets/specials/janones/flagfx.png","burst":"assets/specials/janones/burst.png","projectile0":"assets/specials/janones/projectile0.png","projectile1":"assets/specials/janones/projectile1.png","projectile2":"assets/specials/janones/projectile2.png","projectile3":"assets/specials/janones/projectile3.png","projectile4":"assets/specials/janones/projectile4.png","projectile5":"assets/specials/janones/projectile5.png","attack2":"assets/specials/janones/attack2.png","attack1":"assets/specials/janones/attack1.png","attack3":"assets/specials/janones/attack3.png","crowd":"assets/specials/janones/crowd.png"},"finish":"MOBILIZAÇÃO POPULAR!","overlay":true};
class JanonesSpecialV3 extends root.EspecialCinematico{
  constructor(canvas,callbacks={}){super(canvas,JSON.parse(JSON.stringify(opts)),callbacks);}
}
root.JanonesSpecialV3=JanonesSpecialV3;
})(typeof window!=='undefined'?window:globalThis);
