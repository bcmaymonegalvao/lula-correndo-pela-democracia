/* Todos os clipes são sequências reais de WebP; 8 passos de corrida,
   12 de pulo e 8 de pulo duplo, socos e voadora com 8 quadros. */
window.GameAnimation=(()=>{
 const FPS_RUN=11;
 function clip({step,grounded,jumpsUsed,landing}){
  if(step)return window.GameCombat.MOVES[step-1].clip;
  if(!grounded&&jumpsUsed>=2)return 'double_jump';
  if(!grounded||landing>0)return 'jump';
  return 'run';
 }
 function frame({clipId,elapsed,jumpAge,velocityY,landing,combat}){
  if(['left_punch','front_punch','flying_kick'].includes(clipId))return combat.visualFrame();
  if(clipId==='run')return Math.floor(elapsed*FPS_RUN)%8;
  if(clipId==='double_jump'){
   if(velocityY<0)return Math.min(5,Math.floor(jumpAge*17));return Math.min(7,5+Math.floor(Math.max(0,velocityY)/230));
  }
  if(landing>0)return 10;
  if(jumpAge<.1)return 0;
  if(velocityY< -220)return 2;
  if(velocityY<0)return 4;
  if(velocityY<170)return 6;
  return 8;
 }
 return {FPS_RUN,clip,frame};
})();
