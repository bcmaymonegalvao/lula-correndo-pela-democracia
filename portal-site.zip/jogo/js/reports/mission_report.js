/* Relatório de missão — Alpha 0.9.5, implementação não versionada.
   Apenas lê um snapshot do jogo. Nunca inventa resultados nem altera estatísticas.
   API: window.GameMissionReport.create({background, portrait, logo, onRestart, onHome})
*/
(() => {
 'use strict';
 const WIDTH = 1080, HEIGHT = 1350;
 // Os nomes são metadados fixos dos bônus; quantidades vêm SOMENTE do snapshot.
 const FALLBACK_BENEFITS=Object.freeze([
  ['fim_escala_6x1','Fim da escala 6×1'],['passe_livre','Passe livre'],
  ['aumento_real_salario_minimo','Aumento real do salário mínimo'],
  ['mais_especialistas','Mais especialistas'],['susp','SUSP'],
  ['pe_de_meia','Pé-de-Meia'],['desenrola','Desenrola'],
  ['isencao_ir','Isenção do IR'],['farmacia_popular','Farmácia Popular'],
  ['universidades_publicas','Universidades públicas'],
  ['minha_casa_minha_vida','Minha Casa, Minha Vida'],
  ['reducao_desmatamento','Redução do desmatamento'],
  ['reindustrializacao','Reindustrialização']
 ].map(([id,name],row)=>Object.freeze({id,name,row})));
 const benefitsCatalog=()=>window.GameBonuses?.catalog||FALLBACK_BENEFITS;
 const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
 const number=v=>Math.max(0,Number.isFinite(+v)?Number(v):0);
 const pt=v=>Math.round(number(v)).toLocaleString('pt-BR');
 const hms=ms=>{let n=Math.floor(number(ms)/1000);const h=Math.floor(n/3600);n%=3600;const m=Math.floor(n/60),s=n%60;return h?`${h}h ${String(m).padStart(2,'0')}m ${String(s).padStart(2,'0')}s`:`${m}m ${String(s).padStart(2,'0')}s`;};
 const safeText=(s,length=34)=>String(s??'').replace(/[\u0000-\u001f\u007f]/g,'').trim().slice(0,length);
 const loaded=im=>im&&im.complete&&im.naturalWidth>0;
 function image(src){const im=new Image();im.decoding='async';im.src=src;return im;}
 function polygon(ctx,cx,cy,outer,inner,points=5,rotation=-Math.PI/2){ctx.beginPath();for(let i=0;i<points*2;i++){const theta=rotation+i*Math.PI/points,r=i%2?inner:outer;const x=cx+Math.cos(theta)*r,y=cy+Math.sin(theta)*r;if(i===0)ctx.moveTo(x,y);else ctx.lineTo(x,y);}ctx.closePath();}
 function box(ctx,x,y,w,h,r=16){r=Math.min(r,w/2,h/2);ctx.beginPath();ctx.moveTo(x+r,y);ctx.lineTo(x+w-r,y);ctx.quadraticCurveTo(x+w,y,x+w,y+r);ctx.lineTo(x+w,y+h-r);ctx.quadraticCurveTo(x+w,y+h,x+w-r,y+h);ctx.lineTo(x+r,y+h);ctx.quadraticCurveTo(x,y+h,x,y+h-r);ctx.lineTo(x,y+r);ctx.quadraticCurveTo(x,y,x+r,y);ctx.closePath();}
 function fitCover(ctx,img,x,y,w,h){if(!loaded(img))return false;const scale=Math.max(w/img.naturalWidth,h/img.naturalHeight);const sw=w/scale,sh=h/scale,sx=(img.naturalWidth-sw)/2,sy=(img.naturalHeight-sh)/2;ctx.drawImage(img,sx,sy,sw,sh,x,y,w,h);return true;}
 function fitContain(ctx,img,x,y,w,h){if(!loaded(img))return false;const scale=Math.min(w/img.naturalWidth,h/img.naturalHeight);const dw=img.naturalWidth*scale,dh=img.naturalHeight*scale;ctx.drawImage(img,x+(w-dw)/2,y+(h-dh)/2,dw,dh);return true;}
 function text(ctx,value,x,y,maxWidth){ctx.fillText(String(value),x,y,maxWidth);}
 function makeSummary(snapshot){
  const s=snapshot||{},victory=s.result==='victory';
  return Object.freeze({
   playerName:safeText(s.playerName,26), result:victory?'victory':'defeat',
   phaseName:safeText(s.phaseName||'Brasília',60),phaseReached:Math.max(1,Math.floor(number(s.phaseReached)||1)),
   score:number(s.score),votesCollected:number(s.votesCollected),protectedBenefits:number(s.protectedBenefits),
   bestCombo:number(s.bestCombo),playTimeMs:number(s.playTimeMs),
   enemiesDefeated:number(s.enemiesDefeated),bossDefeated:!!s.bossDefeated,
   bonusesCollected:number(s.bonusesCollected),
   bonusCounts:Object.freeze(Object.fromEntries(benefitsCatalog().map(b=>[b.id,Math.floor(number(s.bonusCounts?.[b.id]))])))
  });
 }
 function renderArt(canvas,summary,assets={}){
  const s=makeSummary(summary),ctx=canvas.getContext('2d');
  canvas.width=WIDTH;canvas.height=HEIGHT;
  const win=s.result==='victory';const GOLD='#ffe28a',MAGENTA='#ef4167',LIGHT='#f5f7fe';
  const bg=ctx.createLinearGradient(0,0,WIDTH,HEIGHT);bg.addColorStop(0,win?'#133c58':'#121f39');bg.addColorStop(.55,win?'#0c1c36':'#10152a');bg.addColorStop(1,'#050c1d');ctx.fillStyle=bg;ctx.fillRect(0,0,WIDTH,HEIGHT);
  ctx.save();ctx.globalAlpha=win?.35:.20;fitCover(ctx,assets.background,0,0,WIDTH,540);ctx.restore();
  const wash=ctx.createLinearGradient(0,0,0,570);wash.addColorStop(0,'#07102044');wash.addColorStop(.65,'#08142d99');wash.addColorStop(1,'#091529');ctx.fillStyle=wash;ctx.fillRect(0,0,WIDTH,570);
  // Neon pixels and decorative border
  ctx.strokeStyle=win?'#f6bd5688':'#617fa299';ctx.lineWidth=5;ctx.strokeRect(27,27,WIDTH-54,HEIGHT-54);
  ctx.strokeStyle='#d6455680';ctx.lineWidth=2;ctx.strokeRect(37,37,WIDTH-74,HEIGHT-74);
  ctx.fillStyle=win?'#ffb96f':'#9bb3d9';for(let i=0;i<16;i++){const x=57+(i*173)%970,y=115+(i*137)%330;ctx.globalAlpha=.37;ctx.fillRect(x,y,8+(i%3)*5,8+(i%2)*5);}ctx.globalAlpha=1;
  if(win){
   // fixed seeded festive confetti — decoration only, never statistics
   for(let i=0;i<70;i++){const x=65+(i*197)%930,y=190+(i*107)%410;ctx.save();ctx.translate(x,y);ctx.rotate((i*31%360)*Math.PI/180);ctx.fillStyle=['#f6ca67','#ef4167','#6ee9bf','#b1a1ff'][i%4];ctx.fillRect(0,0,5+i%4,9+i%7);ctx.restore();}
  }
  ctx.font='800 28px monospace';ctx.fillStyle='#9ae9e5';ctx.textAlign='left';text(ctx,'✦  RELATÓRIO DA MISSÃO',76,104);
  ctx.font='1000 53px system-ui,sans-serif';ctx.fillStyle=GOLD;text(ctx,'LULA — CORRENDO',74,172,700);text(ctx,'PELA DEMOCRACIA',74,231,700);
  // portrait inside red star; image clipped to star silhouette
  ctx.save();ctx.shadowColor='#ef3158';ctx.shadowBlur=27;polygon(ctx,842,291,145,72);ctx.fillStyle='#ca132d';ctx.fill();ctx.restore();
  ctx.save();polygon(ctx,842,291,129,66);ctx.clip();
  if(loaded(assets.portrait))fitContain(ctx,assets.portrait,747,196,190,194);
  else if(loaded(assets.player))fitContain(ctx,assets.player,749,205,180,175);
  ctx.restore();
  ctx.font='1000 54px system-ui,sans-serif';ctx.fillStyle=win?'#ffe58a':'#dce6f4';text(ctx,win?'VITÓRIA! O POVO VENCEU!':'MISSÃO NÃO CONCLUÍDA',74,330,645);
  ctx.font='800 26px monospace';ctx.fillStyle=win?'#bafee3':'#b0bfd8';text(ctx,win?'MISSÃO CONCLUÍDA':'A LUTA CONTINUA!',76,372,640);
  // player name panel
  box(ctx,67,420,945,105,19);ctx.fillStyle='#102848ed';ctx.fill();ctx.lineWidth=3;ctx.strokeStyle='#7adbe999';ctx.stroke();
  ctx.font='700 23px monospace';ctx.fillStyle='#9fd3e3';text(ctx,'JOGADOR(A)',94,458);
  ctx.font='1000 43px system-ui,sans-serif';ctx.fillStyle=LIGHT;text(ctx,s.playerName||'JOGADOR(A)',92,507,855);
  // Estatísticas gerais compactas, preservadas em ambos os desfechos.
  const cells=[
   ['PONTUAÇÃO',pt(s.score)], ['VOTOS COLETADOS',pt(s.votesCollected)],
   ['BENEFÍCIOS PROTEGIDOS',pt(s.protectedBenefits)], ['MELHOR COMBO',`${pt(s.bestCombo)} HITS`],
   ['TEMPO DE JOGO',hms(s.playTimeMs)], ['INIMIGOS DERROTADOS',pt(s.enemiesDefeated)],
   ['FASE ALCANÇADA',`${pt(s.phaseReached)} · ${s.phaseName}`], ['TARIFLÁVIO',s.bossDefeated?'DERROTADO':'NÃO DERROTADO']
  ];
  for(let ci=0;ci<cells.length;ci++){
   const [label,value]=cells[ci],x=67+(ci%2)*484,y=542+Math.floor(ci/2)*87;
   box(ctx,x,y,462,79,13);ctx.fillStyle='#112743ed';ctx.fill();
   ctx.strokeStyle=win?'#3caa9b88':'#7186a088';ctx.lineWidth=2;ctx.stroke();
   ctx.fillStyle=win?'#ffd27f':'#b8c8e4';ctx.font='800 18px monospace';text(ctx,label,x+18,y+25,420);
   ctx.fillStyle=LIGHT;ctx.font='950 29px system-ui,sans-serif';text(ctx,value,x+18,y+62,422);
  }
  // Todas as 13 categorias de bônus, incluindo quantidades zeradas.
  // Ícones: primeiro quadro de cada linha do atlas REAL do jogo (192×192).
  box(ctx,67,903,945,325,15);ctx.fillStyle='#0c253dF0';ctx.fill();
  ctx.strokeStyle=win?'#e3ad5e':'#7792b8';ctx.lineWidth=2;ctx.stroke();
  ctx.font='900 23px monospace';ctx.fillStyle=win?'#ffe09a':'#d9e2f2';
  text(ctx,`13 BÔNUS • ${pt(s.bonusesCollected)} COLETADOS`,88,941,895);
  const benefits=benefitsCatalog();
  for(let i=0;i<benefits.length;i++){
   const b=benefits[i],col=i>=7?1:0,row=i>=7?i-7:i;
   const x=83+col*469,y=955+row*38,count=s.bonusCounts[b.id]||0;
   ctx.save();ctx.globalAlpha=count?1:.62;
   box(ctx,x,y,443,35,6);ctx.fillStyle=count?'#254464':'#15273f';ctx.fill();
   if(loaded(assets.bonusAtlas)){
    ctx.imageSmoothingEnabled=false;
    ctx.drawImage(assets.bonusAtlas,0,b.row*192,192,192,x+3,y+2,32,32);
    ctx.imageSmoothingEnabled=true;
   }else{ctx.fillStyle='#f0b67b';ctx.font='22px monospace';text(ctx,'✦',x+7,y+26);}
   ctx.fillStyle=count?'#f6f8fd':'#b5c5d8';ctx.font='750 18px system-ui,sans-serif';
   text(ctx,b.name,x+42,y+24,350);
   ctx.fillStyle=count?'#ffdd8e':'#91a7c4';ctx.font='950 22px monospace';ctx.textAlign='right';
   text(ctx,`×${pt(count)}`,x+432,y+25,74);ctx.textAlign='left';ctx.restore();
  }
  ctx.fillStyle=win?GOLD:'#d5e0ee';ctx.font='900 31px system-ui,sans-serif';ctx.textAlign='center';
  text(ctx,win?'O povo venceu!':'A luta continua!',540,1274,920);
  // Autoria e patch na arte exportada (tambem na tela de resultado).
  const build=window.GameBuildInfo;
  const owner=build?.author||'Bruno Galvão';
  const release=build?.label||'Alpha 0.9.5 · Patch QA4';
  ctx.fillStyle='#b9d4df';ctx.font='600 17px system-ui,sans-serif';
  text(ctx,`Desenvolvido por ${owner} · © 2026`,540,1298,965);
  ctx.fillStyle='#8faac0';ctx.font='600 15px system-ui,sans-serif';
  text(ctx,`${release} · #LulaCorrendoPelaDemocracia`,540,1317,970);
  ctx.textAlign='left';return canvas;
 }
 function create({background,portrait,player,logo,onRestart=()=>{},onHome=()=>{}}={}){
  const assets={background:typeof background==='string'?image(background):background,
   portrait:typeof portrait==='string'?image(portrait):portrait,
   player:typeof player==='string'?image(player):player,
   logo:typeof logo==='string'?image(logo):logo,
   bonusAtlas:image('assets/sprites/coletaveis/bonus_13x4.webp')};
  const epilogue=window.GameEpilogueCinematic?.create({
   background,portrait,lula:player,celebrate:'assets/epilogue/lula_celebracao.webp',
   celebrateFrames:[1,2,3,4].map(n=>`assets/sprites/animacoes/jump/${String(n).padStart(2,'0')}.webp`),
   defeatFrames:[5,6,7,8].map(n=>`assets/sprites/animacoes/jump/${String(n).padStart(2,'0')}.webp`),
   crowd:[
     'assets/sprites/npc_rgba_v5/eleitores_l/frame_01.png',
     'assets/sprites/npc_rgba_v5/eleitores_l/frame_03.png',
     'assets/sprites/npc_rgba_v5/amor_contra_odio/frame_03.png',
     'assets/sprites/npc_rgba_v5/vira_voto/frame_03.png'
   ],applause:'assets/epilogue/aplausos_torcida.wav',audio:true
  });
  const root=document.createElement('div');root.className='mission-end-overlay hidden';root.setAttribute('role','dialog');root.setAttribute('aria-modal','true');root.setAttribute('aria-label','Resultado da missão');
  root.innerHTML=`<canvas class="mission-transition" aria-hidden="true"></canvas>
  <button type="button" class="mission-skip" id="missionSkip">PULAR CINEMÁTICA →</button>
  <section class="mission-report-screen hidden">
   <header class="mission-report-title"><span>✦ FIM DE MISSÃO ✦</span><h2 id="missionOutcome">RELATÓRIO DA MISSÃO</h2><p id="missionOutcomeText"></p></header>
   <div class="mission-report-layout"><div class="mission-form">
    <label for="missionPlayerName">DIGITE SEU NOME OU APELIDO</label><input id="missionPlayerName" type="text" maxlength="26" autocomplete="nickname" placeholder="Seu nome no relatório" aria-label="Nome do jogador">
    <div id="missionStats" class="mission-live-stats" aria-live="polite"></div>
    <section class="mission-benefit-recap" aria-label="Benefícios coletados">
     <h3>13 BENEFÍCIOS DA MISSÃO <span id="missionBenefitTotal"></span></h3>
     <div id="missionBenefitRows" class="mission-benefit-rows"></div>
    </section>
    <div class="mission-report-actions"><button type="button" id="missionGenerate">🎨 GERAR MINHA ARTE</button><button type="button" id="missionDownload">⬇ BAIXAR IMAGEM</button><button type="button" id="missionShare">📤 COMPARTILHAR</button><button type="button" id="missionReplay">▶ JOGAR NOVAMENTE</button><button type="button" id="missionHome">⌂ TELA INICIAL</button></div>
    <p id="missionActionStatus" class="mission-action-status" role="status" aria-live="polite"></p>
    <small>PNG 1080 × 1350 • 4:5 • Estatísticas capturadas ao fim da partida.</small>
    <small class="mission-build-credit" data-game-build="credits">Desenvolvido por Bruno Galvão</small>
    <small class="mission-build-credit" data-game-build="version">Alpha 0.9.5 · Patch QA4</small>
   </div><div class="mission-preview"><canvas id="missionPngPreview" width="1080" height="1350" role="img" aria-label="Prévia da imagem do relatório de missão"></canvas><span>PRÉVIA • FORMATO 4:5 • PNG</span></div></div>
  </section>`;
  document.body.appendChild(root);
  // Conteudo dinamico: mesma fonte de versao utilizada na tela inicial.
  const build=window.GameBuildInfo;
  if(build){
   root.querySelectorAll('[data-game-build="credits"]').forEach(el=>{el.textContent=build.credits;});
   root.querySelectorAll('[data-game-build="version"]').forEach(el=>{el.textContent=build.label;});
  }
  const q=id=>root.querySelector('#'+id),panel=root.querySelector('.mission-report-screen'),fx=root.querySelector('.mission-transition');
  const fctx=fx.getContext('2d'),preview=q('missionPngPreview');
  let result=null,runSnapshot=null,phase='hidden',phaseStart=0,raf=0,oldFocus=null,generated=false,frozenScene=null;
  const durations=epilogue?.durations||{victory:3900,defeat:1600,star:2100};
  function resizeFx(){const r=fx.getBoundingClientRect();const dpr=Math.min(2,window.devicePixelRatio||1);fx.width=Math.max(1,Math.round(r.width*dpr));fx.height=Math.max(1,Math.round(r.height*dpr));}
  function enterPhase(next,ts){phase=next;phaseStart=ts;if(next==='victory')epilogue?.cheers();else if(next==='star')epilogue?.stop();}
  function animationFrame(ts){
   if(!['victory','defeat','star'].includes(phase))return;
   if(!phaseStart)phaseStart=ts;const age=ts-phaseStart;
   if(age>=durations[phase]){
    if(phase==='victory'||phase==='defeat')enterPhase('star',ts);
    else {beginResults();return;}
   }
   epilogue?.draw(fctx,fx.width,fx.height,phase,ts-phaseStart,frozenScene);
   raf=requestAnimationFrame(animationFrame);
  }
  function beginResults(){
   cancelAnimationFrame(raf);raf=0;epilogue?.stop();phase='results';fx.classList.add('hidden');q('missionSkip').classList.add('hidden');panel.classList.remove('hidden');
   const win=runSnapshot.result==='victory';
   q('missionOutcome').textContent=win?'VITÓRIA! — O POVO VENCEU!':'MISSÃO NÃO CONCLUÍDA';
   q('missionOutcomeText').textContent=win?'Você impediu Tariflávio! Registre sua conquista e compartilhe sua arte.':'A LUTA CONTINUA! Registre sua jornada e tente novamente.';
   const pairs=[['Pontos',pt(runSnapshot.score)],['Votos',pt(runSnapshot.votesCollected)],['Benefícios',pt(runSnapshot.protectedBenefits)],['Melhor combo',`${pt(runSnapshot.bestCombo)} hits`],['Tempo',hms(runSnapshot.playTimeMs)],['Inimigos',pt(runSnapshot.enemiesDefeated)],['Fase',`${runSnapshot.phaseReached} · ${runSnapshot.phaseName}`],['Tariflávio',runSnapshot.bossDefeated?'Derrotado':'Não derrotado']];
   q('missionStats').replaceChildren(...pairs.map(([label,v])=>{const div=document.createElement('div');const name=document.createElement('span');name.textContent=label;const value=document.createElement('b');value.textContent=v;div.append(name,value);return div;}));
   q('missionBenefitTotal').textContent=`${pt(runSnapshot.bonusesCollected)} coletados`;
   q('missionBenefitRows').replaceChildren(...benefitsCatalog().map(b=>{
    const row=document.createElement('div');const count=runSnapshot.bonusCounts[b.id]||0;
    row.className='mission-benefit-row'+(count?'':' missing');
    const name=document.createElement('span');name.textContent=b.name;
    const amount=document.createElement('strong');amount.textContent=`× ${pt(count)}`;
    row.append(name,amount);return row;
   }));
   q('missionPlayerName').value=runSnapshot.playerName;regenerate();try{q('missionPlayerName').focus({preventScroll:true});}catch(_){}
  }
  function regenerate(){
   if(!runSnapshot||phase!=='results')return false;
   // Snapshot congelado. Apenas o nome pode ser alterado após o fim do jogo.
   result=makeSummary({...runSnapshot,playerName:safeText(q('missionPlayerName').value,26)});
   renderArt(preview,result,assets);generated=true;q('missionDownload').disabled=false;q('missionShare').disabled=false;
   q('missionActionStatus').textContent='Arte pronta para baixar ou compartilhar.';return true;
  }
  const filename=()=>`lula-correndo-pela-democracia-resultado-${(result?.playerName||'jogador').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-zA-Z0-9_-]+/g,'_').slice(0,26)}.png`;
  function getPngBlob(){return new Promise(resolve=>{try{preview.toBlob(b=>resolve(b),'image/png');}catch(e){console.warn('[Relatório] PNG indisponível',e);resolve(null);}});}
  async function download(){if(!regenerate())return false;
   const blob=await getPngBlob();if(!blob){q('missionActionStatus').textContent='Falha ao gerar PNG. Tente novamente.';return false;}
   const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=filename();document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);
   q('missionActionStatus').textContent='Imagem PNG preparada para download.';return true;
  }
  async function share(){if(!regenerate())return false;
   const blob=await getPngBlob();if(!blob){q('missionActionStatus').textContent='Não foi possível gerar o PNG.';return false;}
   const file=new File([blob],filename(),{type:'image/png'});
   if(navigator.share&&navigator.canShare&&navigator.canShare({files:[file]})){
    try{await navigator.share({files:[file],title:'Relatório da Missão',text:'Lula – Correndo pela Democracia'});
     q('missionActionStatus').textContent='Imagem enviada para o compartilhamento.';return true;
    }catch(err){if(err?.name==='AbortError'){q('missionActionStatus').textContent='Compartilhamento cancelado.';return false;}
     console.warn('[Relatório] Compartilhamento indisponível, usando download:',err);}
   }
   q('missionActionStatus').textContent='Seu navegador não compartilha PNG diretamente. Baixando a imagem.';
   const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=filename();document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);
   return false;
  }
  function reset(){cancelAnimationFrame(raf);raf=0;epilogue?.stop();phaseStart=0;phase='hidden';result=null;runSnapshot=null;generated=false;frozenScene=null;
   root.classList.add('hidden');fx.classList.remove('hidden');q('missionSkip').classList.remove('hidden');panel.classList.add('hidden');q('missionActionStatus').textContent='';
   if(oldFocus&&oldFocus.isConnected){try{oldFocus.focus({preventScroll:true})}catch(_){}}oldFocus=null;}
  function show(snapshot,{skipAnimation=false,backdropCanvas=null}={}){
   if(phase!=='hidden')return false; // Nunca ativar duas vezes para a mesma partida.
   runSnapshot=makeSummary(snapshot); // Captura única de estatísticas (não são alteradas pelo relatório).
   oldFocus=document.activeElement;root.classList.remove('hidden');panel.classList.add('hidden');fx.classList.remove('hidden');q('missionSkip').classList.remove('hidden');
   resizeFx();if(backdropCanvas){try{frozenScene=document.createElement('canvas');frozenScene.width=backdropCanvas.width;frozenScene.height=backdropCanvas.height;
    frozenScene.getContext('2d').drawImage(backdropCanvas,0,0);}catch(err){frozenScene=null;console.warn('[Epílogo] Não foi possível capturar cenário:',err);}}
   if(skipAnimation){beginResults();return true;}
   phase=runSnapshot.result==='victory'?'victory':'defeat';phaseStart=0;if(phase==='victory')epilogue?.cheers();
   raf=requestAnimationFrame(animationFrame);return true;
  }
  for(const pic of Object.values(assets)){if(pic&&typeof pic.addEventListener==='function')pic.addEventListener('load',()=>{if(phase==='results')regenerate();},{once:true});}
  q('missionGenerate').addEventListener('click',regenerate);q('missionDownload').addEventListener('click',download);q('missionShare').addEventListener('click',share);
  q('missionPlayerName').addEventListener('input',()=>{if(phase==='results')regenerate();});
  q('missionSkip').addEventListener('click',beginResults);
  q('missionReplay').addEventListener('click',()=>{reset();onRestart();});q('missionHome').addEventListener('click',()=>{reset();onHome();});
  root.addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();if(phase!=='results')beginResults();}if(e.key==='Enter'&&e.target===q('missionPlayerName')){e.preventDefault();regenerate();}});
  window.addEventListener('resize',()=>{if(['victory','defeat','star'].includes(phase))resizeFx();});
  return Object.freeze({show,reset,isActive:()=>phase!=='hidden',phase:()=>phase,summary:()=>result||runSnapshot,renderArt:(canvas,s)=>renderArt(canvas,s,assets),regenerate,download,share});
 }
 window.GameMissionReport=Object.freeze({create,renderArt,makeSummary,WIDTH,HEIGHT});
})();
