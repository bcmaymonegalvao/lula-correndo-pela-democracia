/* Diálogo inicial — Lula: Correndo pela Democracia | módulo sem dependências */
(function(global){
  'use strict';
  const LINES = Object.freeze([
    {speaker:'Janones', image:'assets/story/intro/janones.webp', accent:'#5db8ff', text:'Presidente Lula, URGENTE! O Tariflávio está à solta!'},
    {speaker:'Jones Manoel', image:'assets/story/intro/jones.webp', accent:'#f2d27d', text:'Ele soltou seu tesouraço e está saqueando as terras raras do povo brasileiro!'},
    {speaker:'Érika Hilton', image:'assets/story/intro/erika.webp', accent:'#fa8fd9', text:'Ele ameaça acabar com o Bolsa Família e com o SUS, além de instaurar uma república de milicianos!'},
    {speaker:'Ana Eliza', image:'assets/story/intro/ana_eliza.webp', accent:'#f889ba', text:'Não podemos deixar que ataquem os direitos do povo brasileiro!'},
    {speaker:'Lula', image:'assets/story/intro/lula.png', accent:'#ffe486', text:'Vamos, companheiras e companheiros! Não vamos deixar que saqueiem o povo brasileiro! Que brilhe uma estrela vermelha!', star:true}
  ]);
  const q = (el, selector) => el.querySelector(selector);
  function create({scene, onFinish=()=>{}, speed=46}={}) {
    if(!scene)throw new Error('OpeningDialogue: informe o elemento scene');
    const node=document.createElement('section');
    node.className='opening-dialogue hidden';
    node.setAttribute('role','dialog');
    node.setAttribute('aria-modal','true');
    node.setAttribute('aria-label','Conversa no início da fase');
    node.innerHTML=`
      <div class="opening-dim"></div>
      <div class="opening-caption"><span class="opening-label">PRÓLOGO • BRASÍLIA</span><span class="opening-count">1 / 5</span></div>
      <div class="opening-star" aria-hidden="true"><i></i><i></i><i></i></div>
      <div class="opening-panel">
        <div class="opening-headshot"><img alt="" src="assets/story/intro/janones.webp"/></div>
        <div class="opening-copy"><div class="opening-name">JANONES</div><p class="opening-text"></p><div class="opening-hint">Toque ou pressione Enter / Espaço para continuar</div></div>
        <button class="opening-next" type="button" aria-label="Avançar diálogo">▶</button>
      </div>
      <button class="opening-skip" type="button">Pular diálogo ↠</button>
    `;
    scene.appendChild(node);
    const image=q(node,'.opening-headshot img'), name=q(node,'.opening-name');
    const message=q(node,'.opening-text'), hint=q(node,'.opening-hint');
    const progress=q(node,'.opening-count'), next=q(node,'.opening-next'), skip=q(node,'.opening-skip');
    let active=false, index=0, visible=0, elapsed=0, finishing=0;
    const characters=Array.from(LINES);
    const formatSpeaker=(s)=>s.toLocaleUpperCase('pt-BR');
    function displayLine(){
      const item=characters[index]; visible=0; elapsed=0;
      image.src=item.image; image.alt='Retrato em pixel art de '+item.speaker;
      name.textContent=formatSpeaker(item.speaker); message.textContent='';
      progress.textContent=`${index+1} / ${characters.length}`;
      node.style.setProperty('--opening-accent',item.accent);
      node.classList.toggle('opening-lula',Boolean(item.star));
      hint.textContent='Toque ou pressione Enter / Espaço para continuar';
      next.textContent='▶';
    }
    function stop(){
      if(!active)return;
      active=false;finishing=0;node.classList.add('hidden');
      node.classList.remove('opening-finishing','opening-star-active','opening-lula');
      onFinish();
    }
    function star(){
      node.classList.remove('opening-star-active');
      void node.offsetWidth; // reinicia a animação caso a fase seja reiniciada
      node.classList.add('opening-star-active');
    }
    function advance(){
      if(!active||finishing)return;
      const item=characters[index];
      if(visible<item.text.length){
        visible=item.text.length;message.textContent=item.text;
        if(item.star)star();
        return;
      }
      if(index===characters.length-1){
        if(!node.classList.contains('opening-star-active'))star();
        finishing=0.0001;
        node.classList.add('opening-finishing');
        hint.textContent='A estrela brilha!';
        return;
      }
      index++;displayLine();
    }
    function update(dt){
      if(!active)return;
      dt=Math.min(.1,Math.max(0,Number(dt)||0));
      if(finishing){finishing+=dt;if(finishing>=1.0)stop();return;}
      const item=characters[index];
      if(visible>=item.text.length)return;
      elapsed+=dt;
      const count=Math.min(item.text.length,Math.floor(elapsed*speed));
      if(count!==visible){visible=count;message.textContent=item.text.slice(0,count);
        if(item.star && visible===item.text.length)star();
      }
    }
    function begin(){
      active=true;finishing=0;index=0;
      node.classList.remove('hidden','opening-finishing','opening-star-active');
      displayLine();
      next.focus({preventScroll:true});
    }
    function keyHandler(e){
      if(!active)return;
      if(['Enter',' ','ArrowRight'].includes(e.key)){
        if(e.repeat)return;
        e.preventDefault();e.stopPropagation();advance();
      }else if(e.key==='Escape'){
        e.preventDefault();e.stopPropagation();stop();
      }else if(['arrowup','arrowdown','w','s','z','x','c','l','v','p'].includes(e.key.toLowerCase())){
        e.preventDefault();e.stopPropagation();
      }
    }
    // captura o teclado antes dos handlers de pulo, combo, pausa e especial do jogo
    document.addEventListener('keydown',keyHandler,true);
    next.addEventListener('click',advance);
    q(node,'.opening-panel').addEventListener('click', (e)=>{if(!e.target.closest('button'))advance();});
    skip.addEventListener('click',stop);
    return {begin, update, skip:stop, advance, isActive:()=>active,
      destroy:()=>{document.removeEventListener('keydown',keyHandler,true);node.remove();},
      get currentIndex(){return index;}, get fullText(){return characters[index]?.text||'';}};
  }
  global.OpeningDialogue = { create, lines:LINES };
})(window);
