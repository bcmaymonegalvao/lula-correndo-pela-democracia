/* Epílogo cinematográfico independente — Alpha 0.9.5.
 * Só desenha sobre o estado congelado; não altera física, HP nem estatísticas.
 * API: GameEpilogueCinematic.create({...}).draw(ctx, w, h, scene, elapsedMs, frozenCanvas)
 */
(() => {
  'use strict';
  const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
  const ease=v=>{v=clamp(v,0,1);return v*v*(3-2*v);};
  const pathStar=(ctx,r)=>{ctx.beginPath();for(let i=0;i<10;i++){
   const a=-Math.PI/2+i*Math.PI/5,rad=i%2?r*.42:r;
   const x=Math.cos(a)*rad,y=Math.sin(a)*rad;
   i?ctx.lineTo(x,y):ctx.moveTo(x,y);
  }ctx.closePath();};
  const ready=im=>!!im&&im.complete&&im.naturalWidth>0;
  const fetchImage=src=>{if(!src)return null;if(typeof src!=='string')return src;
   const im=new Image();im.decoding='async';im.src=src;return im;};
  function create({lula,celebrate,portrait,background,crowd=[],celebrateFrames=[],defeatFrames=[],applause=null,audio=true}={}){
   const a={lula:fetchImage(lula),celebrate:fetchImage(celebrate),portrait:fetchImage(portrait),background:fetchImage(background),crowd:crowd.map(fetchImage),
    celebrateFrames:celebrateFrames.map(fetchImage),defeatFrames:defeatFrames.map(fetchImage)};
   const clip=applause?new Audio(applause):null;
   if(clip){clip.volume=.48;clip.preload='auto';}
   let talking=false;
   function voice(text){if(!audio||!('speechSynthesis'in window))return;
    try{window.speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);u.lang='pt-BR';u.rate=1.10;u.pitch=1.16;u.volume=.8;window.speechSynthesis.speak(u);}catch(e){console.warn('[Epílogo] Sem síntese de torcida',e);}
   }
   function cheers(){if(!audio||talking)return;talking=true;
    if(clip){try{clip.currentTime=0;clip.play().catch(()=>{});}catch(e){console.warn('[Epílogo] Áudio indisponível',e);}}
    voice('Parabéns, Lula! Você impediu o Tariflávio! O povo brasileiro venceu!');
   }
   function stop(){talking=false;if(clip){clip.pause();clip.currentTime=0;}if('speechSynthesis'in window){try{window.speechSynthesis.cancel();}catch(_){}}}
   function line(ctx,value,x,y,size,fill,outline,max){ctx.save();ctx.textAlign='center';ctx.textBaseline='middle';
    ctx.font=`1000 ${size}px system-ui,sans-serif`;ctx.lineWidth=Math.max(4,size*.13);ctx.lineJoin='round';
    ctx.strokeStyle=outline;ctx.strokeText(value,x,y,max);ctx.fillStyle=fill;ctx.fillText(value,x,y,max);ctx.restore();}
   function cover(ctx,img,w,h){if(!ready(img))return;const sc=Math.max(w/img.width,h/img.height),sw=w/sc,sh=h/sc;
    ctx.imageSmoothingEnabled=true;ctx.drawImage(img,(img.width-sw)/2,(img.height-sh)/2,sw,sh,0,0,w,h);ctx.imageSmoothingEnabled=false;}
   function base(ctx,w,h,frozen){ctx.clearRect(0,0,w,h);try{if(frozen&&frozen.width>0)ctx.drawImage(frozen,0,0,w,h);else if(ready(a.background))cover(ctx,a.background,w,h);}catch(e){console.warn('[Epílogo] Imagem de fundo indisponível:',e);}
    ctx.fillStyle='rgba(5,10,27,.46)';ctx.fillRect(0,0,w,h);
   }
   function drawVictory(ctx,w,h,age,frozen){base(ctx,w,h,frozen);
    const u=Math.min(w/960,h/540),bounce=Math.sin(age*.011);
    const glow=ctx.createRadialGradient(w*.5,h*.35,0,w*.5,h*.35,w*.55);
    glow.addColorStop(0,'#ffda8340');glow.addColorStop(1,'#ff001000');ctx.fillStyle=glow;ctx.fillRect(0,0,w,h);
    // Multidão animada atrás de Lula (sprites do jogo, não silhuetas temporárias).
    ctx.save();ctx.globalAlpha=.95;const ids=a.crowd.length;
    for(let i=0;i<Math.min(10,ids*2);i++){
     const pic=a.crowd[i%ids];if(!ready(pic))continue;
     const cw=Math.min(154*u,w*.20),ch=cw*(pic.height/pic.width);
     const x=w*(.03+i*.099),y=h*.90-ch-Math.abs(Math.sin(age*.007+i))*10*u;
     ctx.imageSmoothingEnabled=false;ctx.drawImage(pic,x,y,cw,ch);
    }ctx.restore();
    // Lula comemora, alternando quadros reais de salto e corrida.
    const heroFrame=a.celebrateFrames[Math.floor(age/170)%Math.max(1,a.celebrateFrames.length)];
    const hero=ready(heroFrame)?heroFrame:(ready(a.celebrate)?a.celebrate:a.lula);
    if(ready(hero)){const sw=205*u,sh=205*u;const y=h*.88-sh-Math.abs(Math.sin(age*.008))*25*u;
     ctx.imageSmoothingEnabled=false;ctx.drawImage(hero,w*.5-sw/2,y,sw,sh);}
    for(let i=0;i<90;i++){
      const x=((i*173.41+Math.sin(i)*23+age*.045*(1+i%4))%(w+40))-20;
      const y=((i*91.17+age*(.08+(i%5)*.025))%(h+60))-30;
      ctx.save();ctx.translate(x,y);ctx.rotate(age*.003+(i*7));ctx.fillStyle=['#ffdf84','#f1425b','#9fe7c9','#b5c8ff','#ffffff'][i%5];
      ctx.fillRect(-3*u,-5*u,6*u,11*u);ctx.restore();
    }
    const messages=['PARABÉNS, LULA!','VOCÊ IMPEDIU O TARIFLÁVIO!','O POVO BRASILEIRO VENCEU!'];
    const idx=age<1150?0:age<2400?1:2;
    ctx.save();ctx.globalAlpha=ease((age-(idx?idx===1?1150:2400:0))/260);
    line(ctx,messages[idx],w/2,h*.23,idx===1?38*u:46*u,'#ffdc88','#74192c',w*.94);
    line(ctx,'LULA!  LULA!  LULA!',w/2,h*.35,25*u,'#f4ffff','#084775',w*.88);
    ctx.restore();
   }
   function drawDefeat(ctx,w,h,age,frozen){base(ctx,w,h,frozen);
    ctx.fillStyle=`rgba(4,6,20,${Math.min(.64,age/1900*.60)})`;ctx.fillRect(0,0,w,h);
    const u=Math.min(w/960,h/540),idx=Math.min(3,Math.floor(age/380)),
     candidate=a.defeatFrames[idx],pic=ready(candidate)?candidate:(ready(a.lula)?a.lula:a.celebrate);
    if(ready(pic)){ctx.save();ctx.globalAlpha=.86;ctx.filter='grayscale(.65) brightness(.75)';ctx.imageSmoothingEnabled=false;
     const sw=192*u;ctx.drawImage(pic,w/2-sw/2,h*.78-sw+idx*7*u,sw,sw);ctx.restore();}
    if(age>200)line(ctx,'A LUTA CONTINUA!',w/2,h*.28,49*u,'#d2d9e9','#202d47',w*.90);
   }
   function drawStar(ctx,w,h,age,frozen){base(ctx,w,h,frozen);
    const p=ease(age/2100),u=Math.min(w/960,h/540),cx=w*.5,cy=h*.5;
    ctx.fillStyle=`rgba(6,3,22,${.2+.35*p})`;ctx.fillRect(0,0,w,h);
    for(let i=0;i<60;i++){
     const theta=i*2.39996+age*.002,rad=(40+i*5)*u*(1+p*.45);
     ctx.fillStyle=i%3?'#ffe39c':'#ffffff';ctx.fillRect(cx+Math.cos(theta)*rad,cy+Math.sin(theta)*rad,2+u*2,2+u*2);
    }
    // Estrela chega a preencher toda a tela, inclusive cantos, antes da troca.
    const radius=(60+Math.max(w,h)*1.5*Math.pow(p,2.2));
    ctx.save();ctx.translate(cx,cy);ctx.rotate(age*.0015);
    ctx.shadowColor='#ffb65a';ctx.shadowBlur=p>.85?0:26*u;
    pathStar(ctx,radius);ctx.fillStyle='#c61537';ctx.fill();ctx.shadowBlur=0;
    ctx.strokeStyle='#ffd37d';ctx.lineWidth=8*u;ctx.stroke();
    // Lula fica dentro do recorte da estrela, sem deformação.
    pathStar(ctx,radius*.89);ctx.clip();
    const pic=ready(a.portrait)?a.portrait:a.lula;
    if(ready(pic)){const s=Math.min(radius*1.38,Math.max(w,h)*1.25);
     ctx.rotate(-age*.0015);ctx.imageSmoothingEnabled=false;ctx.drawImage(pic,-s*.5,-s*.56,s,s);}
    ctx.restore();
    if(p>.90){ctx.fillStyle=`rgba(194,17,49,${ease((p-.90)/.10)})`;ctx.fillRect(0,0,w,h);}
   }
   function draw(ctx,w,h,phase,age,frozen){ctx.save();
    if(phase==='victory')drawVictory(ctx,w,h,age,frozen);
    else if(phase==='defeat')drawDefeat(ctx,w,h,age,frozen);
    else if(phase==='star')drawStar(ctx,w,h,age,frozen);
    ctx.restore();
   }
   return Object.freeze({draw,cheers,stop,assets:a,durations:Object.freeze({victory:3900,defeat:1600,star:2100})});
  }
  window.GameEpilogueCinematic=Object.freeze({create});
})();
