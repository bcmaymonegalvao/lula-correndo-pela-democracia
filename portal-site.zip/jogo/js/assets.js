/* Arte da Alpha 0.9.4: HUD refinada, Tesourinha refeita e NPCs temáticos atualizados. */
window.GAME_ASSETS = {
  "backgrounds": {
    "brasilia_dia": "assets/backgrounds/brasilia/brasilia_dia.webp",
    "brasilia_tarde": "assets/backgrounds/brasilia/brasilia_tarde.webp",
    "brasilia_entardecer": "assets/backgrounds/brasilia/brasilia_entardecer.webp",
    "brasilia_noite": "assets/backgrounds/brasilia/brasilia_noite.webp"
  },
  "bosses": {
    "final": [
      "assets/bosses/final/walk_01.webp?v=0.9.4",
      "assets/bosses/final/walk_02.webp?v=0.9.4",
      "assets/bosses/final/walk_03.webp?v=0.9.4",
      "assets/bosses/final/walk_04.webp?v=0.9.4",
      "assets/bosses/final/hit_01.webp?v=0.9.4",
      "assets/bosses/final/hit_02.webp?v=0.9.4",
      "assets/bosses/final/hit_03.webp?v=0.9.4",
      "assets/bosses/final/die_01.webp?v=0.9.4",
      "assets/bosses/final/die_02.webp?v=0.9.4",
      "assets/bosses/final/die_03.webp?v=0.9.4",
      "assets/bosses/final/die_04.webp?v=0.9.4"
]
  },
  "sprites": {
    "double_jump": [
      "assets/sprites/animacoes/double_jump/01.webp",
      "assets/sprites/animacoes/double_jump/02.webp",
      "assets/sprites/animacoes/double_jump/03.webp",
      "assets/sprites/animacoes/double_jump/04.webp",
      "assets/sprites/animacoes/double_jump/05.webp",
      "assets/sprites/animacoes/double_jump/06.webp",
      "assets/sprites/animacoes/double_jump/07.webp",
      "assets/sprites/animacoes/double_jump/08.webp"
    ],
    "enemy_die": [
      "assets/sprites/animacoes/enemy_die/01.webp?v=0.9.4",
      "assets/sprites/animacoes/enemy_die/02.webp?v=0.9.4",
      "assets/sprites/animacoes/enemy_die/03.webp?v=0.9.4",
      "assets/sprites/animacoes/enemy_die/04.webp?v=0.9.4",
      "assets/sprites/animacoes/enemy_die/05.webp?v=0.9.4",
      "assets/sprites/animacoes/enemy_die/06.webp?v=0.9.4",
      "assets/sprites/animacoes/enemy_die/07.webp?v=0.9.4",
      "assets/sprites/animacoes/enemy_die/08.webp?v=0.9.4"
    ],
    "enemy_hit": [
      "assets/sprites/animacoes/enemy_hit/01.webp?v=0.9.4",
      "assets/sprites/animacoes/enemy_hit/02.webp?v=0.9.4",
      "assets/sprites/animacoes/enemy_hit/03.webp?v=0.9.4",
      "assets/sprites/animacoes/enemy_hit/04.webp?v=0.9.4"
    ],
    "enemy_walk": [
      "assets/sprites/animacoes/enemy_walk/01.webp?v=0.9.4",
      "assets/sprites/animacoes/enemy_walk/02.webp?v=0.9.4",
      "assets/sprites/animacoes/enemy_walk/03.webp?v=0.9.4",
      "assets/sprites/animacoes/enemy_walk/04.webp?v=0.9.4",
      "assets/sprites/animacoes/enemy_walk/05.webp?v=0.9.4",
      "assets/sprites/animacoes/enemy_walk/06.webp?v=0.9.4",
      "assets/sprites/animacoes/enemy_walk/07.webp?v=0.9.4",
      "assets/sprites/animacoes/enemy_walk/08.webp?v=0.9.4",
      "assets/sprites/animacoes/enemy_walk/09.webp?v=0.9.4",
      "assets/sprites/animacoes/enemy_walk/10.webp?v=0.9.4",
      "assets/sprites/animacoes/enemy_walk/11.webp?v=0.9.4",
      "assets/sprites/animacoes/enemy_walk/12.webp?v=0.9.4"
    ],
    "flying_kick": [
      "assets/sprites/animacoes/flying_kick/01.webp",
      "assets/sprites/animacoes/flying_kick/02.webp",
      "assets/sprites/animacoes/flying_kick/03.webp",
      "assets/sprites/animacoes/flying_kick/04.webp",
      "assets/sprites/animacoes/flying_kick/05.webp",
      "assets/sprites/animacoes/flying_kick/06.webp",
      "assets/sprites/animacoes/flying_kick/07.webp",
      "assets/sprites/animacoes/flying_kick/08.webp"
    ],
    "front_punch": [
      "assets/sprites/animacoes/front_punch/01.webp",
      "assets/sprites/animacoes/front_punch/02.webp",
      "assets/sprites/animacoes/front_punch/03.webp",
      "assets/sprites/animacoes/front_punch/04.webp",
      "assets/sprites/animacoes/front_punch/05.webp",
      "assets/sprites/animacoes/front_punch/06.webp",
      "assets/sprites/animacoes/front_punch/07.webp",
      "assets/sprites/animacoes/front_punch/08.webp"
    ],
    "jump": [
      "assets/sprites/animacoes/jump/01.webp",
      "assets/sprites/animacoes/jump/02.webp",
      "assets/sprites/animacoes/jump/03.webp",
      "assets/sprites/animacoes/jump/04.webp",
      "assets/sprites/animacoes/jump/05.webp",
      "assets/sprites/animacoes/jump/06.webp",
      "assets/sprites/animacoes/jump/07.webp",
      "assets/sprites/animacoes/jump/08.webp",
      "assets/sprites/animacoes/jump/09.webp",
      "assets/sprites/animacoes/jump/10.webp",
      "assets/sprites/animacoes/jump/11.webp",
      "assets/sprites/animacoes/jump/12.webp"
    ],
    "run": [
      "assets/sprites/animacoes/run/01.webp",
      "assets/sprites/animacoes/run/02.webp",
      "assets/sprites/animacoes/run/03.webp",
      "assets/sprites/animacoes/run/04.webp",
      "assets/sprites/animacoes/run/05.webp",
      "assets/sprites/animacoes/run/06.webp",
      "assets/sprites/animacoes/run/07.webp",
      "assets/sprites/animacoes/run/08.webp"
    ],
    "left_punch": [
      "assets/sprites/animacoes/left_punch/01.webp",
      "assets/sprites/animacoes/left_punch/02.webp",
      "assets/sprites/animacoes/left_punch/03.webp",
      "assets/sprites/animacoes/left_punch/04.webp",
      "assets/sprites/animacoes/left_punch/05.webp",
      "assets/sprites/animacoes/left_punch/06.webp",
      "assets/sprites/animacoes/left_punch/07.webp",
      "assets/sprites/animacoes/left_punch/08.webp"
    ]
  },
  "impacts": {
    "left_punch": [
      "assets/sprites/fx08/left_punch/01.webp",
      "assets/sprites/fx08/left_punch/02.webp",
      "assets/sprites/fx08/left_punch/03.webp",
      "assets/sprites/fx08/left_punch/04.webp"
    ],
    "front_punch": [
      "assets/sprites/fx08/front_punch/01.webp",
      "assets/sprites/fx08/front_punch/02.webp",
      "assets/sprites/fx08/front_punch/03.webp",
      "assets/sprites/fx08/front_punch/04.webp"
    ],
    "flying_kick": [
      "assets/sprites/fx08/flying_kick/01.webp",
      "assets/sprites/fx08/flying_kick/02.webp",
      "assets/sprites/fx08/flying_kick/03.webp",
      "assets/sprites/fx08/flying_kick/04.webp"
    ],
    "jump": [
      "assets/sprites/fx08/jump/01.webp",
      "assets/sprites/fx08/jump/02.webp",
      "assets/sprites/fx08/jump/03.webp",
      "assets/sprites/fx08/jump/04.webp"
    ],
    "double_jump": [
      "assets/sprites/fx08/double_jump/01.webp",
      "assets/sprites/fx08/double_jump/02.webp",
      "assets/sprites/fx08/double_jump/03.webp",
      "assets/sprites/fx08/double_jump/04.webp"
    ]
  },
  "estrelaPovo": {
  "golpe_1": [
    "assets/sprites/effects/estrela_povo/golpe_1/01.png",
    "assets/sprites/effects/estrela_povo/golpe_1/02.png",
    "assets/sprites/effects/estrela_povo/golpe_1/03.png",
    "assets/sprites/effects/estrela_povo/golpe_1/04.png"
  ],
  "golpe_2": [
    "assets/sprites/effects/estrela_povo/golpe_2/01.png",
    "assets/sprites/effects/estrela_povo/golpe_2/02.png",
    "assets/sprites/effects/estrela_povo/golpe_2/03.png",
    "assets/sprites/effects/estrela_povo/golpe_2/04.png"
  ],
  "golpe_3": [
    "assets/sprites/effects/estrela_povo/golpe_3/01.png",
    "assets/sprites/effects/estrela_povo/golpe_3/02.png",
    "assets/sprites/effects/estrela_povo/golpe_3/03.png",
    "assets/sprites/effects/estrela_povo/golpe_3/04.png"
  ],
  "golpe_4": [
    "assets/sprites/effects/estrela_povo/golpe_4/01.png",
    "assets/sprites/effects/estrela_povo/golpe_4/02.png",
    "assets/sprites/effects/estrela_povo/golpe_4/03.png",
    "assets/sprites/effects/estrela_povo/golpe_4/04.png"
  ]
},
  "bossDust": [
    "assets/sprites/fx_dust/dust_01.webp",
    "assets/sprites/fx_dust/dust_02.webp",
    "assets/sprites/fx_dust/dust_03.webp",
    "assets/sprites/fx_dust/dust_04.webp"
  ],
  "bossMinions": {
    "miliciano": [
      "assets/sprites/boss_minions/miliciano/walk1.webp",
      "assets/sprites/boss_minions/miliciano/walk2.webp",
      "assets/sprites/boss_minions/miliciano/attack.webp",
      "assets/sprites/boss_minions/miliciano/dead.webp"
    ],
    "petroleo": [
      "assets/sprites/boss_minions/petroleo/walk1.webp",
      "assets/sprites/boss_minions/petroleo/walk2.webp",
      "assets/sprites/boss_minions/petroleo/attack.webp",
      "assets/sprites/boss_minions/petroleo/dead.webp"
    ],
    "desmatamento": [
      "assets/sprites/boss_minions/desmatamento/walk1.webp",
      "assets/sprites/boss_minions/desmatamento/walk2.webp",
      "assets/sprites/boss_minions/desmatamento/attack.webp",
      "assets/sprites/boss_minions/desmatamento/dead.webp"
    ],
    "terras_raras": [
      "assets/sprites/boss_minions/terras_raras/walk1.webp",
      "assets/sprites/boss_minions/terras_raras/walk2.webp",
      "assets/sprites/boss_minions/terras_raras/attack.webp",
      "assets/sprites/boss_minions/terras_raras/dead.webp"
    ],
    "fake_news": [
      "assets/sprites/boss_minions/fake_news/walk1.webp",
      "assets/sprites/boss_minions/fake_news/walk2.webp",
      "assets/sprites/boss_minions/fake_news/attack.webp",
      "assets/sprites/boss_minions/fake_news/dead.webp"
    ],
    "orcamento_secreto": [
      "assets/sprites/boss_minions/orcamento_secreto/walk1.webp",
      "assets/sprites/boss_minions/orcamento_secreto/walk2.webp",
      "assets/sprites/boss_minions/orcamento_secreto/attack.webp",
      "assets/sprites/boss_minions/orcamento_secreto/dead.webp"
    ],
  },
  "vote": "assets/sprites/coletaveis/voto.webp",
  "bonusAtlas": "assets/sprites/coletaveis/bonus_13x4.webp",
  "foreground": {
  "street": "assets/foreground/rua_brasilia_loop.webp"
},
  "sceneryNpcs": {
  "eleitores_l": [
    "assets/sprites/npc_rgba_v5/eleitores_l/frame_01.png",
    "assets/sprites/npc_rgba_v5/eleitores_l/frame_02.png",
    "assets/sprites/npc_rgba_v5/eleitores_l/frame_03.png",
    "assets/sprites/npc_rgba_v5/eleitores_l/frame_04.png"
  ],
  "trompetista": [
    "assets/sprites/npc_rgba_v5/trompetista/frame_01.png",
    "assets/sprites/npc_rgba_v5/trompetista/frame_02.png",
    "assets/sprites/npc_rgba_v5/trompetista/frame_03.png",
    "assets/sprites/npc_rgba_v5/trompetista/frame_04.png"
  ],
  "vira_voto": [
    "assets/sprites/npc_rgba_v5/vira_voto/frame_01.png",
    "assets/sprites/npc_rgba_v5/vira_voto/frame_02.png",
    "assets/sprites/npc_rgba_v5/vira_voto/frame_03.png",
    "assets/sprites/npc_rgba_v5/vira_voto/frame_04.png"
  ],
  "amor_contra_odio": [
    "assets/sprites/npc_rgba_v5/amor_contra_odio/frame_01.png",
    "assets/sprites/npc_rgba_v5/amor_contra_odio/frame_02.png",
    "assets/sprites/npc_rgba_v5/amor_contra_odio/frame_03.png",
    "assets/sprites/npc_rgba_v5/amor_contra_odio/frame_04.png"
  ],
  "artista_pop": [
    "assets/sprites/npc_rgba_v5/artista_pop/frame_01.png",
    "assets/sprites/npc_rgba_v5/artista_pop/frame_02.png",
    "assets/sprites/npc_rgba_v5/artista_pop/frame_03.png",
    "assets/sprites/npc_rgba_v5/artista_pop/frame_04.png"
  ],
  "artista_tropical": [
    "assets/sprites/npc_rgba_v5/artista_tropical/frame_01.png",
    "assets/sprites/npc_rgba_v5/artista_tropical/frame_02.png",
    "assets/sprites/npc_rgba_v5/artista_tropical/frame_03.png",
    "assets/sprites/npc_rgba_v5/artista_tropical/frame_04.png"
  ],
  "artista_cancioneiro": [
    "assets/sprites/npc_rgba_v5/artista_cancioneiro/frame_01.png",
    "assets/sprites/npc_rgba_v5/artista_cancioneiro/frame_02.png",
    "assets/sprites/npc_rgba_v5/artista_cancioneiro/frame_03.png",
    "assets/sprites/npc_rgba_v5/artista_cancioneiro/frame_04.png"
  ]
},
  "sidewalkRunners": {
  "corredor_joinha": [
    "assets/sprites/sidewalk_runners/corredor_joinha/run_01.webp",
    "assets/sprites/sidewalk_runners/corredor_joinha/run_02.webp",
    "assets/sprites/sidewalk_runners/corredor_joinha/run_03.webp",
    "assets/sprites/sidewalk_runners/corredor_joinha/run_04.webp",
    "assets/sprites/sidewalk_runners/corredor_joinha/run_05.webp",
    "assets/sprites/sidewalk_runners/corredor_joinha/run_06.webp",
    "assets/sprites/sidewalk_runners/corredor_joinha/run_07.webp",
    "assets/sprites/sidewalk_runners/corredor_joinha/run_08.webp"
  ],
  "caminhao": [
    "assets/sprites/sidewalk_runners/caminhao/run_01.webp",
    "assets/sprites/sidewalk_runners/caminhao/run_02.webp",
    "assets/sprites/sidewalk_runners/caminhao/run_03.webp",
    "assets/sprites/sidewalk_runners/caminhao/run_04.webp"
  ]
}
};

window.NPC_SPRITE_BUILD = "RGBA_V5_20261024_CLOUDFLARE_QA";
