/* Lula – Correndo pela Democracia | Trilha da homepage
   Respeita restrições de autoplay: se o navegador bloquear som automático,
   o visitante pode tocar em "Ativar música". Nunca inicia ao navegar para o jogo.
   Arquivo isolado: nenhuma alteração no código ou no áudio da Alpha 0.9.5. */
(()=>{
  'use strict';
  const audio = document.getElementById('portal-home-audio');
  const control = document.getElementById('portal-music-button');
  const status = document.getElementById('portal-music-status');
  if (!audio || !control) return;
  audio.volume = .36;
  audio.loop = true;
  let wanted = false;
  let pausedByUser = false;
  let pending = false;
  let lastError = false;
  const isHome = () => !location.hash || /^#\/?(?:inicio(?:\/.*)?)?$/.test(location.hash);
  const label = (s) => { if (status) status.textContent = s; };

  const update = () => {
    const playing = !audio.paused;
    control.classList.toggle('is-playing', playing);
    control.setAttribute('aria-pressed', String(playing));
    control.setAttribute('aria-label', playing ? 'Pausar trilha da homepage' : 'Ativar trilha da homepage');
    const icon = control.querySelector('[data-music-icon]');
    const text = control.querySelector('[data-music-text]');
    if (icon) icon.textContent = playing ? '♫' : '▶';
    if (text) text.textContent = playing ? 'PAUSAR MÚSICA' : (lastError ? 'TENTAR NOVAMENTE' : 'ATIVAR MÚSICA');
    control.hidden = !isHome();
  };

  async function start(userRequested = false) {
    if (!isHome() || pending || !audio.paused) return;
    pending = true;
    if (userRequested) {
      wanted = true;
      pausedByUser = false;
    }
    try {
      await audio.play();
      wanted = true;
      pausedByUser = false;
      lastError = false;
      label('Trilha da homepage tocando.');
    } catch (error) {
      if (error?.name === 'NotAllowedError') {
        label('Para ouvir a trilha, clique em Ativar música.');
      } else if (error?.name === 'AbortError') {
        // Interrupcao normal: o usuario pausou o audio antes do play concluir.
      } else {
        lastError = true;
        label('Não foi possível reproduzir a trilha.');
      }
    } finally {
      pending = false;
      update();
    }
  }

  control.addEventListener('click', () => {
    if (!audio.paused) {
      audio.pause();
      pausedByUser = true;
      label('Trilha da homepage pausada.');
      update();
      return;
    }
    void start(true);
  });

  audio.addEventListener('play', update);
  audio.addEventListener('pause', update);
  audio.addEventListener('error', () => {
    lastError = true;
    label('Erro ao carregar a música de fundo.');
    update();
  });

  const routeChange = () => {
    if (!isHome()) {
      audio.pause();
    } else if (wanted && !pausedByUser && !document.hidden) {
      void start();
    }
    update();
  };
  window.addEventListener('hashchange', routeChange);
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) audio.pause();
    else if (isHome() && wanted && !pausedByUser) void start();
  });
  document.addEventListener('click', (event) => {
    if (event.target.closest('a[href="./jogo/"]')) audio.pause();
  }, true);
  document.addEventListener('click', (event) => {
    if (event.target.closest('[data-v12-replay]') && wanted && !pausedByUser) {
      audio.currentTime = 0; // sincronizar reinício da música ao rever a V12
      void start();
    }
  });
  update();
  // Tentativa discreta: navegadores que bloqueiam autoplay exigirão o botão.
  // Deixa a página silenciosa se a tentativa for rejeitada.
  if (isHome()) void start();
})();
