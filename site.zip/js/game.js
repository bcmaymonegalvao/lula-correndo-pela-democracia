/* Lula - Correndo pela Democracia — Runner 2D para celular.
   Motor de jogo em JavaScript/Canvas; os cenários urbanos são desenhados em drawCapital().
   Protótipo. Imagens regionais e sprites são arquivos separados. */
(()=>{
'use strict';
const assets=window.GAME_ASSETS;
if(!assets) throw Error('assets.js deve ser carregado antes de game.js');
const $=id=>document.getElementById(id);
const cv=$('canvas'), ctx=cv.getContext('2d',{alpha:false});
const el={start:$('start'),game:$('game'),scene:$('scene'),startBtn:$('startBtn'),cover:$('coverImg'),score:$('score'),clock:$('clock'),bar:$('bar'),hearts:$('hearts'),region:$('region'),story:$('story'),storyLabel:$('storyLabel'),storyText:$('storyText'),veil:$('veil'),veilTitle:$('veilTitle'),veilText:$('veilText'),resultData:$('resultData'),resume:$('resume'),restart:$('restart'),home:$('home'),finalScore:$('finalScore'),finalMemory:$('finalMemory'),finalProgress:$('finalProgress'),memoryList:$('memoryList'),pause:$('pause')};
let Cw=390,Ch=600,G=460, px=95, playerH=104, images={backgrounds:{},sprites:{}}, loadDone=false;
let frame=0,last=0,runClock=0;
const TOTAL=180, SPEED=230;
const MEMORIES=window.MEMORIAS_QUIZ;
const phases=window.FASES_BRASIL.map(p=>({...p}));
let cursor=0;for(const p of phases){p.start=cursor;p.startX=cursor*SPEED;cursor+=p.seconds;p.end=cursor;p.endX=cursor*SPEED;}const LENGTH=cursor*SPEED;
let checkpoint=null, jumpBuffer=0, coyote=0, landing=0, jumpAge=0, particles=[], finishTime=0;
const combat=window.GameCombat.create();
const animator=window.GameAnimation;
const state={jumpsUsed:0,flagUnlocked:false,playing:false,paused:false,ended:false,elapsed:0,score:0,lives:3,world:0,inv:0,playerY:0,vY:0,onGround:true,anim:0,attack:'',attackLeft:0,attackHit:false,toast:0,toastId:0,phase:'',collected:[],obj:[],pickup:[]};
const rng=(seed)=>{let x=seed>>>0;return ()=>{x=(1664525*x+1013904223)>>>0;return x/4294967296;};};
function createLevel(){
 state.obj=[];state.pickup=[];const R=rng(42613);let m=0;
 for(const p of phases){
   if(p.city){state.pickup.push({x:p.startX+390,y:78,kind:'scroll',id:m++});state.obj.push({x:p.startX+620,w:37,h:32,type:'crate',done:false});continue;}
   const s=p.startX, width=p.endX-p.startX;
   for(let x=670;x<width-800;x+=470+Math.round(R()*130)){
      const ty=R();
      const type=ty<.20?'gap':ty<.42?'platform':ty<.65?'crate':ty<.82?'log':'barrier';
      const w=type==='gap'?105:type==='platform'?150:type==='log'?72:type==='crate'?45:35;
      state.obj.push({x:s+x,w,h:type==='platform'?64:type==='crate'?46:36,type,done:false});
      if(R()>.38)state.pickup.push({x:s+x+46,y:type==='gap'?143:125,kind:'gem',id:m++});
   }
   for(let x=350;x<width-200;x+=720){state.pickup.push({x:s+x,y:85+(m%3)*22,kind:'scroll',id:m++});}
 }
}
function getPhase(t){for(const p of phases)if(t<p.end)return p;return phases.at(-1);}
function resize(){
  if(el.scene.getBoundingClientRect().height<10)return;
  const r=el.scene.getBoundingClientRect();const dpr=Math.min(1.75,window.devicePixelRatio||1);
  Cw=960;Ch=540;cv.width=Math.round(r.width*dpr);cv.height=Math.round(r.height*dpr);
  const scale=Math.min(cv.width/Cw,cv.height/Ch);
  ctx.setTransform(scale,0,0,scale,(cv.width-Cw*scale)/2,(cv.height-Ch*scale)/2);ctx.imageSmoothingEnabled=false;
  G=420;px=190;playerH=110;
  if(state.onGround)state.playerY=G;
  render();
}
function drawImageCover(img,sourceProgress=0,alpha=1){
 if(!img||!img.width)return;
 // scale to canvas height so ground of landscape and game ground coincide
 const scale=Math.max(Ch/img.height,Cw/img.width), sw=img.width*scale, travel=Math.max(0,sw-Cw);
 const xx=-travel*Math.max(0,Math.min(1,sourceProgress));ctx.globalAlpha*=alpha;
 ctx.drawImage(img,xx,0,sw,img.height*scale);
}
function drawBackdrop(phase){
  if(!phase.city){
    const img=images.backgrounds[phase.id];const progress=(state.world-phase.startX)/(phase.endX-phase.startX);
    drawImageCover(img,Math.max(0,Math.min(1,progress)),1);
  }else{drawCapital(phase);}
}
function background(phase){
 const i=phases.indexOf(phase), t=state.elapsed-phase.start;
 if(i>0&&t<1.4){drawBackdrop(phases[i-1]);ctx.save();ctx.globalAlpha=t/1.4;drawBackdrop(phase);ctx.restore();}
 else drawBackdrop(phase);
 // Separate moving sky, intermediate vegetation and near-road layers.
 ctx.fillStyle='#ffffff55';for(let i=0;i<7;i++){const x=((i*211-state.world*.04)%1200+1200)%1200-120;ctx.fillRect(x,100+i%3*15,65,6);}
 for(let i=0;i<8;i++){const x=((i*170-state.world*.24)%1360+1360)%1360-170;if(!phase.city)tree(x,G,0.28);}
 if(state.elapsed>175){const x=Math.max(410,1050-(state.elapsed-175)*128);ctx.fillStyle='#f5f1de';ctx.fillRect(x,G-136,370,15);ctx.fillRect(x+5,G-40,360,13);ctx.fillStyle='#79aabd';ctx.fillRect(x+20,G-118,330,72);ctx.strokeStyle='#fff9de';ctx.lineWidth=8;for(let n=0;n<7;n++){ctx.beginPath();ctx.moveTo(x+22+n*50,G-129);ctx.quadraticCurveTo(x+48+n*50,G-72,x+22+n*50,G-28);ctx.stroke();}ctx.fillStyle='#142c3b';ctx.font='bold 14px system-ui';ctx.fillText('PALÁCIO DO PLANALTO',x+90,G-145);}
}
function building(x,y,w,h,c){ctx.fillStyle=c;ctx.fillRect(x,y-h,w,h);ctx.fillStyle='#b4d9eb90';const step=Math.max(9,Math.round(w/7));for(let xx=x+7;xx<x+w-7;xx+=step)for(let yy=y-h+12;yy<y-10;yy+=19)ctx.fillRect(xx,yy,5,7);}
function palm(x,y,s){ctx.save();ctx.translate(x,y);ctx.scale(s,s);ctx.fillStyle='#6c432c';ctx.fillRect(-5,-88,10,90);ctx.fillStyle='#296c4d';for(let i=0;i<7;i++){ctx.save();ctx.rotate((i-3)*.35);ctx.beginPath();ctx.ellipse(0,-87,45,11,0,0,Math.PI*2);ctx.fill();ctx.restore()}ctx.restore();}
function tree(x,y,s){ctx.save();ctx.translate(x,y);ctx.scale(s,s);ctx.fillStyle='#61452a';ctx.fillRect(-7,-75,14,80);ctx.fillStyle='#39824d';for(let i=0;i<5;i++){ctx.beginPath();ctx.arc((i-2)*18,-85-(i%2)*8,24,0,Math.PI*2);ctx.fill()}ctx.restore();}
function drawCapital(p){
 let paint={curitiba:['#71bee6','#97c69d','#32604b'],manaus:['#58b2eb','#61a28d','#185e5e'],cuiaba:['#71b9ec','#a6af70','#586d46'],saopaulo:['#6b95c3','#7b8eaa','#394b6d'],salvador:['#5ebdf1','#e4c17d','#4b92bc']}[p.id];
 const sky=ctx.createLinearGradient(0,0,0,G);sky.addColorStop(0,paint[0]);sky.addColorStop(.65,paint[1]);sky.addColorStop(1,paint[2]);ctx.fillStyle=sky;ctx.fillRect(0,0,Cw,Ch);
 ctx.fillStyle='#eff7e999';for(let i=0;i<5;i++){let x=(i*199+93-state.world*.045)%(Cw+180)-90;ctx.beginPath();ctx.ellipse(x,G*.2+(i%2)*28,55,13,0,0,Math.PI*2);ctx.fill();}
 let offset=state.world*.28;
 const palette=['#405774','#344762','#253a55','#526784'];
 for(let layer=0;layer<2;layer++){
   for(let i=-2;i<Cw/65+4;i++){
      const x=i*77-(offset*(.20+layer*.19)%77),h=G*(.22+.22*(Math.sin(i*7.8+layer*5)+1)/2);
      building(x,G,62,h,palette[(i+30+layer*3)%palette.length]);
   }
 }
 const X=Cw*.43,Y=G,SC=Math.min(1.45,Math.max(.55,Cw/550));
 ctx.save();ctx.translate(X,Y);ctx.scale(SC,SC);
 if(p.id==='curitiba'){
   // Jardim Botânico de Curitiba — estufa de vidro
   ctx.fillStyle='#accbc9';ctx.fillRect(-96,-136,194,126);
   ctx.strokeStyle='#daf5e7';ctx.lineWidth=5;ctx.strokeRect(-96,-136,194,126);
   for(let k=-2;k<=2;k++){ctx.beginPath();ctx.moveTo(k*37,-12);ctx.lineTo(k*26,-136);ctx.stroke();}
   ctx.beginPath();ctx.moveTo(-104,-132);ctx.quadraticCurveTo(0,-260,105,-132);ctx.stroke();tree(-170,0,.9);tree(167,0,.95);
 }else if(p.id==='manaus'){
   // Teatro Amazonas
   ctx.fillStyle='#f2d39e';ctx.fillRect(-110,-114,220,110);ctx.fillStyle='#d58960';ctx.fillRect(-125,-124,250,16);
   ctx.fillStyle='#9c74a4';ctx.beginPath();ctx.arc(0,-128,67,Math.PI,Math.PI*2);ctx.fill();
   for(let n=0;n<6;n++){ctx.fillStyle=n%2?'#9dc8b0':'#d7e4db';ctx.fillRect(-66+n*22,-160,15,32)}
   ctx.fillStyle='#6a3f33';for(let n=0;n<6;n++)ctx.fillRect(-93+n*34,-93,17,72);palm(-176,0,.85);palm(174,0,.85);
 }else if(p.id==='cuiaba'){
   // Centro histórico e igrejas de Cuiabá
   ctx.fillStyle='#f0dfc1';ctx.fillRect(-103,-118,206,113);
   ctx.fillRect(-140,-162,39,158);ctx.fillRect(104,-162,39,158);
   ctx.fillStyle='#cc9878';ctx.fillRect(-153,-173,66,17);ctx.fillRect(91,-173,66,17);
   ctx.fillStyle='#61432d';ctx.fillRect(-25,-70,50,64);for(let n=-1;n<=1;n++)ctx.fillRect(n*64-9,-105,20,34);tree(-190,0,.8);tree(185,0,.8);
 }else if(p.id==='saopaulo'){
   // MASP e avenida urbana
   ctx.fillStyle='#cbdded';ctx.fillRect(-143,-164,286,82);ctx.fillStyle='#a62430';ctx.fillRect(-151,-172,302,10);ctx.fillRect(-150,-92,302,12);
   ctx.fillStyle='#ad313b';ctx.fillRect(-116,-85,20,86);ctx.fillRect(96,-85,20,86);
   ctx.fillStyle='#c6e6fb66';ctx.fillRect(-128,-154,256,54);for(let n=0;n<8;n++)ctx.fillRect(-125+n*33,-164,7,72);
 }else if(p.id==='salvador'){
   // Elevador Lacerda e casarões do Pelourinho
   ctx.fillStyle='#f9e7c9';ctx.fillRect(-28,-196,45,196);ctx.fillRect(14,-154,90,23);
   ctx.fillStyle='#e4ccaa';ctx.fillRect(17,-40,110,36);ctx.fillStyle='#7a5a46';ctx.fillRect(-22,-176,32,48);
   let colors=['#e9a665','#f1dc88','#80b9b3','#ee8c81'];for(let n=0;n<4;n++){
      ctx.fillStyle=colors[n];ctx.fillRect(-177+n*36,-93-(n%2)*18,36,93+(n%2)*18);
      ctx.fillStyle='#fff0d0';for(let j=0;j<3;j++)ctx.fillRect(-171+n*36,-80+j*24,12,13);
   }palm(185,0,.9);
 }
 // Cornices, pavement, railings and small repeated façade details.
 ctx.fillStyle='#fff0d688';for(let i=-130;i<130;i+=18){ctx.fillRect(i,-112,9,3);ctx.fillRect(i,-20,9,4);}
 ctx.fillStyle='#253944';ctx.fillRect(-210,-5,420,5);ctx.fillStyle='#ddc8a2';for(let i=-210;i<210;i+=12)ctx.fillRect(i,-4,10,3);
 ctx.restore();
 ctx.fillStyle='#102e4388';ctx.fillRect(310,104,340,28);ctx.fillStyle='#fff3d6';ctx.font='bold 13px system-ui';ctx.fillText(p.name+' • interpretação artística',325,123);
}
function ground(){
 const tile=35,off=Math.floor(state.world*.88)%tile;
 ctx.fillStyle='#4c2c1f';ctx.fillRect(0,G,Cw,Ch-G);
 for(let r=0;r<Math.ceil((Ch-G)/28);r++)for(let c=-1;c<Cw/tile+1;c++){
   const x=c*tile-off,y=G+r*28;ctx.fillStyle=((r+c)%3===0)?'#754626':((r+c)%3===1?'#5e3825':'#553023');ctx.fillRect(x,y,tile-2,26);ctx.fillStyle='#3a241d';ctx.fillRect(x+2,y+20,20,3);
 }
 ctx.fillStyle='#215336';ctx.fillRect(0,G-7,Cw,12);ctx.fillStyle='#96dc6a';ctx.fillRect(0,G-8,Cw,5);
}
function currentVisible(items){const a=state.world-px;return items.filter(it=>!it.done&&!it.got&&it.x>a-180&&it.x<a+Cw+220);}
function rect(a,b){return a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y;}
function drawObjects(){
 const cam=state.world-px;
 for(const o of currentVisible(state.obj)){
   const x=o.x-cam;
   if(o.type==='gap'){
     ctx.fillStyle='#2373aa';ctx.fillRect(x,G-7,o.w,Ch-G+8);
     ctx.fillStyle='#71c4eb';for(let i=0;i<o.w;i+=19)ctx.fillRect(x+i,G+22+3*Math.sin(state.elapsed*6+i/11),13,3);
   }else{
     ctx.fillStyle=o.type==='platform'?'#497a58':o.type==='log'?'#6e4224':o.type==='crate'?'#9e652f':'#ac7461';ctx.fillRect(x,G-o.h,o.w,o.h);
     ctx.strokeStyle='#ecbd76';ctx.lineWidth=Math.max(2,Ch*.006);ctx.strokeRect(x+3,G-o.h+3,o.w-6,o.h-6);
     if(o.type==='log'){ctx.fillStyle='#bd9458';ctx.beginPath();ctx.ellipse(x+12,G-o.h/2,10,o.h/2-4,0,0,Math.PI*2);ctx.fill();ctx.fillStyle='#6e4224';ctx.fillRect(x+10,G-o.h/2-4,5,8);}if(o.type==='crate'){
       ctx.beginPath();ctx.moveTo(x+7,G-o.h+7);ctx.lineTo(x+o.w-7,G-7);ctx.moveTo(x+o.w-7,G-o.h+7);ctx.lineTo(x+7,G-7);ctx.stroke();
     }
   }
 }
}
function drawPickup(){
 const cam=state.world-px;
 for(const ob of currentVisible(state.pickup)){
   const x=ob.x-cam,y=G-ob.y+Math.sin(state.elapsed*5+ob.x/71)*4;
   ctx.save();ctx.translate(x,y);ctx.shadowColor='#ffd67a';ctx.shadowBlur=14;
   if(ob.kind==='scroll'){
     ctx.fillStyle='#fff2b9';ctx.fillRect(-11,-14,22,28);ctx.fillStyle='#bb8227';ctx.fillRect(-14,-13,6,26);ctx.fillRect(8,-13,6,26);ctx.fillStyle='#be883d';ctx.fillRect(-6,-5,12,3);ctx.fillRect(-6,2,12,3);
   }else{
     ctx.fillStyle='#ffcf57';ctx.beginPath();ctx.moveTo(0,-14);ctx.lineTo(12,0);ctx.lineTo(0,14);ctx.lineTo(-12,0);ctx.closePath();ctx.fill();ctx.fillStyle='#fff8bc';ctx.fillRect(-2,-8,4,14);
   }
   ctx.restore();
 }
}
function drawPlayer(){
 const attack=state.attack;
 const clipId=animator.clip({attack,onGround:state.onGround,landing,velocityY:state.vY,jumpAge,step:combat.state.step});
 const frames=images.sprites[clipId]||[];if(!frames.length)return;
 const index=animator.frame({clipId,elapsed:runClock,landing,velocityY:state.vY,jumpAge,combat});
 const im=frames[Math.max(0,Math.min(frames.length-1,index))];
 ctx.save();if(finishTime>0)ctx.translate(Math.min(260,finishTime*140),0);
 if(state.inv>0&&Math.floor(state.inv*9)%2===0)ctx.globalAlpha=.42;
 ctx.fillStyle='#06142c44';ctx.beginPath();ctx.ellipse(px,G-2,27,6,0,0,Math.PI*2);ctx.fill();
 window.drawFramedSprite(ctx,im,px,state.playerY,playerH,attack?combat.move().scale:1);
 // A diferenciação dos golpes é reforçada por efeitos com direções e alcances distintos.
 if(attack){
   const m=combat.move(),t=m.duration-combat.state.left;
   if(t>=m.active[0]&&t<=m.active[1]){
      const frac=(t-m.active[0])/(m.active[1]-m.active[0]);
      ctx.globalAlpha=.65;ctx.lineWidth=combat.state.step===3?12:7;
      ctx.strokeStyle=attack==='flag'?'#90ffb8':combat.state.step===3?'#ff7a64':'#f8d36a';
      ctx.beginPath();
      if(combat.state.step===1){ // corte na horizontal
          ctx.ellipse(px+80,state.playerY-80,65,25,-.2,-.7+frac*.3,1.5+frac*.3);
      }else if(combat.state.step===2){ // golpe descendente
          ctx.ellipse(px+70,state.playerY-112,33,75,-.3,-1.5+frac,0+frac);
      }else{ // finalização circular dupla
          ctx.ellipse(px+83,state.playerY-105,78,84,0,-1+frac*.6,1.7+frac*.6);
      }
      ctx.stroke();
   }
 }
 ctx.restore();
}
function foreground(){
 // subtle sign at regular intervals, visually indicates travelled region
 if(Cw>460){ctx.fillStyle='#08182ec5';ctx.fillRect(8,G+16,158,29);ctx.fillStyle='#c6e6fa';ctx.font='bold 13px system-ui';ctx.fillText('RUMO A BRASÍLIA →',18,G+35)}
}
function render(){if(!loadDone||el.game.classList.contains('hidden'))return;ctx.clearRect(0,0,Cw,Ch);const p=getPhase(state.elapsed);background(p);ground();drawObjects();drawPickup();drawPlayer();drawEffects();foreground();}
function toast(label,msg,duration=3){el.storyLabel.textContent=label;el.storyText.textContent=msg;el.story.classList.add('show');state.toast=duration;}
function burst(x,y){for(let i=0;i<12;i++)particles.push({x,y,vx:(i%4-1.5)*65,vy:-70-i*12,life:.6});}
function drawEffects(){ctx.fillStyle='#ffe486';for(const p of particles)ctx.fillRect(p.x-state.world+px,p.y,5,5);if(finishTime>0){ctx.fillStyle='#07182baa';ctx.fillRect(190,170,580,100);ctx.fillStyle='#ffe29a';ctx.font='bold 32px system-ui';ctx.fillText('BRASIL PERCORRIDO!',290,230);}}
function hurt(){
 if(state.inv>0||state.ended)return;
 state.lives--;state.inv=2.6;
 if(state.lives<=0){end(false);return;}
 toast('Atenção!','Uma vida perdida — proteção temporária ativada.',1.8);
}
function action(key){
 if(!state.playing||state.paused||state.ended||finishTime>0)return;
 if(key==='jump'){
  if(!state.onGround&&state.jumpsUsed===1){state.vY=-505;state.jumpsUsed=2;landing=0;jumpAge=0;jumpBuffer=0;runClock=0;burst(state.world,state.playerY);}
  else if(state.onGround||coyote>0||state.jumpsUsed===0)jumpBuffer=.14;
 }else{
  if(key==='flag'&&!state.flagUnlocked){toast('Bandeira bloqueada','Alcance '+window.GameCombat.FLAG_SCORE+' pontos para coletar a bandeira.',1.5);return;}
  combat.press(key,state.flagUnlocked);state.attack=combat.state.weapon;state.attackLeft=combat.state.left;
 }
}
function showMemories(){el.memoryList.replaceChildren();for(const m of state.collected){const d=document.createElement('div');d.textContent=m[0]+' — '+m[1];if(m[2]){const a=document.createElement('a');a.href=m[2];a.target='_blank';a.rel='noopener noreferrer';a.textContent=' Consultar fonte (internet)';d.appendChild(a);}el.memoryList.appendChild(d);}if(!state.collected.length)el.memoryList.textContent='Colete pergaminhos para abrir o acervo desta tentativa.';}
function checkFlag(){if(!state.flagUnlocked&&state.score>=window.GameCombat.FLAG_SCORE){state.flagUnlocked=true;toast('Bandeira coletada!','Você alcançou 1.000 pontos. O ataque com bandeira está disponível.',2.8);}}
function hud(){const flag=$('flag');flag.disabled=!state.flagUnlocked;flag.classList.toggle('locked',!state.flagUnlocked);$('flagLabel').textContent=state.flagUnlocked?'BANDEIRA':Math.min(state.score,window.GameCombat.FLAG_SCORE)+' / '+window.GameCombat.FLAG_SCORE;$('comboLabel').textContent=combat.state.weapon?combat.move().name+' • '+combat.state.step+'/3':'';const remaining=Math.ceil(Math.max(0,TOTAL-state.elapsed));el.score.textContent=state.score.toLocaleString('pt-BR');el.clock.textContent=String(Math.floor(remaining/60)).padStart(2,'0')+':'+String(remaining%60).padStart(2,'0');el.bar.style.width=state.elapsed/TOTAL*100+'%';el.hearts.textContent='♥'.repeat(Math.max(0,state.lives));el.region.textContent=getPhase(state.elapsed).name;}
function saveCheckpoint(){checkpoint=JSON.parse(JSON.stringify({elapsed:state.elapsed,world:state.world,score:state.score,collected:state.collected,obj:state.obj,pickup:state.pickup,phase:state.phase,flagUnlocked:state.flagUnlocked}));}
function recover(){if(!checkpoint)return;Object.assign(state,JSON.parse(JSON.stringify(checkpoint)),{lives:3,inv:2.6,ended:false,paused:false,onGround:true,playerY:G,vY:0,attack:'',attackLeft:0,jumpsUsed:0});combat.reset();runClock=0;jumpBuffer=0;coyote=0;landing=0;particles=[];finishTime=0;el.veil.classList.add('hidden');last=0;hud();}
function update(dt){
 if(!state.playing||state.paused||state.ended)return;
 if(finishTime>0){finishTime+=dt;if(finishTime>=2)end(true);return;}
 dt=Math.min(dt,TOTAL-state.elapsed);const oldTime=state.elapsed;
 state.elapsed=Math.min(TOTAL,state.elapsed+dt);state.world=state.elapsed*SPEED;state.anim+=dt;if(state.onGround)runClock+=dt;
 state.score+=Math.floor(state.elapsed*10)-Math.floor(oldTime*10);
 state.inv=Math.max(0,state.inv-dt);landing=Math.max(0,landing-dt);
 combat.update(dt);state.attack=combat.state.weapon;state.attackLeft=combat.state.left;
 const prevY=state.playerY;
 const gap=state.obj.find(o=>o.type==='gap'&&state.world>o.x&&state.world<o.x+o.w);
 const platform=state.obj.find(o=>o.type==='platform'&&state.world+15>o.x&&state.world-15<o.x+o.w&&state.playerY<=G-o.h+2);
 const floor=platform?G-platform.h:gap?Infinity:G;
 if(state.onGround&&Math.abs(state.playerY-floor)>2)state.onGround=false;
 coyote=state.onGround?.10:Math.max(0,coyote-dt);
 if(jumpBuffer>0&&(state.onGround||coyote>0)){state.vY=-535;state.jumpsUsed=1;runClock=0;landing=0;state.onGround=false;coyote=0;jumpBuffer=0;jumpAge=0;}
 jumpBuffer=Math.max(0,jumpBuffer-dt);
 if(!state.onGround){jumpAge+=dt;state.vY+=1290*dt;state.playerY+=state.vY*dt;
 if(state.vY>=0&&prevY<=floor+2&&state.playerY>=floor){state.playerY=floor;state.vY=0;state.onGround=true;state.jumpsUsed=0;landing=.10;runClock=0;}}
 if(state.playerY>G+125){hurt();state.playerY=G-90;state.vY=-320;state.jumpsUsed=2;state.onGround=false;}
 if(state.toast>0){state.toast-=dt;if(state.toast<=0)el.story.classList.remove('show');}
 const pbox={x:state.world-16,y:state.playerY-88,w:32,h:86};
 for(const o of state.obj){if(o.done||o.type==='gap'||o.type==='platform'||o.x<state.world-120||o.x>state.world+230)continue;
 const obox={x:o.x,y:G-o.h,w:o.w,h:o.h};
 const hit=combat.hitbox(state.world,state.playerY);
 if(hit&&o.type!=='barrier'&&rect(hit,obox)){o.done=true;state.score+=130;burst(o.x,G-o.h);}
 else if(rect(pbox,obox)&&state.inv<=0){o.done=true;hurt();}
 }
 if(state.ended){hud();return;}
 for(const c of state.pickup){if(c.got||c.x<state.world-50||c.x>state.world+55)continue;
 if(rect(pbox,{x:c.x-14,y:G-c.y-18,w:28,h:36})){c.got=true;state.score+=c.kind==='scroll'?180:90;burst(c.x,G-c.y);
 if(c.kind==='scroll'){const next=MEMORIES[state.collected.length];if(next){state.collected.push(next);toast('Acervo • '+next[0],next[1],3.1);}}}}
 for(const p of particles){p.life-=dt;p.x+=p.vx*dt;p.vy+=450*dt;p.y+=p.vy*dt;}particles=particles.filter(p=>p.life>0);
 checkFlag();
 const ph=getPhase(state.elapsed);if(state.phase!==ph.id){state.phase=ph.id;if(!ph.city)saveCheckpoint();toast(ph.city?'Cidade • interpretação artística':'Checkpoint',ph.name,2);}
 hud();if(state.elapsed>=TOTAL){state.score+=1500;checkFlag();finishTime=.001;state.attack='';state.playerY=G;burst(state.world+100,G-120);hud();}
}
function loop(ts){if(!state.playing)return;let dt=last?Math.max(0,(ts-last)/1000):0;last=ts;
 // Long browser suspension pauses instead of consuming lives or skipping the route.
 if(dt>1&&!state.paused&&!state.ended){pause();dt=0;}
 while(dt>0){const step=Math.min(1/120,dt);update(step);dt-=step;}
 render();frame=requestAnimationFrame(loop);
}
function start(){if(!loadDone)return;cancelAnimationFrame(frame);Object.assign(state,{playing:true,paused:false,ended:false,elapsed:0,score:0,lives:3,world:0,inv:0,playerY:420,vY:0,onGround:true,anim:0,attack:'',attackLeft:0,toast:0,phase:'south',collected:[],jumpsUsed:0,flagUnlocked:false});combat.reset();runClock=0;jumpBuffer=0;coyote=0;landing=0;particles=[];finishTime=0;createLevel();saveCheckpoint();el.start.classList.add('hidden');el.game.classList.remove('hidden');el.veil.classList.add('hidden');el.story.classList.remove('show');el.pause.textContent='Ⅱ';resize();hud();last=0;frame=requestAnimationFrame(loop);}
function pause(){if(!state.playing||state.ended)return;state.paused=!state.paused;el.pause.textContent=state.paused?'▶':'Ⅱ';if(state.paused){el.veil.classList.remove('hidden');el.resultData.classList.remove('hidden');el.veilTitle.textContent='Pausa • biblioteca';el.veilText.textContent='O cronômetro está parado. Consulte suas memórias.';el.resume.classList.remove('hidden');$('checkpoint').classList.add('hidden');showMemories();el.finalScore.textContent=state.score;el.finalMemory.textContent=state.collected.length;el.finalProgress.textContent=Math.floor(state.elapsed/TOTAL*100)+'%';}else{el.veil.classList.add('hidden');last=0;}}
function end(win){state.ended=true;state.paused=true;el.resultData.classList.remove('hidden');el.veil.classList.remove('hidden');el.resume.classList.add('hidden');$('checkpoint').classList.toggle('hidden',win);el.veilTitle.textContent=win?'Democracia em movimento!':'Fim de jogo';el.veilText.textContent=win?'Você chegou ao Palácio do Planalto. 180 segundos de percurso concluídos.':'Retome o início da região com três vidas. Tempo, itens e pontos serão restaurados juntos.';el.finalScore.textContent=state.score.toLocaleString('pt-BR');el.finalMemory.textContent=state.collected.length;el.finalProgress.textContent=Math.round(state.elapsed/TOTAL*100)+'%';showMemories();}
$('checkpoint').addEventListener('click',recover);
window.pauseGame=()=>{if(state.playing&&!state.paused&&!state.ended)pause();};
// Explicit opt-in used by automated tests only.
if(new URLSearchParams(location.search).has('test'))window.__game={state,combat,checkFlag,update,action,start,pause,recover,getPhase,render,resize,geometry:()=>({G,playerH}),get checkpoint(){return checkpoint;}};
function goHome(){state.playing=false;cancelAnimationFrame(frame);el.game.classList.add('hidden');el.start.classList.remove('hidden');el.veil.classList.add('hidden');}
function setupTap(id,k){const btn=$(id);btn.addEventListener('pointerdown',e=>{e.preventDefault();btn.classList.add('pressed');action(k);});btn.addEventListener('pointerup',()=>btn.classList.remove('pressed'));btn.addEventListener('pointercancel',()=>btn.classList.remove('pressed'));btn.addEventListener('pointerleave',()=>btn.classList.remove('pressed'));btn.addEventListener('click',e=>{if(!window.PointerEvent)action(k);});}
setupTap('jump','jump');setupTap('hammer','hammer');setupTap('flag','flag');
el.pause.addEventListener('click',pause);el.resume.addEventListener('click',pause);el.restart.addEventListener('click',start);el.home.addEventListener('click',goHome);el.startBtn.addEventListener('click',start);
window.addEventListener('keydown',e=>{const key=e.key.toLowerCase();if([' ','arrowup','w'].includes(key)){e.preventDefault();if(!e.repeat)action('jump')}else if(key==='z'&&!e.repeat)action('hammer');else if(key==='x'&&!e.repeat)action('flag');else if(key==='p'&&!e.repeat)pause();});
document.addEventListener('visibilitychange',()=>{if(document.hidden&&state.playing&&!state.paused&&!state.ended)pause();});
window.addEventListener('resize',()=>{if(!el.game.classList.contains('hidden'))resize();});
function loadOne(src){return new Promise(resolve=>{const im=new Image();im.onload=()=>resolve(im);im.onerror=()=>resolve(null);im.src=src;});}
async function preload(){
 el.cover.style.backgroundImage='url('+assets.backgrounds.south+')';
 const jobs=[];for(const [key,url] of Object.entries(assets.backgrounds))jobs.push(loadOne(url).then(img=>{images.backgrounds[key]=img;}));
 for(const [key,urls] of Object.entries(assets.sprites)){
   images.sprites[key]=new Array(urls.length);
   urls.forEach((url,i)=>jobs.push(loadOne(url).then(im=>{images.sprites[key][i]=im;})));
 }
 await Promise.all(jobs);
 for(const [key,v] of Object.entries(images.sprites))images.sprites[key]=v.filter(Boolean);
 loadDone=Object.values(images.backgrounds).every(Boolean)&&Object.entries(assets.sprites).every(([k,v])=>images.sprites[k].length===v.length);
 if(loadDone){el.startBtn.disabled=false;el.startBtn.textContent='▶ JOGAR AGORA';}else{el.startBtn.textContent='Erro ao carregar — recarregue';}
}
preload().catch(e=>{el.startBtn.textContent='Erro ao carregar — recarregue';console.error(e)});
})();
