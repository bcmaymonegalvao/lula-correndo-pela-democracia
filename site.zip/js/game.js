/* Lula - Correndo pela Democracia · Alpha 0.8.2
   Corrida infinita em Brasília, votos, inimigos-robô e combos aéreos.
   Sem cronômetro limite, barra de progresso ou fim automático. */
(()=>{
 'use strict';
 const $=id=>document.getElementById(id);
 const cv=$('canvas'), ctx=cv.getContext('2d',{alpha:false});
 const assets=window.GAME_ASSETS, combat=window.GameCombat.create(), animator=window.GameAnimation, bonusSystem=window.GameBonuses;
 const el={start:$('start'),game:$('game'),startBtn:$('startBtn'),cover:$('coverImg'),scene:$('scene'),
  votes:$('votes'),benefits:$('benefits'),superPoints:$('superPoints'),clock:$('clock'),hits:$('hits'),hearts:$('hearts'),region:$('region'),
  story:$('story'),storyLabel:$('storyLabel'),storyText:$('storyText'),comboLabel:$('comboLabel'),
  pause:$('pause'),veil:$('veil'),veilTitle:$('veilTitle'),veilText:$('veilText'),
  resultData:$('resultData'),finalVotes:$('finalVotes'),finalBenefits:$('finalBenefits'),finalHits:$('finalHits'),
  summaryInfo:$('summaryInfo'),finalSuperPoints:$('finalSuperPoints'),bonusSummary:$('bonusSummary'),resume:$('resume'),restart:$('restart'),home:$('home'),
  loadingText:$('loadingText'),loadProgress:$('loadProgress'),loadWarning:$('loadWarning')};
 const W=960,H=540,FLOOR=423,SPEED=214,GRAVITY=1300,SCENE_SECONDS=38,SCENE_FADE=4.5;
 let G=FLOOR, P_X=190,frame=0,last=0,runAge=0,jumpAge=0,landing=0,toastLeft=0;
 let jumpQueue=0, coyote=0,loadDone=false,sceneCycle=window.CityRotation.create();
 const loadingReport={total:0,completed:0,failed:[],essentialMissing:[]};
 const assetFailures=new Set();
 let images={bg:{},sprite:{},fx:{},vote:null,street:null,bonusAtlas:null};
 let fx=[],swingFx=[],particles=[],popups=[];
 let lastAttackSerial=0;
 const robotTintCache=new WeakMap();
 let nextEnemy=4,nextVote=.9,nextBonus=5,spawnId=0,lastBonusId=null;
 let currentCity=null,previousCity=null,cityAge=0,cityDuration=SCENE_SECONDS,cityCount=0;
 const state={playing:false,paused:false,ended:false,time:0,world:0,votes:0,benefits:0,
  lives:3,inv:0,playerY:FLOOR,vY:0,onGround:true,jumpsUsed:0,hitCombo:0,bestCombo:0,hitClock:0,
  enemies:[],pickups:[],bonusPickups:[],superPoints:0,bonusTotal:0,bonusCounts:bonusSystem.initialCounts(),attack:'',streakHits:0};
 const rnd=(a,b)=>a+Math.random()*(b-a);
 function chooseCity(){
  previousCity=currentCity;currentCity=sceneCycle.next();cityAge=0;cityCount++;
  cityDuration=SCENE_SECONDS;if(el.region)el.region.textContent=currentCity.name;
  if(state.playing)showToast('Fase atual',currentCity.name,1.55);
 }
 function fmt(t){const sec=Math.max(0,Math.floor(t)),h=Math.floor(sec/3600),m=Math.floor(sec/60)%60,s=sec%60;
  return (h?h.toString().padStart(2,'0')+':':'')+String(m).padStart(2,'0')+':'+String(s).padStart(2,'0');}
 function resize(){
  const r=el.scene.getBoundingClientRect();if(r.width<=0||r.height<=0)return;
  const dpr=Math.min(2,window.devicePixelRatio||1);
  cv.width=Math.max(1,Math.round(r.width*dpr));cv.height=Math.max(1,Math.round(r.height*dpr));
  const scale=Math.min(cv.width/W,cv.height/H);
  ctx.setTransform(scale,0,0,scale,(cv.width-W*scale)/2,(cv.height-H*scale)/2);ctx.imageSmoothingEnabled=false;
  render();
 }
 // Panoramas are illustrated (not pixelated), with gentle sideways parallax.
 function drawCity(city,opacity=1,age=cityAge){
  if(!city)return;
  ctx.save();ctx.globalAlpha*=opacity;
  const im=images.bg[city.id] || images.bg.brasilia_dia || Object.values(images.bg).find(Boolean);
  if(im&&im.width){
   const cover=Math.max(W/im.width,H/im.height)*1.17;
   const dw=im.width*cover,dh=im.height*cover;
   const travel=Math.max(0,dw-W);
   const progress=Math.min(1,Math.max(0,age/SCENE_SECONDS));
   ctx.imageSmoothingEnabled=true; // Realistic illustration, not a pixel sprite.
   ctx.drawImage(im,-travel*progress,(H-dh)/2,dw,dh);
   ctx.imageSmoothingEnabled=false;
  }else{
   const grad=ctx.createLinearGradient(0,0,0,H);grad.addColorStop(0,'#2783d2');grad.addColorStop(1,'#a1e4c4');
   ctx.fillStyle=grad;ctx.fillRect(0,0,W,H);
  }
  ctx.restore();
 }
 // Change atmospheric lighting continuously while afternoon gives way to dusk/night.
 function atmosphere(){
  if(!currentCity)return;
  const progress=Math.min(1,cityAge/SCENE_SECONDS);
  const period=currentCity.period;
  ctx.save();
  if(period==='afternoon'||period==='sunset'){
   const warmth=period==='afternoon'?(.045+.095*progress):(.15+.12*progress);
   const tint=ctx.createLinearGradient(0,0,W,H);
   tint.addColorStop(0,'rgba(255,224,170,0)');
   tint.addColorStop(1,`rgba(251,130,49,${warmth})`);
   ctx.fillStyle=tint;ctx.fillRect(0,0,W,H);
  }
  if(period==='sunset'){
   ctx.fillStyle=`rgba(36,26,63,${.03+.13*progress})`;ctx.fillRect(0,0,W,H);
  }
  if(period==='night'){
   // Daylight drains smoothly from the blue-hour scene, leaving architecture visible.
   ctx.fillStyle=`rgba(1,8,36,${.12+.37*progress})`;ctx.fillRect(0,0,W,H);
   const glow=ctx.createLinearGradient(0,H*.45,0,H);
   glow.addColorStop(0,'rgba(255,173,97,0)');
   glow.addColorStop(1,`rgba(238,134,76,${.045+.085*progress})`);
   ctx.fillStyle=glow;ctx.fillRect(0,0,W,H);
  }
  ctx.restore();
 }
 function backdrop(){
  drawCity(currentCity,1);
  if(previousCity&&cityAge<SCENE_FADE){
   drawCity(previousCity,1-cityAge/SCENE_FADE,SCENE_SECONDS);
  }
  atmosphere();
 }
 function ground(){
  // Constantly moving 16-bit transparent road over the illustrated panoramas.
  const road=images.street;
  if(!road){ // Graceful fallback if the noncritical foreground does not load.
   ctx.save();ctx.fillStyle='#313b50';ctx.fillRect(0,G,W,H-G);
   ctx.fillStyle='#8e9ba9';ctx.fillRect(0,G,W,4);
   ctx.fillStyle='#c4bb9d';for(let i=0;i<8;i++){
    const x=((i*160-state.world*1.15)%1280+1280)%1280;
    ctx.fillRect(x,G+62,74,5);
   }ctx.restore();return;
  }
  const tileW=1140,roadH=146;
  const offset=((state.world*1.15)%tileW+tileW)%tileW;
  ctx.save();ctx.imageSmoothingEnabled=false;
  for(let x=-offset-tileW;x<W+tileW;x+=tileW){
   ctx.drawImage(road,Math.round(x),G-10,tileW,roadH);
  }
  ctx.restore();
 }
 function drawVote(item){
  const dx=item.x-state.world+P_X;
  const dy=G-item.height+Math.sin(state.time*5+item.id)*4;
  if(images.vote){ctx.save();ctx.shadowColor='#e2ffb0';ctx.shadowBlur=9;
   ctx.drawImage(images.vote,dx-19,dy-21,38,38);ctx.restore();}
  else{ctx.fillStyle='#d8ff99';ctx.fillRect(dx-12,dy-15,24,30);}
 }
 function drawBonus(item){
  const dx=item.x-state.world+P_X;
  const dy=G-item.height+Math.sin(state.time*4.7+item.id)*5;
  const b=bonusSystem.catalog.find(t=>t.id===item.type);
  if(!b)return;
  const size=61 + Math.sin(state.time*8+item.id)*2;
  ctx.save();ctx.imageSmoothingEnabled=false;
  ctx.shadowColor='#ffe773';ctx.shadowBlur=16;
  if(images.bonusAtlas && images.bonusAtlas.width===bonusSystem.FRAME_SIZE*4){
    const ix=Math.floor((state.time*bonusSystem.FPS+item.id*.27)%4);
    ctx.drawImage(images.bonusAtlas, ix*192,b.row*192,192,192,
      dx-size/2,dy-size/2,size,size);
  }else{
    // Bônus continua coletável se a spritesheet opcional falhar.
    ctx.fillStyle='#213f65';ctx.strokeStyle='#ffe68a';ctx.lineWidth=3;
    ctx.beginPath();ctx.arc(dx,dy,24,0,Math.PI*2);ctx.fill();ctx.stroke();
    ctx.fillStyle='#ffed96';ctx.font='900 23px system-ui';ctx.textAlign='center';
    ctx.fillText('★',dx,dy+8);ctx.textAlign='left';
  }
  ctx.restore();
 }
 function tintedRobot(pic,color){
  if(!pic||typeof document.createElement!=='function')return pic;
  let colors=robotTintCache.get(pic);
  if(!colors){colors=new Map();robotTintCache.set(pic,colors);}
  if(colors.has(color))return colors.get(color);
  const overlay=document.createElement('canvas');
  if(typeof overlay.getContext!=='function')return pic; // Lightweight test harness.
  overlay.width=pic.width;overlay.height=pic.height;
  const c=overlay.getContext('2d');
  c.drawImage(pic,0,0);
  c.globalCompositeOperation='source-atop';c.fillStyle=color;
  c.fillRect(0,0,overlay.width,overlay.height);
  c.globalCompositeOperation='source-over';
  colors.set(color,overlay);return overlay;
 }
 function drawEnemies(){
  for(const e of state.enemies){
   const x=e.x-state.world+P_X;
   if(x<-270||x>W+270)continue;
   if(e.dead&&e.deathAge>.85)continue;
   const anim=e.dead?'enemy_die':e.stun>0?'enemy_hit':'enemy_walk';
   const pics=images.sprite[anim]||[];
   let ix=0;
   if(e.dead)ix=Math.min(pics.length-1,Math.floor(e.deathAge*10));
   else if(e.stun>0)ix=Math.min(pics.length-1,Math.floor((.32-e.stun)*12));
   else ix=Math.floor(e.walkTime*10)%pics.length;
   const pic=pics[ix]||pics.find(Boolean);if(!pic)continue;
   // Colored silhouette blinks ONLY when a registered attack intersects this robot.
   const blinking=(e.flash||0)>0&&Math.floor((.34-e.flash)/.055)%2===0;
   const image=blinking?tintedRobot(pic,e.flashColor||'#66dbff'):pic;
   ctx.save();
   // Face the approaching enemy toward the left.
   ctx.translate(x,G);ctx.scale(-1,1);
   if(blinking){ctx.shadowColor=e.flashColor||'#66dbff';ctx.shadowBlur=21;}
   window.drawFramedSprite(ctx,image,0,0,2.26,anim); // exactly 2 × previous 1.13 scale
   ctx.restore();
   if(!e.dead){
    ctx.fillStyle='#102037';ctx.fillRect(x-43,G-227,86,7);
    ctx.fillStyle=e.flashColor||'#66d7ff';ctx.fillRect(x-41,G-225,82*(e.hp/3),4);
   }
  }
 }
 function drawPlayer(){
  const id=animator.clip({step:combat.state.step,grounded:state.onGround,jumpsUsed:state.jumpsUsed,landing});
  const arr=images.sprite[id]||[];
  const ix=animator.frame({clipId:id,elapsed:runAge,jumpAge,velocityY:state.vY,landing,combat});
  const pic=arr[Math.min(arr.length-1,ix)]||arr.find(Boolean)||images.sprite.run?.find(Boolean);if(!pic)return;
  ctx.save();ctx.fillStyle='#08152666';ctx.beginPath();ctx.ellipse(P_X,G-3,34,7,0,0,Math.PI*2);ctx.fill();
  if(state.inv>0&&Math.floor(state.inv*14)%2)ctx.globalAlpha=.42;
  window.drawFramedSprite(ctx,pic,P_X,state.playerY,1.13,id);
  ctx.restore();
 }
 // Draw 4-frame RGBA effects; the drawn art itself uses only ~65% of each frame.
 function drawFxSequence(effect,scale=1){
  const sprites=images.fx[effect.kind]||[];if(!sprites.length)return;
  const life=effect.duration||.32;
  const ix=Math.min(sprites.length-1,Math.floor(effect.age/life*sprites.length));
  const sprite=sprites[ix]||sprites.find(Boolean);if(!sprite)return;
  const x=effect.x-state.world+P_X;
  const px=152*(effect.scale||1)*scale;
  ctx.save();ctx.globalAlpha=Math.max(0,1-effect.age/life*.67);
  ctx.drawImage(sprite,x-px/2,effect.y-px/2,px,px);
  ctx.restore();
 }
 function drawFx(){
  // The swing is visible even if it misses; contact bursts only exist for a real hit.
  for(const f of swingFx)drawFxSequence(f,.97);
  for(const f of fx)drawFxSequence(f,1.06);
  for(const p of particles){const x=p.x-state.world+P_X;
   ctx.globalAlpha=Math.max(.05,p.life/.7);ctx.fillStyle=p.color;ctx.fillRect(x,p.y,p.sz,p.sz);
  }
  ctx.globalAlpha=1;
  for(const p of popups){const x=p.x-state.world+P_X;
   ctx.globalAlpha=Math.min(1,p.life*2);
   ctx.font='900 19px system-ui';ctx.textAlign='center';ctx.lineWidth=4;
   ctx.strokeStyle='#0b1930';ctx.strokeText(p.text,x,p.y);ctx.fillStyle=p.color;ctx.fillText(p.text,x,p.y);
  }
  ctx.globalAlpha=1;ctx.textAlign='left';
 }
 function launchFx(kind,x,y,options={}){
  const e={kind,x,y,age:0,duration:options.duration||.32,scale:options.scale||1};
  (options.swing?swingFx:fx).push(e);
  return e;
 }
 function swingAtNewAttack(){
  if(lastAttackSerial===combat.state.serial)return;
  lastAttackSerial=combat.state.serial;
  const m=combat.move();if(!m)return;
  launchFx(m.impact,state.world+(m.clip==='flying_kick'?88:68),
   state.playerY+(m.clip==='flying_kick'?-87:-76),{swing:true,duration:.29,scale:m.clip==='flying_kick'?1.12:.85});
 }
 function render(){
  if(!loadDone||el.game.classList.contains('hidden'))return;
  ctx.clearRect(0,0,W,H);backdrop();ground();
  for(const vote of state.pickups)if(!vote.got&&vote.x>state.world-200&&vote.x<state.world+W)drawVote(vote);
  for(const bonus of state.bonusPickups)if(!bonus.got&&bonus.x>state.world-200&&bonus.x<state.world+W)drawBonus(bonus);
  drawEnemies();drawPlayer();drawFx();
 }
 function showToast(label,msg,duration=2){el.storyLabel.textContent=label;el.storyText.textContent=msg;
  el.story.classList.add('show');toastLeft=duration;}
 function sparkle(x,y,kind){
  const palette=kind==='flying_kick'?['#62d872','#ffe579','#86bfff']:['#ffe99e','#faf7ec','#f1a65e'];
  for(let i=0;i<11;i++)particles.push({x,y,vx:rnd(-145,145),vy:rnd(-200,-40),life:rnd(.25,.7),sz:rnd(3,6),color:palette[i%3]});
 }
 function hud(){
  el.votes.textContent=state.votes.toLocaleString('pt-BR');
  el.superPoints.textContent=state.superPoints.toLocaleString('pt-BR');
  el.benefits.textContent=state.benefits.toLocaleString('pt-BR');
  el.clock.textContent=fmt(state.time);el.hearts.textContent='♥'.repeat(state.lives);
  el.hits.textContent=state.hitCombo+' hits';
  el.region.textContent=currentCity?currentCity.name:'Carregando…';
  el.comboLabel.textContent=state.hitCombo>=2&&state.hitClock>0?`COMBO ${state.hitCombo} HITS!`:'';
 }
 function createEnemy(){
  state.enemies.push({id:++spawnId,x:state.world+rnd(W+60,W+410),hp:3,stun:0,flash:0,flashColor:'#66dbff',
   walkTime:rnd(0,2),dead:false,deathAge:0,comboFollow:0});
 }
 function createVote(){
  state.pickups.push({id:++spawnId,x:state.world+rnd(W-90,W+210),height:rnd(52,126),got:false});
 }
 function createBonus(){
  const bonus=bonusSystem.choose(state.bonusCounts,lastBonusId);
  lastBonusId=bonus.id;
  // Varia alturas para convidar o jogador a correr e a usar os dois pulos.
  const height=[68,93,134,174][Math.floor(Math.random()*4)];
  const x=state.world+rnd(W+65,W+260);
  state.bonusPickups.push({id:++spawnId,type:bonus.id,x,height,got:false});
 }
 function collectBonus(item){
  if(item.got)return false;
  item.got=true;
  const value=bonusSystem.award(state,item.type);
  const type=bonusSystem.catalog.find(b=>b.id===item.type);
  const y=G-item.height;
  sparkle(item.x,y,'flying_kick');
  popups.push({text:`+${value.toLocaleString('pt-BR')} SUPER PONTOS`,x:item.x,y:y-31,life:1.1,color:'#ffe485'});
  showToast('BÔNUS COLETADO!',`${type.name} · +${value.toLocaleString('pt-BR')} pontos`,1.7);
  return true;
 }
 function hurt(){
  if(state.inv>0||state.ended)return;
  state.lives--;state.inv=1.7;
  sparkle(state.world,state.playerY-60,'front_punch');
  if(state.lives<=0){end();return;}
  showToast('O tesouraço atacou!',`Restam ${state.lives} vidas.`,1.4);
 }
 function collide(a,b){return a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y;}
 function playerBox(){return {x:state.world-25,y:state.playerY-99,w:52,h:91};}
 function hitEnemy(e,attackBox,targetBox){
  if(combat.state.hitTargets.has(e.id))return;
  combat.state.hitTargets.add(e.id);
  e.hp--;e.stun=.32;e.flash=.34;e.flashColor=combat.move().flashColor;
  if(e.hp>0){e.comboFollow=1.45;e.x=Math.max(e.x,state.world+94);}
  state.benefits+=1;state.hitCombo=state.hitClock>0?state.hitCombo+1:1;
  state.hitClock=1.55;state.bestCombo=Math.max(state.bestCombo,state.hitCombo);
  // Efeito acontece NO PONTO DE CONTATO (intersecção real das hitboxes),
  // inclusive quando o jogador acerta durante salto ou pulo duplo.
  const contactX=Math.max(attackBox.x,targetBox.x);
  const contactY=Math.max(attackBox.y,targetBox.y);
  const overlapW=Math.max(0,Math.min(attackBox.x+attackBox.w,targetBox.x+targetBox.w)-contactX);
  const overlapH=Math.max(0,Math.min(attackBox.y+attackBox.h,targetBox.y+targetBox.h)-contactY);
  launchFx(combat.move().impact,contactX+overlapW/2,contactY+overlapH/2,
    {duration:.32,scale:combat.state.step===3?1.07:.91});
  popups.push({text:'+1 BENEFÍCIO',x:e.x,y:G-140,life:.9,color:'#a3f6ce'});
  if(e.hp<=0){e.dead=true;e.deathAge=0;e.stun=0;
    sparkle(e.x,G-83,combat.move().impact);
    popups.push({text:'TESOURAÇO DETIDO!',x:e.x,y:G-190,life:1.1,color:'#ffe199'});
  }
 }
 function action(key){
  if(!state.playing||state.paused||state.ended)return false;
  if(key==='jump'){
   if(!state.onGround&&state.jumpsUsed===1){
     state.vY=-520;state.jumpsUsed=2;jumpAge=0;landing=0;jumpQueue=0;
     launchFx('double_jump',state.world,state.playerY-50,{duration:.36,scale:.92});return true;
   }
   if(state.onGround||coyote>0){jumpQueue=.15;return true;}
   return false;
  }
  if(key==='combo'){
   const success=combat.press('combo');
   if(success){state.attack=combat.move().clip;swingAtNewAttack();return true;}return false;
  }
  return false;
 }
 function update(dt){
  if(!state.playing||state.paused||state.ended||dt<=0)return;
  dt=Math.min(dt,.05);
  state.time+=dt;state.world+=dt*SPEED;cityAge+=dt;
  if(cityAge>=cityDuration)chooseCity();
  nextEnemy-=dt;nextVote-=dt;nextBonus-=dt;
  if(nextEnemy<=0){createEnemy();nextEnemy=rnd(3.6,7.8);}
  if(nextVote<=0){createVote();nextVote=rnd(1.12,1.9);}
  if(nextBonus<=0){createBonus();nextBonus=rnd(4.8,7.6);}
  if(state.onGround)runAge+=dt;
  if(toastLeft>0){toastLeft-=dt;if(toastLeft<=0)el.story.classList.remove('show');}
  state.inv=Math.max(0,state.inv-dt);landing=Math.max(0,landing-dt);
  state.hitClock=Math.max(0,state.hitClock-dt);
  if(!state.hitClock)state.hitCombo=0;
  // Jump physics: attack input never interrupts jump or double-jump state.
  coyote=state.onGround?.11:Math.max(0,coyote-dt);
  if(jumpQueue>0&&(state.onGround||coyote>0)){
    state.onGround=false;state.vY=-530;state.jumpsUsed=1;jumpAge=0;landing=0;
    launchFx('jump',state.world,G-30,{duration:.34,scale:.8});
    jumpQueue=0;coyote=0;
  }
  jumpQueue=Math.max(0,jumpQueue-dt);
  if(!state.onGround){
    jumpAge+=dt;state.vY+=GRAVITY*dt;state.playerY+=state.vY*dt;
    if(state.playerY>=G){state.playerY=G;state.vY=0;state.onGround=true;state.jumpsUsed=0;landing=.13;jumpAge=0;
     launchFx('jump',state.world,G-26,{duration:.25,scale:.50});}
  }
  combat.update(dt);state.attack=combat.state.step?combat.move().clip:'';
  swingAtNewAttack();
  const sword=combat.hitbox(state.world,state.playerY);
  const body=playerBox();
  for(const e of state.enemies){
    if(e.dead){e.deathAge+=dt;continue;}
    e.walkTime+=dt;e.stun=Math.max(0,e.stun-dt);e.flash=Math.max(0,(e.flash||0)-dt);
    // Robot advances against the direction of the runner.
    if(e.comboFollow>0){e.x+=SPEED*dt;e.comboFollow-=dt;}
    else if(e.stun<=0)e.x-=dt*24;
    const box={x:e.x-51,y:G-222,w:102,h:215}; // robot silhouette doubled
    if(sword&&collide(sword,box)){hitEnemy(e,sword,box);continue;}
    const bodyContact={x:e.x-37,y:G-207,w:74,h:196};
    if(!e.dead&&!combat.state.step&&collide(body,bodyContact))hurt();
  }
  state.enemies=state.enemies.filter(e=>e.dead?e.deathAge<1.0:e.x>state.world-235);
  for(const v of state.pickups){
   if(v.got)continue;
   const y=G-v.height+Math.sin(state.time*5+v.id)*4;
   if(collide(body,{x:v.x-18,y:y-20,w:36,h:36})){
    v.got=true;state.votes++;
    sparkle(v.x,y,'flying_kick');
    popups.push({text:'+1 VOTO',x:v.x,y:y-25,life:.73,color:'#d2ffc0'});
   }
  }
  state.pickups=state.pickups.filter(v=>!v.got&&v.x>state.world-210);
  for(const b of state.bonusPickups){
    if(b.got)continue;
    const y=G-b.height+Math.sin(state.time*4.7+b.id)*5;
    if(collide(body,{x:b.x-24,y:y-24,w:48,h:48}))collectBonus(b);
  }
  state.bonusPickups=state.bonusPickups.filter(b=>!b.got&&b.x>state.world-210);
  for(const e of fx)e.age+=dt;fx=fx.filter(e=>e.age<e.duration);
  for(const e of swingFx)e.age+=dt;swingFx=swingFx.filter(e=>e.age<e.duration);
  for(const p of particles){p.life-=dt;p.x+=p.vx*dt;p.vy+=500*dt;p.y+=p.vy*dt;}
  particles=particles.filter(p=>p.life>0);
  for(const p of popups){p.life-=dt;p.y-=dt*34;}popups=popups.filter(p=>p.life>0);
  hud();
 }
 function pause(){
  if(!state.playing||state.ended)return;
  state.paused=!state.paused;el.pause.textContent=state.paused?'▶':'Ⅱ';
  if(state.paused){
   el.veil.classList.remove('hidden');el.resultData.classList.remove('hidden');
   el.veilTitle.textContent='Jogo pausado';el.veilText.textContent='Sua corrida infinita aguarda. Continue quando quiser.';
   el.resume.classList.remove('hidden');updateSummary();
  }else{el.veil.classList.add('hidden');last=0;}
 }
 function renderBonusSummary(){
  el.bonusSummary.replaceChildren();
  for(const b of bonusSystem.catalog){
    const row=document.createElement('div');
    row.className='bonus-entry'+((state.bonusCounts[b.id]||0)?'':' missing');
    if(images.bonusAtlas){
      const image=document.createElement('canvas');
      image.width=192;image.height=192;image.className='emblem';
      const c=image.getContext('2d');c.imageSmoothingEnabled=false;
      c.drawImage(images.bonusAtlas,0,b.row*192,192,192,0,0,192,192);
      row.appendChild(image);
    }else{
      const placeholder=document.createElement('span');
      placeholder.className='emblem emblem-placeholder';placeholder.textContent='★';row.appendChild(placeholder);
    }
    const name=document.createElement('span');name.className='bonus-name';name.textContent=b.name;
    const count=document.createElement('strong');count.className='bonus-count';
    count.textContent=`× ${state.bonusCounts[b.id]||0}`;
    row.append(name,count);el.bonusSummary.appendChild(row);
  }
 }
 function updateSummary(){
  el.finalVotes.textContent=state.votes.toLocaleString('pt-BR');
  el.finalBenefits.textContent=state.benefits.toLocaleString('pt-BR');
  el.finalHits.textContent=state.bestCombo+' hits';
  el.finalSuperPoints.textContent=state.superPoints.toLocaleString('pt-BR');
  renderBonusSummary();
  el.summaryInfo.textContent='Tempo de jogo: '+fmt(state.time)+' • Bônus coletados: '+state.bonusTotal+' • Brasília (manhã, tarde, pôr do sol e noite)';
 }
 function end(){
  state.ended=true;state.paused=true;state.lives=0;
  el.veil.classList.remove('hidden');el.resultData.classList.remove('hidden');
  el.veilTitle.textContent='Fim de jogo!';
  el.veilText.textContent=`Parabéns você coletou ${state.votes.toLocaleString('pt-BR')} votos e protegeu ${state.benefits.toLocaleString('pt-BR')} benefícios do tesouraço. Você ganhou ${state.superPoints.toLocaleString('pt-BR')} SUPER PONTOS com ${state.bonusTotal} bônus!`;
  el.resume.classList.add('hidden');updateSummary();hud();
 }
 function start(){
  if(!loadDone)return;
  cancelAnimationFrame(frame);
  Object.assign(state,{playing:true,paused:false,ended:false,time:0,world:0,votes:0,benefits:0,
   lives:3,inv:0,playerY:G,vY:0,onGround:true,jumpsUsed:0,hitCombo:0,bestCombo:0,
   hitClock:0,enemies:[],pickups:[],bonusPickups:[],superPoints:0,bonusTotal:0,bonusCounts:bonusSystem.initialCounts(),attack:'',streakHits:0});
  combat.reset();sceneCycle=window.CityRotation.create();currentCity=null;previousCity=null;
  cityCount=0;chooseCity();nextEnemy=rnd(2.8,4.8);nextVote=.8;nextBonus=3.3;lastBonusId=null;spawnId=0;
  runAge=0;jumpAge=0;landing=0;toastLeft=0;jumpQueue=0;coyote=0;fx=[];swingFx=[];particles=[];popups=[];lastAttackSerial=0;
  el.start.classList.add('hidden');el.game.classList.remove('hidden');el.veil.classList.add('hidden');
  el.story.classList.remove('show');el.pause.textContent='Ⅱ';
  resize();hud();last=0;frame=requestAnimationFrame(loop);
 }
 function loop(ts){
  if(!state.playing)return;
  let dt=last?Math.max(0,(ts-last)/1000):0;last=ts;
  if(dt>1&&!state.paused&&!state.ended){pause();dt=0;}
  while(dt>0){const step=Math.min(1/120,dt);update(step);dt-=step;}
  render();frame=requestAnimationFrame(loop);
 }
 function goHome(){state.playing=false;cancelAnimationFrame(frame);el.game.classList.add('hidden');el.start.classList.remove('hidden');el.veil.classList.add('hidden');}
 function setupTap(id,key){
  const btn=$(id);btn.addEventListener('pointerdown',e=>{e.preventDefault();btn.classList.add('pressed');action(key);});
  for(const name of ['pointerup','pointercancel','pointerleave'])btn.addEventListener(name,()=>btn.classList.remove('pressed'));
  btn.addEventListener('click',()=>{if(!window.PointerEvent)action(key);});
 }
 setupTap('jump','jump');setupTap('comboBtn','combo');
 el.pause.addEventListener('click',pause);el.resume.addEventListener('click',pause);
 el.restart.addEventListener('click',start);el.home.addEventListener('click',goHome);
 el.startBtn.addEventListener('click',start);
 window.addEventListener('keydown',e=>{
  const key=e.key.toLowerCase();if([' ','arrowup','w'].includes(key)){
   e.preventDefault();if(!e.repeat)action('jump');
  }else if(key==='z'&&!e.repeat)action('combo');
  else if(key==='x'&&!e.repeat)action('combo'); // optional keyboard alias, same one move cycle
  else if(key==='p'&&!e.repeat)pause();
 });
 document.addEventListener('visibilitychange',()=>{if(document.hidden&&state.playing&&!state.paused&&!state.ended)pause();});
 window.addEventListener('resize',()=>{if(!el.game.classList.contains('hidden'))resize();});
 // Treat missing OPTIONAL art as degraded visuals, not as a fatal game startup error.
 function warnAsset(group,src,reason){
  const key=group+' '+src;
  if(assetFailures.has(key))return;
  assetFailures.add(key);loadingReport.failed.push({group,src,reason});
  const critical=group.startsWith('essencial/');
  console[critical?'error':'warn'](`[Alpha 0.8.2][${critical?'recurso essencial':'recurso opcional'}] ${group}: ${src} — ${reason}`);
 }
 function progress(label){
  const {total,completed}=loadingReport;
  const percent=total?Math.round(100*completed/total):0;
  if(el.loadingText)el.loadingText.textContent=`${label}: ${completed}/${total} (${percent}%)`;
  if(el.loadProgress){el.loadProgress.max=Math.max(1,total);el.loadProgress.value=completed;}
 }
 function loadOne(src,group,{timeout=10000}={}){
  return new Promise(resolve=>{
   if(!src){resolve(null);return;}
   const image=new Image();let finished=false;
   const fullSrc=new URL(src,document.baseURI).href;
   let timer;
   function settle(ok,reason){
    if(finished)return;finished=true;clearTimeout(timer);
    image.onload=null;image.onerror=null;
    if(!ok)warnAsset(group,src,reason);
    loadingReport.completed++;progress(loadDone?'Carregando recursos adicionais':'Carregando imagens');
    resolve(ok?image:null);
   }
   image.onload=()=>settle(image.naturalWidth>0&&image.naturalHeight>0,'Imagem vazia ou inválida');
   image.onerror=()=>settle(false,`Falha de rede, caminho ou formato (${fullSrc})`);
   timer=setTimeout(()=>settle(false,`Tempo limite de ${timeout} ms em ${fullSrc}`),timeout);
   // Query string busts stale GitHub Pages/mobile caches after publishing a replacement ZIP.
   image.src=fullSrc+(fullSrc.includes('?')?'&':'?')+'v=0.8.2';
  });
 }
 const ESSENTIAL_CLIPS=['run','jump','double_jump','left_punch','front_punch','flying_kick','enemy_walk'];
 function validateCore(){
  const missing=ESSENTIAL_CLIPS.filter(k=>!(images.sprite[k]||[]).some(Boolean));
  loadingReport.essentialMissing=missing;
  if(missing.length){
   console.error('[Alpha 0.8.2] FALHA NOS SPRITES ESSENCIAIS:',missing.join(', '));
   el.startBtn.disabled=true;
   el.startBtn.textContent='Não foi possível carregar o jogo';
   if(el.loadWarning){el.loadWarning.hidden=false;el.loadWarning.textContent=
    `Recursos essenciais ausentes: ${missing.join(', ')}. Atualize a página ou confira o relatório no console.`;}
   return false;
  }
  return true;
 }
 function finishLoading(){
  loadDone=validateCore();
  el.startBtn.disabled=!loadDone;
  if(loadDone){
   el.startBtn.textContent='▶ JOGAR AGORA';
   progress('Pronto para jogar');
   if(loadingReport.failed.length && el.loadWarning){
    el.loadWarning.hidden=false;
    el.loadWarning.textContent=`${loadingReport.failed.length} recurso(s) opcional(is) indisponível(is); o jogo pode ser iniciado. Veja detalhes no console.`;
   }
  }
 }
 async function preload(){
  el.cover.style.backgroundImage=`url("${assets.backgrounds.brasilia_dia}")`;
  for(const [key,paths] of Object.entries(assets.sprites))images.sprite[key]=new Array(paths.length).fill(null);
  for(const [key,paths] of Object.entries(assets.impacts))images.fx[key]=new Array(paths.length).fill(null);
  loadingReport.total=Object.values(assets.backgrounds).length+1+1+1+
   Object.values(assets.sprites).reduce((n,arr)=>n+arr.length,0)+
   Object.values(assets.impacts).reduce((n,arr)=>n+arr.length,0);
  loadingReport.completed=0;progress('Carregando imagens');

  // First frame of the critical animation clips: enough to draw and animate with fallback.
  // Keep all frames indexed: NEVER filter(Boolean), which shifts indices/animation timing.
  const essentialTasks=ESSENTIAL_CLIPS.map(k=>loadOne(assets.sprites[k][0],`essencial/sprites/${k}`,{timeout:12000})
    .then(im=>{images.sprite[k][0]=im;}));
  const optionalTasks=[];
  for(const [key,paths] of Object.entries(assets.sprites)){
   for(let i=0;i<paths.length;i++){
    if(i===0&&ESSENTIAL_CLIPS.includes(key))continue;
    optionalTasks.push(()=>loadOne(paths[i],`sprites/${key}/${i+1}`).then(im=>{images.sprite[key][i]=im;}));
   }
  }
  for(const [key,paths] of Object.entries(assets.impacts)){
   for(let i=0;i<paths.length;i++){
    optionalTasks.push(()=>loadOne(paths[i],`fx/${key}/${i+1}`).then(im=>{images.fx[key][i]=im;}));
   }
  }
  optionalTasks.push(()=>loadOne(assets.vote,'coletável/voto').then(im=>{images.vote=im;}));
  optionalTasks.push(()=>loadOne(assets.bonusAtlas,'coletável/bônus-13').then(im=>{images.bonusAtlas=im;}));
  optionalTasks.push(()=>loadOne(assets.foreground?.street,'cenário/rua').then(im=>{images.street=im;}));
  // Prioritize the day panorama, then progressively enhance with the other periods.
  optionalTasks.unshift(()=>loadOne(assets.backgrounds.brasilia_dia,'cenário/manhã').then(im=>{images.bg.brasilia_dia=im;}));
  for(const [key,url] of Object.entries(assets.backgrounds)){
   if(key==='brasilia_dia')continue;
   optionalTasks.push(()=>loadOne(url,`cenário/${key}`).then(im=>{images.bg[key]=im;}));
  }

  // Limit active requests, preventing mobile browsers from being overwhelmed with >100 simultaneous fetches.
  // Run concurrently with critical-first startup; optional requests never block the Play button.
  async function worker(){while(optionalTasks.length){const task=optionalTasks.shift();await task();}}
  const backgroundLoading=Promise.allSettled(Array.from({length:6},()=>worker()));
  await Promise.allSettled(essentialTasks);
  finishLoading();
  await backgroundLoading;
  finishLoading();
 }
 // Isolated test API; only exposed deliberately for ?test=1, never during regular play.
 if(new URLSearchParams(location.search).has('test'))window.__game={state,combat,update,action,start,pause,end,render,resize,loadingReport,
  createEnemy,createVote,createBonus,collectBonus,renderBonusSummary,chooseCity,get currentCity(){return currentCity;},get cityCount(){return cityCount;},get images(){return images;},get impactEffects(){return fx;},get swingEffects(){return swingFx;}};
 preload().catch(e=>{console.error('[Alpha 0.8.2] Falha inesperada no pré-carregamento:',e);finishLoading();});
})();
