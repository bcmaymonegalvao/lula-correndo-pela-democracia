/* Lula - Correndo pela Democracia · Alpha 0.5
   Corrida infinita em 27 capitais sorteadas, votos, inimigos-robô e combos aéreos.
   Sem cronômetro limite, barra de progresso ou fim automático. */
(()=>{
 'use strict';
 const $=id=>document.getElementById(id);
 const cv=$('canvas'), ctx=cv.getContext('2d',{alpha:false});
 const assets=window.GAME_ASSETS, combat=window.GameCombat.create(), animator=window.GameAnimation;
 const el={start:$('start'),game:$('game'),startBtn:$('startBtn'),cover:$('coverImg'),scene:$('scene'),
  votes:$('votes'),benefits:$('benefits'),clock:$('clock'),hits:$('hits'),hearts:$('hearts'),region:$('region'),
  story:$('story'),storyLabel:$('storyLabel'),storyText:$('storyText'),comboLabel:$('comboLabel'),
  pause:$('pause'),veil:$('veil'),veilTitle:$('veilTitle'),veilText:$('veilText'),
  resultData:$('resultData'),finalVotes:$('finalVotes'),finalBenefits:$('finalBenefits'),finalHits:$('finalHits'),
  summaryInfo:$('summaryInfo'),resume:$('resume'),restart:$('restart'),home:$('home')};
 const W=960,H=540,FLOOR=423,SPEED=214,GRAVITY=1300;
 let G=FLOOR, P_X=190,frame=0,last=0,runAge=0,jumpAge=0,landing=0,toastLeft=0;
 let jumpQueue=0, coyote=0,loadDone=false,sceneCycle=window.CityRotation.create();
 let images={bg:{},sprite:{},fx:{},vote:null};
 let fx=[],particles=[],popups=[];
 let nextEnemy=4,nextVote=.9,spawnId=0;
 let currentCity=null,previousCity=null,cityAge=0,cityDuration=14,cityCount=0;
 const state={playing:false,paused:false,ended:false,time:0,world:0,votes:0,benefits:0,
  lives:3,inv:0,playerY:FLOOR,vY:0,onGround:true,jumpsUsed:0,hitCombo:0,bestCombo:0,hitClock:0,
  enemies:[],pickups:[],attack:'',streakHits:0};
 const rnd=(a,b)=>a+Math.random()*(b-a);
 function chooseCity(){
  previousCity=currentCity;currentCity=sceneCycle.next();cityAge=0;cityCount++;
  cityDuration=rnd(12,17);if(el.region)el.region.textContent=currentCity.name;
  if(state.playing)showToast('Nova cidade',currentCity.name,1.55);
 }
 function fmt(t){const sec=Math.max(0,Math.floor(t)),h=Math.floor(sec/3600),m=Math.floor(sec/60)%60,s=sec%60;
  return (h?h.toString().padStart(2,'0')+':':'')+String(m).padStart(2,'0')+':'+String(s).padStart(2,'0');}
 function resize(){
  const r=el.scene.getBoundingClientRect();if(r.width<=0||r.height<=0)return;
  const dpr=Math.min(2,window.devicePixelRatio||1);
  cv.width=Math.max(1,Math.round(r.width*dpr));cv.height=Math.max(1,Math.round(r.height*dpr));
  const scale=Math.min(cv.width/W,cv.height/H);
  ctx.setTransform(scale,0,0,scale,(cv.width-W*scale)/2,(cv.height-H*scale)/2);ctx.imageSmoothingEnabled=false;
  render();
 }
 function drawCity(city,opacity=1){
  if(!city)return;
  ctx.save();ctx.globalAlpha*=opacity;
  const img=images.bg[city.id];
  if(img&&img.width){
   const scale=Math.max(W/img.width,H/img.height),iw=img.width*scale,travel=Math.max(0,iw-W);
   // Last 5s of the city holds final pose; next panorama is shuffled at a new checkpoint
   const progress=Math.min(1,Math.max(0,cityAge/cityDuration));
   ctx.drawImage(img,-travel*progress,0,iw,img.height*scale);
  }else{
   const grad=ctx.createLinearGradient(0,0,0,H);grad.addColorStop(0,'#2783d2');grad.addColorStop(1,'#a1e4c4');
   ctx.fillStyle=grad;ctx.fillRect(0,0,W,H);
  }
  ctx.restore();
 }
 function backdrop(){
  drawCity(currentCity);
  if(previousCity&&cityAge<1){
   ctx.save();ctx.globalAlpha=1-cityAge;drawCity(previousCity);ctx.restore();
  }
  // Subtle distant sky scroll, always behind the gameplay strip
  ctx.fillStyle='#e1fbff21';for(let i=0;i<5;i++){
   const x=((i*223-state.world*.04)%1180+1180)%1180-100;
   ctx.fillRect(x,95+(i%2)*32,64,4);
  }
 }
 function ground(){
  const tile=38,scroll=Math.floor(state.world*.9)%tile;
  ctx.fillStyle='#423225';ctx.fillRect(0,G,W,H-G);
  for(let i=-1;i<W/tile+1;i++){
    const x=i*tile-scroll;
    ctx.fillStyle=i%2?'#695440':'#806a4d';ctx.fillRect(x,G+8,tile-2,24);
    ctx.fillStyle='#4b392c';ctx.fillRect(x,G+33,tile-2,H-G-33);
    ctx.fillStyle='#b4a688';ctx.fillRect(x,G+9,tile-3,2);
  }
  ctx.fillStyle='#423b33';ctx.fillRect(0,G-5,W,13);
  ctx.fillStyle='#c1bba0';ctx.fillRect(0,G-6,W,5);
  ctx.fillStyle='#376344';ctx.fillRect(0,G-10,W,4);
 }
 function drawVote(item){
  const dx=item.x-state.world+P_X;
  const dy=G-item.height+Math.sin(state.time*5+item.id)*4;
  if(images.vote){ctx.save();ctx.shadowColor='#e2ffb0';ctx.shadowBlur=9;
   ctx.drawImage(images.vote,dx-19,dy-21,38,38);ctx.restore();}
  else{ctx.fillStyle='#d8ff99';ctx.fillRect(dx-12,dy-15,24,30);}
 }
 function drawEnemies(){
  for(const e of state.enemies){
   const x=e.x-state.world+P_X;
   if(x<-250||x>W+230)continue;
   if(e.dead&&e.deathAge>.85)continue;
   const anim=e.dead?'enemy_die':e.stun>0?'enemy_hit':'enemy_walk';
   const pics=images.sprite[anim]||[];
   let ix=0;
   if(e.dead)ix=Math.min(pics.length-1,Math.floor(e.deathAge*10));
   else if(e.stun>0)ix=Math.min(pics.length-1,Math.floor((.32-e.stun)*12));
   else ix=Math.floor(e.walkTime*10)%pics.length;
   const pic=pics[ix];if(!pic)continue;
   ctx.save();
   // Face the approaching enemy toward the left.
   ctx.translate(x,G);ctx.scale(-1,1);
   if(e.stun>0&&!e.dead&&Math.floor(e.stun*24)%2)ctx.globalAlpha=.68;
   window.drawFramedSprite(ctx,pic,0,0,1.13);
   ctx.restore();
   if(!e.dead){
    ctx.fillStyle='#102037';ctx.fillRect(x-22,G-116,44,5);
    ctx.fillStyle='#66d7ff';ctx.fillRect(x-21,G-115,42*(e.hp/3),3);
   }
  }
 }
 function drawPlayer(){
  const id=animator.clip({step:combat.state.step,grounded:state.onGround,jumpsUsed:state.jumpsUsed,landing});
  const arr=images.sprite[id]||[];
  const ix=animator.frame({clipId:id,elapsed:runAge,jumpAge,velocityY:state.vY,landing,combat});
  const pic=arr[Math.min(arr.length-1,ix)];if(!pic)return;
  ctx.save();ctx.fillStyle='#08152666';ctx.beginPath();ctx.ellipse(P_X,G-3,34,7,0,0,Math.PI*2);ctx.fill();
  if(state.inv>0&&Math.floor(state.inv*14)%2)ctx.globalAlpha=.42;
  window.drawFramedSprite(ctx,pic,P_X,state.playerY,1.13);
  ctx.restore();
 }
 function drawFx(){
  for(const f of fx){const sprites=images.fx[f.kind]||[];
   const idx=Math.min(7,Math.floor(f.age/.036));const sprite=sprites[idx];
   if(!sprite)continue;
   const x=f.x-state.world+P_X;
   ctx.save();ctx.globalAlpha=Math.max(0,1-f.age/.31);
   ctx.drawImage(sprite,x-90,f.y-90,180,180);ctx.restore();
  }
  for(const p of particles){const x=p.x-state.world+P_X;
   ctx.globalAlpha=Math.max(.05,p.life/.7);ctx.fillStyle=p.color;ctx.fillRect(x,p.y,p.sz,p.sz);
  }
  ctx.globalAlpha=1;
  for(const p of popups){const x=p.x-state.world+P_X;
   ctx.globalAlpha=Math.min(1,p.life*2);
   ctx.font='900 19px system-ui';ctx.textAlign='center';ctx.lineWidth=4;
   ctx.strokeStyle='#0b1930';ctx.strokeText(p.text,x,p.y);ctx.fillStyle=p.color;ctx.fillText(p.text,x,p.y);
  }
  ctx.globalAlpha=1;ctx.textAlign='left';
 }
 function render(){
  if(!loadDone||el.game.classList.contains('hidden'))return;
  ctx.clearRect(0,0,W,H);backdrop();ground();
  for(const vote of state.pickups)if(!vote.got&&vote.x>state.world-200&&vote.x<state.world+W)drawVote(vote);
  drawEnemies();drawPlayer();drawFx();
 }
 function showToast(label,msg,duration=2){el.storyLabel.textContent=label;el.storyText.textContent=msg;
  el.story.classList.add('show');toastLeft=duration;}
 function sparkle(x,y,kind){
  const palette=kind==='flag'?['#62d872','#ffe579','#86bfff']:['#ffe99e','#faf7ec','#f1a65e'];
  for(let i=0;i<11;i++)particles.push({x,y,vx:rnd(-145,145),vy:rnd(-200,-40),life:rnd(.25,.7),sz:rnd(3,6),color:palette[i%3]});
 }
 function hud(){
  el.votes.textContent=state.votes.toLocaleString('pt-BR');
  el.benefits.textContent=state.benefits.toLocaleString('pt-BR');
  el.clock.textContent=fmt(state.time);el.hearts.textContent='♥'.repeat(state.lives);
  el.hits.textContent=state.hitCombo+' hits';
  el.region.textContent=currentCity?currentCity.name:'Carregando…';
  el.comboLabel.textContent=state.hitCombo>=2&&state.hitClock>0?`COMBO ${state.hitCombo} HITS!`:'';
 }
 function createEnemy(){
  state.enemies.push({id:++spawnId,x:state.world+rnd(W-80,W+330),hp:3,stun:0,
   walkTime:rnd(0,2),dead:false,deathAge:0,comboFollow:0});
 }
 function createVote(){
  state.pickups.push({id:++spawnId,x:state.world+rnd(W-90,W+210),height:rnd(52,126),got:false});
 }
 function hurt(){
  if(state.inv>0||state.ended)return;
  state.lives--;state.inv=1.7;
  sparkle(state.world,state.playerY-60,'hammer');
  if(state.lives<=0){end();return;}
  showToast('O tesouraço atacou!',`Restam ${state.lives} vidas.`,1.4);
 }
 function collide(a,b){return a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y;}
 function playerBox(){return {x:state.world-25,y:state.playerY-99,w:52,h:91};}
 function hitEnemy(e){
  if(combat.state.hitTargets.has(e.id))return;
  combat.state.hitTargets.add(e.id);
  e.hp--;e.stun=.32;
  if(e.hp>0){e.comboFollow=1.45;e.x=Math.max(e.x,state.world+94);}
  state.benefits+=1;state.hitCombo=state.hitClock>0?state.hitCombo+1:1;
  state.hitClock=1.55;state.bestCombo=Math.max(state.bestCombo,state.hitCombo);
  fx.push({kind:combat.move().clip,x:e.x-5,y:G-80,age:0});
  popups.push({text:'+1 BENEFÍCIO',x:e.x,y:G-140,life:.9,color:'#a3f6ce'});
  if(e.hp<=0){e.dead=true;e.deathAge=0;e.stun=0;
    sparkle(e.x,G-83,combat.move().clip);
    popups.push({text:'TESOURAÇO DETIDO!',x:e.x,y:G-190,life:1.1,color:'#ffe199'});
  }
 }
 function action(key){
  if(!state.playing||state.paused||state.ended)return false;
  if(key==='jump'){
   if(!state.onGround&&state.jumpsUsed===1){
     state.vY=-520;state.jumpsUsed=2;jumpAge=0;landing=0;jumpQueue=0;
     sparkle(state.world,state.playerY,'flag');return true;
   }
   if(state.onGround||coyote>0){jumpQueue=.15;return true;}
   return false;
  }
  if(key==='combo'||key==='hammer'||key==='flag'){
   const success=combat.press(key==='flag'?'flag':'combo');
   if(success){state.attack=combat.move().clip;return true;}return false;
  }
  return false;
 }
 function update(dt){
  if(!state.playing||state.paused||state.ended||dt<=0)return;
  dt=Math.min(dt,.05);
  state.time+=dt;state.world+=dt*SPEED;cityAge+=dt;
  if(cityAge>=cityDuration)chooseCity();
  nextEnemy-=dt;nextVote-=dt;
  if(nextEnemy<=0){createEnemy();nextEnemy=rnd(3.6,7.8);}
  if(nextVote<=0){createVote();nextVote=rnd(1.12,1.9);}
  if(state.onGround)runAge+=dt;
  if(toastLeft>0){toastLeft-=dt;if(toastLeft<=0)el.story.classList.remove('show');}
  state.inv=Math.max(0,state.inv-dt);landing=Math.max(0,landing-dt);
  state.hitClock=Math.max(0,state.hitClock-dt);
  if(!state.hitClock)state.hitCombo=0;
  // Jump physics: attack input never interrupts jump or double-jump state.
  coyote=state.onGround?.11:Math.max(0,coyote-dt);
  if(jumpQueue>0&&(state.onGround||coyote>0)){
    state.onGround=false;state.vY=-530;state.jumpsUsed=1;jumpAge=0;landing=0;
    jumpQueue=0;coyote=0;
  }
  jumpQueue=Math.max(0,jumpQueue-dt);
  if(!state.onGround){
    jumpAge+=dt;state.vY+=GRAVITY*dt;state.playerY+=state.vY*dt;
    if(state.playerY>=G){state.playerY=G;state.vY=0;state.onGround=true;state.jumpsUsed=0;landing=.13;jumpAge=0;}
  }
  combat.update(dt);state.attack=combat.state.step?combat.move().clip:'';
  const sword=combat.hitbox(state.world,state.playerY);
  const body=playerBox();
  for(const e of state.enemies){
    if(e.dead){e.deathAge+=dt;continue;}
    e.walkTime+=dt;e.stun=Math.max(0,e.stun-dt);
    // Robot advances against the direction of the runner.
    if(e.comboFollow>0){e.x+=SPEED*dt;e.comboFollow-=dt;}
    else if(e.stun<=0)e.x-=dt*24;
    const box={x:e.x-32,y:G-112,w:64,h:109};
    if(sword&&collide(sword,box)){hitEnemy(e);continue;}
    if(!e.dead&&collide(body,box))hurt();
  }
  state.enemies=state.enemies.filter(e=>e.dead?e.deathAge<1.0:e.x>state.world-235);
  for(const v of state.pickups){
   if(v.got)continue;
   const y=G-v.height+Math.sin(state.time*5+v.id)*4;
   if(collide(body,{x:v.x-18,y:y-20,w:36,h:36})){
    v.got=true;state.votes++;
    sparkle(v.x,y,'flag');
    popups.push({text:'+1 VOTO',x:v.x,y:y-25,life:.73,color:'#d2ffc0'});
   }
  }
  state.pickups=state.pickups.filter(v=>!v.got&&v.x>state.world-210);
  for(const e of fx)e.age+=dt;fx=fx.filter(e=>e.age<.31);
  for(const p of particles){p.life-=dt;p.x+=p.vx*dt;p.vy+=500*dt;p.y+=p.vy*dt;}
  particles=particles.filter(p=>p.life>0);
  for(const p of popups){p.life-=dt;p.y-=dt*34;}popups=popups.filter(p=>p.life>0);
  hud();
 }
 function pause(){
  if(!state.playing||state.ended)return;
  state.paused=!state.paused;el.pause.textContent=state.paused?'▶':'Ⅱ';
  if(state.paused){
   el.veil.classList.remove('hidden');el.resultData.classList.remove('hidden');
   el.veilTitle.textContent='Jogo pausado';el.veilText.textContent='Sua corrida infinita aguarda. Continue quando quiser.';
   el.resume.classList.remove('hidden');updateSummary();
  }else{el.veil.classList.add('hidden');last=0;}
 }
 function updateSummary(){
  el.finalVotes.textContent=state.votes.toLocaleString('pt-BR');
  el.finalBenefits.textContent=state.benefits.toLocaleString('pt-BR');
  el.finalHits.textContent=state.bestCombo+' hits';
  el.summaryInfo.textContent='Tempo de jogo: '+fmt(state.time)+' • Cidades visitadas: '+cityCount;
 }
 function end(){
  state.ended=true;state.paused=true;state.lives=0;
  el.veil.classList.remove('hidden');el.resultData.classList.remove('hidden');
  el.veilTitle.textContent='Fim de jogo!';
  el.veilText.textContent=`Parabéns você coletou ${state.votes.toLocaleString('pt-BR')} votos e protegeu ${state.benefits.toLocaleString('pt-BR')} benefícios do tesouraço`;
  el.resume.classList.add('hidden');updateSummary();hud();
 }
 function start(){
  if(!loadDone)return;
  cancelAnimationFrame(frame);
  Object.assign(state,{playing:true,paused:false,ended:false,time:0,world:0,votes:0,benefits:0,
   lives:3,inv:0,playerY:G,vY:0,onGround:true,jumpsUsed:0,hitCombo:0,bestCombo:0,
   hitClock:0,enemies:[],pickups:[],attack:'',streakHits:0});
  combat.reset();sceneCycle=window.CityRotation.create();currentCity=null;previousCity=null;
  cityCount=0;chooseCity();nextEnemy=rnd(2.8,4.8);nextVote=.8;spawnId=0;
  runAge=0;jumpAge=0;landing=0;toastLeft=0;jumpQueue=0;coyote=0;fx=[];particles=[];popups=[];
  el.start.classList.add('hidden');el.game.classList.remove('hidden');el.veil.classList.add('hidden');
  el.story.classList.remove('show');el.pause.textContent='Ⅱ';
  resize();hud();last=0;frame=requestAnimationFrame(loop);
 }
 function loop(ts){
  if(!state.playing)return;
  let dt=last?Math.max(0,(ts-last)/1000):0;last=ts;
  if(dt>1&&!state.paused&&!state.ended){pause();dt=0;}
  while(dt>0){const step=Math.min(1/120,dt);update(step);dt-=step;}
  render();frame=requestAnimationFrame(loop);
 }
 function goHome(){state.playing=false;cancelAnimationFrame(frame);el.game.classList.add('hidden');el.start.classList.remove('hidden');el.veil.classList.add('hidden');}
 function setupTap(id,key){
  const btn=$(id);btn.addEventListener('pointerdown',e=>{e.preventDefault();btn.classList.add('pressed');action(key);});
  for(const name of ['pointerup','pointercancel','pointerleave'])btn.addEventListener(name,()=>btn.classList.remove('pressed'));
  btn.addEventListener('click',()=>{if(!window.PointerEvent)action(key);});
 }
 setupTap('jump','jump');setupTap('hammer','combo');setupTap('flag','flag');
 el.pause.addEventListener('click',pause);el.resume.addEventListener('click',pause);
 el.restart.addEventListener('click',start);el.home.addEventListener('click',goHome);
 el.startBtn.addEventListener('click',start);
 window.addEventListener('keydown',e=>{
  const key=e.key.toLowerCase();if([' ','arrowup','w'].includes(key)){
   e.preventDefault();if(!e.repeat)action('jump');
  }else if(key==='z'&&!e.repeat)action('combo');
  else if(key==='x'&&!e.repeat)action('flag');
  else if(key==='p'&&!e.repeat)pause();
 });
 document.addEventListener('visibilitychange',()=>{if(document.hidden&&state.playing&&!state.paused&&!state.ended)pause();});
 window.addEventListener('resize',()=>{if(!el.game.classList.contains('hidden'))resize();});
 function loadOne(src){return new Promise(resolve=>{
  const im=new Image();im.onload=()=>resolve(im);im.onerror=()=>{console.warn('Asset ausente:',src);resolve(null);};im.src=src;
 });}
 async function preload(){
  el.cover.style.backgroundImage=`url("${assets.backgrounds.fortaleza}")`;
  const jobs=[];for(const [name,url] of Object.entries(assets.backgrounds))jobs.push(loadOne(url).then(im=>{images.bg[name]=im;}));
  for(const [name,paths] of Object.entries(assets.sprites)){
   images.sprite[name]=new Array(paths.length);
   paths.forEach((p,i)=>jobs.push(loadOne(p).then(im=>{images.sprite[name][i]=im;})));
  }
  for(const [name,paths] of Object.entries(assets.impacts)){
   images.fx[name]=new Array(paths.length);
   paths.forEach((p,i)=>jobs.push(loadOne(p).then(im=>{images.fx[name][i]=im;})));
  }
  jobs.push(loadOne(assets.vote).then(im=>{images.vote=im;}));
  await Promise.all(jobs);
  for(const key of Object.keys(images.sprite))images.sprite[key]=images.sprite[key].filter(Boolean);
  for(const key of Object.keys(images.fx))images.fx[key]=images.fx[key].filter(Boolean);
  // All art used in combat must be present, a missing city falls back to a gradient.
  loadDone=Object.entries(assets.sprites).every(([k,v])=>images.sprite[k].length===v.length)
    &&Object.entries(assets.impacts).every(([k,v])=>images.fx[k].length===v.length)&&!!images.vote;
  el.startBtn.disabled=!loadDone;
  el.startBtn.textContent=loadDone?'▶ JOGAR AGORA':'Erro ao carregar imagens — recarregue';
 }
 // Isolated test API; only exposed deliberately for ?test=1, never during regular play.
 if(new URLSearchParams(location.search).has('test'))window.__game={state,combat,update,action,start,pause,end,render,resize,
  createEnemy,createVote,chooseCity,get currentCity(){return currentCity;},get cityCount(){return cityCount;},get images(){return images;}};
 preload().catch(e=>{console.error(e);el.startBtn.textContent='Erro de carregamento — recarregue';});
})();
