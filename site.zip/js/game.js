/* Lula - Correndo pela Democracia · Alpha 0.8
   Corrida infinita em Brasília, votos, inimigos-robô e combos aéreos.
   Sem cronômetro limite, barra de progresso ou fim automático. */
(()=>{
 'use strict';
 const $=id=>document.getElementById(id);
 const cv=$('canvas'), ctx=cv.getContext('2d',{alpha:false});
 const assets=window.GAME_ASSETS, combat=window.GameCombat.create(), animator=window.GameAnimation;
 const el={start:$('start'),game:$('game'),startBtn:$('startBtn'),cover:$('coverImg'),scene:$('scene'),
  votes:$('votes'),benefits:$('benefits'),clock:$('clock'),hits:$('hits'),hearts:$('hearts'),region:$('region'),
  story:$('story'),storyLabel:$('storyLabel'),storyText:$('storyText'),comboLabel:$('comboLabel'),
  pause:$('pause'),veil:$('veil'),veilTitle:$('veilTitle'),veilText:$('veilText'),
  resultData:$('resultData'),finalVotes:$('finalVotes'),finalBenefits:$('finalBenefits'),finalHits:$('finalHits'),
  summaryInfo:$('summaryInfo'),resume:$('resume'),restart:$('restart'),home:$('home')};
 const W=960,H=540,FLOOR=423,SPEED=214,GRAVITY=1300,SCENE_SECONDS=38,SCENE_FADE=4.5;
 let G=FLOOR, P_X=190,frame=0,last=0,runAge=0,jumpAge=0,landing=0,toastLeft=0;
 let jumpQueue=0, coyote=0,loadDone=false,sceneCycle=window.CityRotation.create();
 let images={bg:{},sprite:{},fx:{},vote:null,street:null};
 let fx=[],swingFx=[],particles=[],popups=[];
 let lastAttackSerial=0;
 const robotTintCache=new WeakMap();
 let nextEnemy=4,nextVote=.9,spawnId=0;
 let currentCity=null,previousCity=null,cityAge=0,cityDuration=SCENE_SECONDS,cityCount=0;
 const state={playing:false,paused:false,ended:false,time:0,world:0,votes:0,benefits:0,
  lives:3,inv:0,playerY:FLOOR,vY:0,onGround:true,jumpsUsed:0,hitCombo:0,bestCombo:0,hitClock:0,
  enemies:[],pickups:[],attack:'',streakHits:0};
 const rnd=(a,b)=>a+Math.random()*(b-a);
 function chooseCity(){
  previousCity=currentCity;currentCity=sceneCycle.next();cityAge=0;cityCount++;
  cityDuration=SCENE_SECONDS;if(el.region)el.region.textContent=currentCity.name;
  if(state.playing)showToast('Fase atual',currentCity.name,1.55);
 }
 function fmt(t){const sec=Math.max(0,Math.floor(t)),h=Math.floor(sec/3600),m=Math.floor(sec/60)%60,s=sec%60;
  return (h?h.toString().padStart(2,'0')+':':'')+String(m).padStart(2,'0')+':'+String(s).padStart(2,'0');}
 function resize(){
  const r=el.scene.getBoundingClientRect();if(r.width<=0||r.height<=0)return;
  const dpr=Math.min(2,window.devicePixelRatio||1);
  cv.width=Math.max(1,Math.round(r.width*dpr));cv.height=Math.max(1,Math.round(r.height*dpr));
  const scale=Math.min(cv.width/W,cv.height/H);
  ctx.setTransform(scale,0,0,scale,(cv.width-W*scale)/2,(cv.height-H*scale)/2);ctx.imageSmoothingEnabled=false;
  render();
 }
 // Panoramas are illustrated (not pixelated), with gentle sideways parallax.
 function drawCity(city,opacity=1,age=cityAge){
  if(!city)return;
  ctx.save();ctx.globalAlpha*=opacity;
  const im=images.bg[city.id];
  if(im&&im.width){
   const cover=Math.max(W/im.width,H/im.height)*1.17;
   const dw=im.width*cover,dh=im.height*cover;
   const travel=Math.max(0,dw-W);
   const progress=Math.min(1,Math.max(0,age/SCENE_SECONDS));
   ctx.imageSmoothingEnabled=true; // Realistic illustration, not a pixel sprite.
   ctx.drawImage(im,-travel*progress,(H-dh)/2,dw,dh);
   ctx.imageSmoothingEnabled=false;
  }else{
   const grad=ctx.createLinearGradient(0,0,0,H);grad.addColorStop(0,'#2783d2');grad.addColorStop(1,'#a1e4c4');
   ctx.fillStyle=grad;ctx.fillRect(0,0,W,H);
  }
  ctx.restore();
 }
 // Change atmospheric lighting continuously while afternoon gives way to dusk/night.
 function atmosphere(){
  if(!currentCity)return;
  const progress=Math.min(1,cityAge/SCENE_SECONDS);
  const period=currentCity.period;
  ctx.save();
  if(period==='afternoon'||period==='sunset'){
   const warmth=period==='afternoon'?(.045+.095*progress):(.15+.12*progress);
   const tint=ctx.createLinearGradient(0,0,W,H);
   tint.addColorStop(0,'rgba(255,224,170,0)');
   tint.addColorStop(1,`rgba(251,130,49,${warmth})`);
   ctx.fillStyle=tint;ctx.fillRect(0,0,W,H);
  }
  if(period==='sunset'){
   ctx.fillStyle=`rgba(36,26,63,${.03+.13*progress})`;ctx.fillRect(0,0,W,H);
  }
  if(period==='night'){
   // Daylight drains smoothly from the blue-hour scene, leaving architecture visible.
   ctx.fillStyle=`rgba(1,8,36,${.12+.37*progress})`;ctx.fillRect(0,0,W,H);
   const glow=ctx.createLinearGradient(0,H*.45,0,H);
   glow.addColorStop(0,'rgba(255,173,97,0)');
   glow.addColorStop(1,`rgba(238,134,76,${.045+.085*progress})`);
   ctx.fillStyle=glow;ctx.fillRect(0,0,W,H);
  }
  ctx.restore();
 }
 function backdrop(){
  drawCity(currentCity,1);
  if(previousCity&&cityAge<SCENE_FADE){
   drawCity(previousCity,1-cityAge/SCENE_FADE,SCENE_SECONDS);
  }
  atmosphere();
 }
 function ground(){
  // Constantly moving 16-bit transparent road over the illustrated panoramas.
  const road=images.street;if(!road)return;
  const tileW=1140,roadH=146;
  const offset=((state.world*1.15)%tileW+tileW)%tileW;
  ctx.save();ctx.imageSmoothingEnabled=false;
  for(let x=-offset-tileW;x<W+tileW;x+=tileW){
   ctx.drawImage(road,Math.round(x),G-10,tileW,roadH);
  }
  ctx.restore();
 }
 function drawVote(item){
  const dx=item.x-state.world+P_X;
  const dy=G-item.height+Math.sin(state.time*5+item.id)*4;
  if(images.vote){ctx.save();ctx.shadowColor='#e2ffb0';ctx.shadowBlur=9;
   ctx.drawImage(images.vote,dx-19,dy-21,38,38);ctx.restore();}
  else{ctx.fillStyle='#d8ff99';ctx.fillRect(dx-12,dy-15,24,30);}
 }
 function tintedRobot(pic,color){
  if(!pic||typeof document.createElement!=='function')return pic;
  let colors=robotTintCache.get(pic);
  if(!colors){colors=new Map();robotTintCache.set(pic,colors);}
  if(colors.has(color))return colors.get(color);
  const overlay=document.createElement('canvas');
  if(typeof overlay.getContext!=='function')return pic; // Lightweight test harness.
  overlay.width=pic.width;overlay.height=pic.height;
  const c=overlay.getContext('2d');
  c.drawImage(pic,0,0);
  c.globalCompositeOperation='source-atop';c.fillStyle=color;
  c.fillRect(0,0,overlay.width,overlay.height);
  c.globalCompositeOperation='source-over';
  colors.set(color,overlay);return overlay;
 }
 function drawEnemies(){
  for(const e of state.enemies){
   const x=e.x-state.world+P_X;
   if(x<-270||x>W+270)continue;
   if(e.dead&&e.deathAge>.85)continue;
   const anim=e.dead?'enemy_die':e.stun>0?'enemy_hit':'enemy_walk';
   const pics=images.sprite[anim]||[];
   let ix=0;
   if(e.dead)ix=Math.min(pics.length-1,Math.floor(e.deathAge*10));
   else if(e.stun>0)ix=Math.min(pics.length-1,Math.floor((.32-e.stun)*12));
   else ix=Math.floor(e.walkTime*10)%pics.length;
   const pic=pics[ix];if(!pic)continue;
   // Colored silhouette blinks ONLY when a registered attack intersects this robot.
   const blinking=(e.flash||0)>0&&Math.floor((.34-e.flash)/.055)%2===0;
   const image=blinking?tintedRobot(pic,e.flashColor||'#66dbff'):pic;
   ctx.save();
   // Face the approaching enemy toward the left.
   ctx.translate(x,G);ctx.scale(-1,1);
   if(blinking){ctx.shadowColor=e.flashColor||'#66dbff';ctx.shadowBlur=21;}
   window.drawFramedSprite(ctx,image,0,0,2.26,anim); // exactly 2 × previous 1.13 scale
   ctx.restore();
   if(!e.dead){
    ctx.fillStyle='#102037';ctx.fillRect(x-43,G-227,86,7);
    ctx.fillStyle=e.flashColor||'#66d7ff';ctx.fillRect(x-41,G-225,82*(e.hp/3),4);
   }
  }
 }
 function drawPlayer(){
  const id=animator.clip({step:combat.state.step,grounded:state.onGround,jumpsUsed:state.jumpsUsed,landing});
  const arr=images.sprite[id]||[];
  const ix=animator.frame({clipId:id,elapsed:runAge,jumpAge,velocityY:state.vY,landing,combat});
  const pic=arr[Math.min(arr.length-1,ix)];if(!pic)return;
  ctx.save();ctx.fillStyle='#08152666';ctx.beginPath();ctx.ellipse(P_X,G-3,34,7,0,0,Math.PI*2);ctx.fill();
  if(state.inv>0&&Math.floor(state.inv*14)%2)ctx.globalAlpha=.42;
  window.drawFramedSprite(ctx,pic,P_X,state.playerY,1.13,id);
  ctx.restore();
 }
 // Draw 4-frame RGBA effects; the drawn art itself uses only ~65% of each frame.
 function drawFxSequence(effect,scale=1){
  const sprites=images.fx[effect.kind]||[];if(!sprites.length)return;
  const life=effect.duration||.32;
  const ix=Math.min(sprites.length-1,Math.floor(effect.age/life*sprites.length));
  const sprite=sprites[ix];if(!sprite)return;
  const x=effect.x-state.world+P_X;
  const px=152*(effect.scale||1)*scale;
  ctx.save();ctx.globalAlpha=Math.max(0,1-effect.age/life*.67);
  ctx.drawImage(sprite,x-px/2,effect.y-px/2,px,px);
  ctx.restore();
 }
 function drawFx(){
  // The swing is visible even if it misses; contact bursts only exist for a real hit.
  for(const f of swingFx)drawFxSequence(f,.97);
  for(const f of fx)drawFxSequence(f,1.06);
  for(const p of particles){const x=p.x-state.world+P_X;
   ctx.globalAlpha=Math.max(.05,p.life/.7);ctx.fillStyle=p.color;ctx.fillRect(x,p.y,p.sz,p.sz);
  }
  ctx.globalAlpha=1;
  for(const p of popups){const x=p.x-state.world+P_X;
   ctx.globalAlpha=Math.min(1,p.life*2);
   ctx.font='900 19px system-ui';ctx.textAlign='center';ctx.lineWidth=4;
   ctx.strokeStyle='#0b1930';ctx.strokeText(p.text,x,p.y);ctx.fillStyle=p.color;ctx.fillText(p.text,x,p.y);
  }
  ctx.globalAlpha=1;ctx.textAlign='left';
 }
 function launchFx(kind,x,y,options={}){
  const e={kind,x,y,age:0,duration:options.duration||.32,scale:options.scale||1};
  (options.swing?swingFx:fx).push(e);
  return e;
 }
 function swingAtNewAttack(){
  if(lastAttackSerial===combat.state.serial)return;
  lastAttackSerial=combat.state.serial;
  const m=combat.move();if(!m)return;
  launchFx(m.impact,state.world+(m.clip==='flying_kick'?88:68),
   state.playerY+(m.clip==='flying_kick'?-87:-76),{swing:true,duration:.29,scale:m.clip==='flying_kick'?1.12:.85});
 }
 function render(){
  if(!loadDone||el.game.classList.contains('hidden'))return;
  ctx.clearRect(0,0,W,H);backdrop();ground();
  for(const vote of state.pickups)if(!vote.got&&vote.x>state.world-200&&vote.x<state.world+W)drawVote(vote);
  drawEnemies();drawPlayer();drawFx();
 }
 function showToast(label,msg,duration=2){el.storyLabel.textContent=label;el.storyText.textContent=msg;
  el.story.classList.add('show');toastLeft=duration;}
 function sparkle(x,y,kind){
  const palette=kind==='flying_kick'?['#62d872','#ffe579','#86bfff']:['#ffe99e','#faf7ec','#f1a65e'];
  for(let i=0;i<11;i++)particles.push({x,y,vx:rnd(-145,145),vy:rnd(-200,-40),life:rnd(.25,.7),sz:rnd(3,6),color:palette[i%3]});
 }
 function hud(){
  el.votes.textContent=state.votes.toLocaleString('pt-BR');
  el.benefits.textContent=state.benefits.toLocaleString('pt-BR');
  el.clock.textContent=fmt(state.time);el.hearts.textContent='♥'.repeat(state.lives);
  el.hits.textContent=state.hitCombo+' hits';
  el.region.textContent=currentCity?currentCity.name:'Carregando…';
  el.comboLabel.textContent=state.hitCombo>=2&&state.hitClock>0?`COMBO ${state.hitCombo} HITS!`:'';
 }
 function createEnemy(){
  state.enemies.push({id:++spawnId,x:state.world+rnd(W+60,W+410),hp:3,stun:0,flash:0,flashColor:'#66dbff',
   walkTime:rnd(0,2),dead:false,deathAge:0,comboFollow:0});
 }
 function createVote(){
  state.pickups.push({id:++spawnId,x:state.world+rnd(W-90,W+210),height:rnd(52,126),got:false});
 }
 function hurt(){
  if(state.inv>0||state.ended)return;
  state.lives--;state.inv=1.7;
  sparkle(state.world,state.playerY-60,'front_punch');
  if(state.lives<=0){end();return;}
  showToast('O tesouraço atacou!',`Restam ${state.lives} vidas.`,1.4);
 }
 function collide(a,b){return a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y;}
 function playerBox(){return {x:state.world-25,y:state.playerY-99,w:52,h:91};}
 function hitEnemy(e,attackBox,targetBox){
  if(combat.state.hitTargets.has(e.id))return;
  combat.state.hitTargets.add(e.id);
  e.hp--;e.stun=.32;e.flash=.34;e.flashColor=combat.move().flashColor;
  if(e.hp>0){e.comboFollow=1.45;e.x=Math.max(e.x,state.world+94);}
  state.benefits+=1;state.hitCombo=state.hitClock>0?state.hitCombo+1:1;
  state.hitClock=1.55;state.bestCombo=Math.max(state.bestCombo,state.hitCombo);
  // Efeito acontece NO PONTO DE CONTATO (intersecção real das hitboxes),
  // inclusive quando o jogador acerta durante salto ou pulo duplo.
  const contactX=Math.max(attackBox.x,targetBox.x);
  const contactY=Math.max(attackBox.y,targetBox.y);
  const overlapW=Math.max(0,Math.min(attackBox.x+attackBox.w,targetBox.x+targetBox.w)-contactX);
  const overlapH=Math.max(0,Math.min(attackBox.y+attackBox.h,targetBox.y+targetBox.h)-contactY);
  launchFx(combat.move().impact,contactX+overlapW/2,contactY+overlapH/2,
    {duration:.32,scale:combat.state.step===3?1.07:.91});
  popups.push({text:'+1 BENEFÍCIO',x:e.x,y:G-140,life:.9,color:'#a3f6ce'});
  if(e.hp<=0){e.dead=true;e.deathAge=0;e.stun=0;
    sparkle(e.x,G-83,combat.move().impact);
    popups.push({text:'TESOURAÇO DETIDO!',x:e.x,y:G-190,life:1.1,color:'#ffe199'});
  }
 }
 function action(key){
  if(!state.playing||state.paused||state.ended)return false;
  if(key==='jump'){
   if(!state.onGround&&state.jumpsUsed===1){
     state.vY=-520;state.jumpsUsed=2;jumpAge=0;landing=0;jumpQueue=0;
     launchFx('double_jump',state.world,state.playerY-50,{duration:.36,scale:.92});return true;
   }
   if(state.onGround||coyote>0){jumpQueue=.15;return true;}
   return false;
  }
  if(key==='combo'){
   const success=combat.press('combo');
   if(success){state.attack=combat.move().clip;swingAtNewAttack();return true;}return false;
  }
  return false;
 }
 function update(dt){
  if(!state.playing||state.paused||state.ended||dt<=0)return;
  dt=Math.min(dt,.05);
  state.time+=dt;state.world+=dt*SPEED;cityAge+=dt;
  if(cityAge>=cityDuration)chooseCity();
  nextEnemy-=dt;nextVote-=dt;
  if(nextEnemy<=0){createEnemy();nextEnemy=rnd(3.6,7.8);}
  if(nextVote<=0){createVote();nextVote=rnd(1.12,1.9);}
  if(state.onGround)runAge+=dt;
  if(toastLeft>0){toastLeft-=dt;if(toastLeft<=0)el.story.classList.remove('show');}
  state.inv=Math.max(0,state.inv-dt);landing=Math.max(0,landing-dt);
  state.hitClock=Math.max(0,state.hitClock-dt);
  if(!state.hitClock)state.hitCombo=0;
  // Jump physics: attack input never interrupts jump or double-jump state.
  coyote=state.onGround?.11:Math.max(0,coyote-dt);
  if(jumpQueue>0&&(state.onGround||coyote>0)){
    state.onGround=false;state.vY=-530;state.jumpsUsed=1;jumpAge=0;landing=0;
    launchFx('jump',state.world,G-30,{duration:.34,scale:.8});
    jumpQueue=0;coyote=0;
  }
  jumpQueue=Math.max(0,jumpQueue-dt);
  if(!state.onGround){
    jumpAge+=dt;state.vY+=GRAVITY*dt;state.playerY+=state.vY*dt;
    if(state.playerY>=G){state.playerY=G;state.vY=0;state.onGround=true;state.jumpsUsed=0;landing=.13;jumpAge=0;
     launchFx('jump',state.world,G-26,{duration:.25,scale:.50});}
  }
  combat.update(dt);state.attack=combat.state.step?combat.move().clip:'';
  swingAtNewAttack();
  const sword=combat.hitbox(state.world,state.playerY);
  const body=playerBox();
  for(const e of state.enemies){
    if(e.dead){e.deathAge+=dt;continue;}
    e.walkTime+=dt;e.stun=Math.max(0,e.stun-dt);e.flash=Math.max(0,(e.flash||0)-dt);
    // Robot advances against the direction of the runner.
    if(e.comboFollow>0){e.x+=SPEED*dt;e.comboFollow-=dt;}
    else if(e.stun<=0)e.x-=dt*24;
    const box={x:e.x-51,y:G-222,w:102,h:215}; // robot silhouette doubled
    if(sword&&collide(sword,box)){hitEnemy(e,sword,box);continue;}
    const bodyContact={x:e.x-37,y:G-207,w:74,h:196};
    if(!e.dead&&!combat.state.step&&collide(body,bodyContact))hurt();
  }
  state.enemies=state.enemies.filter(e=>e.dead?e.deathAge<1.0:e.x>state.world-235);
  for(const v of state.pickups){
   if(v.got)continue;
   const y=G-v.height+Math.sin(state.time*5+v.id)*4;
   if(collide(body,{x:v.x-18,y:y-20,w:36,h:36})){
    v.got=true;state.votes++;
    sparkle(v.x,y,'flying_kick');
    popups.push({text:'+1 VOTO',x:v.x,y:y-25,life:.73,color:'#d2ffc0'});
   }
  }
  state.pickups=state.pickups.filter(v=>!v.got&&v.x>state.world-210);
  for(const e of fx)e.age+=dt;fx=fx.filter(e=>e.age<e.duration);
  for(const e of swingFx)e.age+=dt;swingFx=swingFx.filter(e=>e.age<e.duration);
  for(const p of particles){p.life-=dt;p.x+=p.vx*dt;p.vy+=500*dt;p.y+=p.vy*dt;}
  particles=particles.filter(p=>p.life>0);
  for(const p of popups){p.life-=dt;p.y-=dt*34;}popups=popups.filter(p=>p.life>0);
  hud();
 }
 function pause(){
  if(!state.playing||state.ended)return;
  state.paused=!state.paused;el.pause.textContent=state.paused?'▶':'Ⅱ';
  if(state.paused){
   el.veil.classList.remove('hidden');el.resultData.classList.remove('hidden');
   el.veilTitle.textContent='Jogo pausado';el.veilText.textContent='Sua corrida infinita aguarda. Continue quando quiser.';
   el.resume.classList.remove('hidden');updateSummary();
  }else{el.veil.classList.add('hidden');last=0;}
 }
 function updateSummary(){
  el.finalVotes.textContent=state.votes.toLocaleString('pt-BR');
  el.finalBenefits.textContent=state.benefits.toLocaleString('pt-BR');
  el.finalHits.textContent=state.bestCombo+' hits';
  el.summaryInfo.textContent='Tempo de jogo: '+fmt(state.time)+' • Brasília (manhã, tarde, pôr do sol e noite)';
 }
 function end(){
  state.ended=true;state.paused=true;state.lives=0;
  el.veil.classList.remove('hidden');el.resultData.classList.remove('hidden');
  el.veilTitle.textContent='Fim de jogo!';
  el.veilText.textContent=`Parabéns você coletou ${state.votes.toLocaleString('pt-BR')} votos e protegeu ${state.benefits.toLocaleString('pt-BR')} benefícios do tesouraço`;
  el.resume.classList.add('hidden');updateSummary();hud();
 }
 function start(){
  if(!loadDone)return;
  cancelAnimationFrame(frame);
  Object.assign(state,{playing:true,paused:false,ended:false,time:0,world:0,votes:0,benefits:0,
   lives:3,inv:0,playerY:G,vY:0,onGround:true,jumpsUsed:0,hitCombo:0,bestCombo:0,
   hitClock:0,enemies:[],pickups:[],attack:'',streakHits:0});
  combat.reset();sceneCycle=window.CityRotation.create();currentCity=null;previousCity=null;
  cityCount=0;chooseCity();nextEnemy=rnd(2.8,4.8);nextVote=.8;spawnId=0;
  runAge=0;jumpAge=0;landing=0;toastLeft=0;jumpQueue=0;coyote=0;fx=[];swingFx=[];particles=[];popups=[];lastAttackSerial=0;
  el.start.classList.add('hidden');el.game.classList.remove('hidden');el.veil.classList.add('hidden');
  el.story.classList.remove('show');el.pause.textContent='Ⅱ';
  resize();hud();last=0;frame=requestAnimationFrame(loop);
 }
 function loop(ts){
  if(!state.playing)return;
  let dt=last?Math.max(0,(ts-last)/1000):0;last=ts;
  if(dt>1&&!state.paused&&!state.ended){pause();dt=0;}
  while(dt>0){const step=Math.min(1/120,dt);update(step);dt-=step;}
  render();frame=requestAnimationFrame(loop);
 }
 function goHome(){state.playing=false;cancelAnimationFrame(frame);el.game.classList.add('hidden');el.start.classList.remove('hidden');el.veil.classList.add('hidden');}
 function setupTap(id,key){
  const btn=$(id);btn.addEventListener('pointerdown',e=>{e.preventDefault();btn.classList.add('pressed');action(key);});
  for(const name of ['pointerup','pointercancel','pointerleave'])btn.addEventListener(name,()=>btn.classList.remove('pressed'));
  btn.addEventListener('click',()=>{if(!window.PointerEvent)action(key);});
 }
 setupTap('jump','jump');setupTap('comboBtn','combo');
 el.pause.addEventListener('click',pause);el.resume.addEventListener('click',pause);
 el.restart.addEventListener('click',start);el.home.addEventListener('click',goHome);
 el.startBtn.addEventListener('click',start);
 window.addEventListener('keydown',e=>{
  const key=e.key.toLowerCase();if([' ','arrowup','w'].includes(key)){
   e.preventDefault();if(!e.repeat)action('jump');
  }else if(key==='z'&&!e.repeat)action('combo');
  else if(key==='x'&&!e.repeat)action('combo'); // optional keyboard alias, same one move cycle
  else if(key==='p'&&!e.repeat)pause();
 });
 document.addEventListener('visibilitychange',()=>{if(document.hidden&&state.playing&&!state.paused&&!state.ended)pause();});
 window.addEventListener('resize',()=>{if(!el.game.classList.contains('hidden'))resize();});
 function loadOne(src){return new Promise(resolve=>{
  const im=new Image();im.onload=()=>resolve(im);im.onerror=()=>{console.warn('Asset ausente:',src);resolve(null);};im.src=src;
 });}
 async function preload(){
  el.cover.style.backgroundImage=`url("${assets.backgrounds.brasilia_dia}")`;
  const jobs=[];for(const [name,url] of Object.entries(assets.backgrounds))jobs.push(loadOne(url).then(im=>{images.bg[name]=im;}));
  for(const [name,paths] of Object.entries(assets.sprites)){
   images.sprite[name]=new Array(paths.length);
   paths.forEach((p,i)=>jobs.push(loadOne(p).then(im=>{images.sprite[name][i]=im;})));
  }
  for(const [name,paths] of Object.entries(assets.impacts)){
   images.fx[name]=new Array(paths.length);
   paths.forEach((p,i)=>jobs.push(loadOne(p).then(im=>{images.fx[name][i]=im;})));
  }
  jobs.push(loadOne(assets.vote).then(im=>{images.vote=im;}));
  jobs.push(loadOne(assets.foreground.street).then(im=>{images.street=im;}));
  await Promise.all(jobs);
  for(const key of Object.keys(images.sprite))images.sprite[key]=images.sprite[key].filter(Boolean);
  for(const key of Object.keys(images.fx))images.fx[key]=images.fx[key].filter(Boolean);
  // All art used in combat must be present, a missing city falls back to a gradient.
  loadDone=Object.entries(assets.sprites).every(([k,v])=>images.sprite[k].length===v.length)
    &&Object.entries(assets.impacts).every(([k,v])=>images.fx[k].length===v.length)
    &&!!images.vote&&!!images.street&&Object.values(images.bg).every(Boolean);
  el.startBtn.disabled=!loadDone;
  el.startBtn.textContent=loadDone?'▶ JOGAR AGORA':'Erro ao carregar imagens — recarregue';
 }
 // Isolated test API; only exposed deliberately for ?test=1, never during regular play.
 if(new URLSearchParams(location.search).has('test'))window.__game={state,combat,update,action,start,pause,end,render,resize,
  createEnemy,createVote,chooseCity,get currentCity(){return currentCity;},get cityCount(){return cityCount;},get images(){return images;},get impactEffects(){return fx;},get swingEffects(){return swingFx;}};
 preload().catch(e=>{console.error(e);el.startBtn.textContent='Erro de carregamento — recarregue';});
})();
