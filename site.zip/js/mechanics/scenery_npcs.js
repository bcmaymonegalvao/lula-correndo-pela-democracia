/* NPCs decorativos de calçada — módulo de desenvolvimento paralelo.
 * Base para integração: Lula – Correndo pela Democracia, Alpha 0.9.4.
 * Não usa state.enemies, colisões, HP, pontos, timers globais ou RAF próprio.
 */
window.GameSceneryNpcs = (() => {
  'use strict';
  const CELL = 192;
  const FEET_X = 96;
  const FEET_Y = 176;
  const IDS = Object.freeze([
    'eleitores_l', 'trompetista', 'vira_voto', 'amor_contra_odio',
    'artista_pop', 'artista_tropical', 'artista_cancioneiro'
  ]);
  const DEFINITIONS = Object.freeze({
    eleitores_l: Object.freeze({ fps: 6, scale: .83 }),
    trompetista: Object.freeze({ fps: 7, scale: .78 }),
    vira_voto: Object.freeze({ fps: 5, scale: .80 }),
    amor_contra_odio: Object.freeze({ fps: 5, scale: .80 }),
    artista_pop: Object.freeze({ fps: 6, scale: .78 }),
    artista_tropical: Object.freeze({ fps: 6, scale: .78 }),
    artista_cancioneiro: Object.freeze({ fps: 5, scale: .80 })
  });

  function create({ spritePaths = {}, cameraSpeedFactor = 1.15,
    enabled = true, onAssetError } = {}) {
    const framesById = Object.fromEntries(IDS.map(id => [id, [null, null, null, null]]));
    let entries = [];
    let nextPosition = 0;
    let typeCursor = 0;
    let animationTime = 0;
    let previousWorld = 0;
    let active = Boolean(enabled);
    let disposed = false;
    let rng = 0x6a09e667;

    function random() {
      rng ^= rng << 13;
      rng ^= rng >>> 17;
      rng ^= rng << 5;
      return (rng >>> 0) / 4294967296;
    }
    function issue(id, url, reason) {
      if (typeof onAssetError === 'function') onAssetError(id, url, reason);
    }
    function loadImages() {
      if (typeof Image !== 'function') return;
      for (const id of IDS) {
        const urls = Array.isArray(spritePaths[id]) ? spritePaths[id] : [];
        for (let n = 0; n < 4; n++) {
          const url = urls[n];
          if (!url) { issue(id, '', `Frame ${n + 1} não configurado`); continue; }
          const img = new Image();
          img.onload = () => {
            if (disposed) return;
            if (img.naturalWidth !== CELL || img.naturalHeight !== CELL) {
              issue(id, url, 'Dimensões inválidas: esperado 192×192');
              return;
            }
            framesById[id][n] = img;
          };
          img.onerror = () => { if (!disposed) issue(id, url, 'Erro ao carregar imagem'); };
          img.src = url;
        }
      }
    }
    function add(id, position) {
      entries.push({ id, position, phase: random() * .13 });
    }
    function reset(world = 0) {
      rng = 0x6a09e667;
      animationTime = 0;
      previousWorld = Number.isFinite(world) ? world : 0;
      const scroll = previousWorld * cameraSpeedFactor;
      const playerX = 190;
      entries = [];
      typeCursor = 0;
      add(IDS[typeCursor++], scroll + 450 - playerX);
      add(IDS[typeCursor++], scroll + 835 - playerX);
      nextPosition = scroll + 1240 - playerX;
    }
    function update(dt, world) {
      if (disposed || !active || !Number.isFinite(dt) || dt <= 0 || !Number.isFinite(world)) return;
      previousWorld = world;
      animationTime += dt;
      const scroll = world * cameraSpeedFactor;
      // Os NPCs seguem exatamente a velocidade relativa da textura da rua.
      entries = entries.filter(npc => npc.position - scroll + 190 > -210);
      const nearRightEdge = scroll + 960 + 180 - 190;
      while (nextPosition <= nearRightEdge && entries.length < 8) {
        add(IDS[typeCursor % IDS.length], nextPosition);
        typeCursor++;
        nextPosition += 365 + random() * 105;
      }
    }
    function render(ctx, { world = previousWorld, floorY = 423, screenWidth = 960,
      playerScreenX = 190, sidewalkOffsetY = -78, period = 'day' } = {}) {
      if (disposed || !active || !ctx || !Number.isFinite(world)) return;
      const baseY = floorY + sidewalkOffsetY;
      const scroll = world * cameraSpeedFactor;
      ctx.save();
      ctx.imageSmoothingEnabled = false;
      if (period === 'night') ctx.globalAlpha *= .82;
      else if (period === 'sunset') ctx.globalAlpha *= .93;
      for (const npc of entries) {
        const x = npc.position - scroll + playerScreenX;
        if (x < -220 || x > screenWidth + 220) continue;
        const cfg = DEFINITIONS[npc.id];
        const frames = framesById[npc.id];
        const frame = Math.floor((animationTime + npc.phase) * cfg.fps) % 4;
        const pic = frames[frame] || frames.find(Boolean);
        if (!pic) continue; // Recursos de cenário jamais bloqueiam o jogo.
        const s = cfg.scale;
        ctx.drawImage(pic, Math.round(x - FEET_X * s),
          Math.round(baseY - FEET_Y * s), CELL * s, CELL * s);
      }
      ctx.restore();
    }
    function setEnabled(value) { active = Boolean(value); }
    function debugState() {
      return {
        active, disposed, animationTime, world: previousWorld,
        loaded: Object.fromEntries(IDS.map(id => [id, framesById[id].filter(Boolean).length])),
        entries: entries.map(({ id, position, phase }) => ({ id, position, phase }))
      };
    }
    function dispose() {
      disposed = true;
      entries = [];
      for (const id of IDS) framesById[id].fill(null);
    }
    loadImages();
    reset(0);
    return Object.freeze({ reset, update, render, setEnabled, debugState, dispose });
  }
  return Object.freeze({ create, definitions: DEFINITIONS, ids: IDS });
})();
