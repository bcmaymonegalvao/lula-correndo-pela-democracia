/* NPCs animados em corrida rápida pela calçada.
 * Módulo opcional; não interage com física, HP, colisão ou combate.
 * Base da integração: Alpha 0.9.4 com NPCs decorativos já integrados.
 */
window.GameSidewalkRunners = (() => {
  'use strict';
  const DEFINITIONS = Object.freeze({
    corredor_joinha: Object.freeze({ count: 8, fps: 13, scale: 0.25,
      footY: 489, speed: 340, cellWidth: 384, cellHeight: 512 }),
    caminhao: Object.freeze({ count: 4, fps: 9, scale: 0.55,
      footY: 423, speed: 295, cellWidth: 384, cellHeight: 512 })
  });
  const TYPES = Object.freeze(Object.keys(DEFINITIONS));

  function create({ spritePaths = {}, onAssetError, enabled = true, width = 960 } = {}) {
    const sprites = Object.fromEntries(TYPES.map(type => [type, Array(DEFINITIONS[type].count).fill(null)]));
    let participants = [];
    let t = 0;
    let clockToSpawn = 1.3;
    let spawnCounter = 0;
    let active = Boolean(enabled);
    let disposed = false;
    let seed = 0x723641a9;
    let viewportWidth = width;
    function rng() {
      seed ^= seed << 13; seed ^= seed >>> 17; seed ^= seed << 5;
      return (seed >>> 0) / 4294967296;
    }
    function warn(type, url, reason) {
      if (typeof onAssetError === 'function') onAssetError(type, url, reason);
    }
    function loadImages() {
      if (typeof Image !== 'function') return;
      for (const type of TYPES) {
        const cfg = DEFINITIONS[type];
        const urls = Array.isArray(spritePaths[type]) ? spritePaths[type] : [];
        for (let i = 0; i < cfg.count; i++) {
          const src = urls[i];
          if (!src) { warn(type, '', `Quadro ${i + 1} não configurado`); continue; }
          const im = new Image();
          im.onload = () => {
            if (disposed) return;
            if (im.naturalWidth !== cfg.cellWidth || im.naturalHeight !== cfg.cellHeight) {
              warn(type, src, `Dimensões incorretas; esperado ${cfg.cellWidth}×${cfg.cellHeight}`);
              return;
            }
            sprites[type][i] = im;
          };
          im.onerror = () => { if (!disposed) warn(type, src, 'Falha no carregamento'); };
          im.src = src;
        }
      }
    }
    function reset() {
      participants = [];
      seed = 0x723641a9;
      t = 0;
      clockToSpawn = 1.3;
      spawnCounter = 0;
    }
    function spawn(type) {
      if (disposed || !active || !DEFINITIONS[type] || participants.length >= 2) return false;
      // Entrada pela esquerda. Velocidade é medida na TELA, já compensada
      // a rolagem da câmera (mundo/câmera se movem para a esquerda).
      const cfg = DEFINITIONS[type];
      const startX = -cfg.cellWidth * cfg.scale * 0.5 - 8;
      participants.push({ type, x: startX, elapsed: rng() * 0.08,
        speed: cfg.speed * (0.93 + rng() * 0.14) });
      spawnCounter++;
      return true;
    }
    function update(dt, { bossActive = false, screenWidth = viewportWidth } = {}) {
      if (disposed || !active || !Number.isFinite(dt) || dt <= 0) return;
      // O motor principal já limita dt e não chama update durante pausa.
      dt = Math.min(dt, 0.05);
      if (Number.isFinite(screenWidth) && screenWidth > 100) viewportWidth = screenWidth;
      t += dt;
      if (bossActive) {
        // Não atravessar o chefão nem competir com seu sistema de invocação.
        participants = [];
        clockToSpawn = Math.max(clockToSpawn, 2.3);
        return;
      }
      for (const npc of participants) {
        npc.elapsed += dt;
        npc.x += npc.speed * dt;
      }
      participants = participants.filter(npc => {
        const halfWidth = DEFINITIONS[npc.type].cellWidth * DEFINITIONS[npc.type].scale * .5;
        return npc.x - halfWidth < viewportWidth + 32;
      });
      clockToSpawn -= dt;
      if (clockToSpawn <= 0 && participants.length < 2) {
        // Alternância equilibrada; presença esporádica, sem saturar a calçada.
        const type = (spawnCounter % 3 === 1) ? 'caminhao' : 'corredor_joinha';
        spawn(type);
        clockToSpawn = 5.2 + rng() * 2.4;
      }
    }
    function render(ctx, { floorY = 423, sidewalkOffsetY = -78,
      screenWidth = viewportWidth, period = 'day' } = {}) {
      if (disposed || !active || !ctx) return;
      const base = floorY + sidewalkOffsetY;
      ctx.save();
      ctx.imageSmoothingEnabled = false;
      if (period === 'night') ctx.globalAlpha *= .86;
      else if (period === 'sunset') ctx.globalAlpha *= .95;
      for (const npc of participants) {
        const cfg = DEFINITIONS[npc.type];
        const frames = sprites[npc.type];
        const halfWidth = cfg.cellWidth * cfg.scale * .5;
        if (npc.x + halfWidth < 0 || npc.x - halfWidth > screenWidth) continue;
        const index = Math.floor(npc.elapsed * cfg.fps) % cfg.count;
        const pic = frames[index] || frames.find(Boolean);
        if (!pic) continue; // Nunca bloquear a partida por falha cosmética.
        ctx.drawImage(pic,
          Math.round(npc.x - halfWidth), Math.round(base - cfg.footY * cfg.scale),
          Math.round(cfg.cellWidth * cfg.scale), Math.round(cfg.cellHeight * cfg.scale));
      }
      ctx.restore();
    }
    function debugState() {
      return { active, disposed, t, clockToSpawn, spawnCounter,
        loaded: Object.fromEntries(TYPES.map(type => [type, sprites[type].filter(Boolean).length])),
        participants: participants.map(npc => ({ ...npc })) };
    }
    function setEnabled(value) { active = Boolean(value); if (!active) participants = []; }
    function dispose() { disposed = true; participants = []; for (const type of TYPES) sprites[type].fill(null); }
    loadImages(); reset();
    return Object.freeze({ reset, update, render, setEnabled, debugState, spawn, dispose });
  }
  return Object.freeze({ create, definitions: DEFINITIONS, types: TYPES });
})();
