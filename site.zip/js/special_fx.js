/* Alpha 0.8.9: o especial usa o MESMO desenho e tempo no jogo e no laboratório. */
window.GameSpecialVisual=(()=>{
 const DURATION=1.32, HITS=13;
 function drawHero(ctx,p,W,G){
  const x=-160 + p*(W+320), y=G-240 - Math.sin(p*Math.PI)*80;
  ctx.save();ctx.translate(x,y);ctx.rotate(-0.18);ctx.globalAlpha=.95;
  ctx.fillStyle='rgba(123,238,255,.22)';for(let i=0;i<5;i++)ctx.fillRect(-180-i*18,-18+i*4,135,10);
  ctx.fillStyle='rgba(255,227,84,.18)';ctx.beginPath();ctx.ellipse(-8,18,86,42,0,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='#f2c59d';ctx.beginPath();ctx.arc(18,-62,18,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='#c53131';ctx.fillRect(0,-44,44,52);ctx.fillStyle='#ffe173';ctx.fillRect(17,-31,10,10);
  ctx.fillStyle='#5d9b2a';ctx.fillRect(5,6,18,26);ctx.fillRect(24,6,18,26);
  ctx.fillStyle='#f2c59d';ctx.fillRect(-18,-30,18,13);ctx.fillRect(44,-28,20,13);ctx.fillRect(6,30,12,34);ctx.fillRect(29,30,12,34);
  ctx.fillStyle='#20324a';ctx.fillRect(5,64,14,10);ctx.fillRect(28,64,14,10);
  ctx.strokeStyle='#ffffff';ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(62,-18);ctx.lineTo(98,-34);ctx.stroke();ctx.restore();
 }
 function draw(ctx,{time=0,hits=0,width=960,height=540,ground=423,bossX=780}={}){
  const p=Math.max(0,Math.min(1,time/DURATION));
  ctx.save();ctx.fillStyle='rgba(3,5,22,0.42)';ctx.fillRect(0,0,width,height);
  ctx.strokeStyle='rgba(116,229,255,0.24)';ctx.lineWidth=4;
  for(let i=0;i<8;i++){ctx.beginPath();ctx.moveTo(-30,50+i*62);ctx.lineTo(width+20,10+i*62);ctx.stroke();}
  // Chuva de impactos junto ao chefão sempre que um hit é registrado.
  if(hits>0){
   const flash=(Math.sin(time*90)+1)/2;
   const x=bossX+Math.sin(hits*2)*17, y=ground-225+Math.cos(hits*3)*35;
   ctx.save();ctx.translate(x,y);ctx.globalAlpha=.56+flash*.35;ctx.strokeStyle='#fff7b0';ctx.lineWidth=5;
   for(let i=0;i<8;i++){const a=i*Math.PI/4+time*2;ctx.beginPath();ctx.moveTo(Math.cos(a)*14,Math.sin(a)*14);ctx.lineTo(Math.cos(a)*(42+flash*11),Math.sin(a)*(42+flash*11));ctx.stroke();}
   ctx.fillStyle='#76dfff';ctx.beginPath();ctx.arc(0,0,10+flash*9,0,Math.PI*2);ctx.fill();ctx.restore();
  }
  drawHero(ctx,p,width,ground);
  ctx.textAlign='center';ctx.font='900 26px system-ui';ctx.lineWidth=5;ctx.strokeStyle='#041220';
  ctx.strokeText("MAROMBA'S COMUNISTA!",width/2,70);ctx.fillStyle='#ffe57f';ctx.fillText("MAROMBA'S COMUNISTA!",width/2,70);
  ctx.font='900 18px system-ui';ctx.strokeText(`${hits}/${HITS} hits`,width/2,96);ctx.fillStyle='#9feaff';ctx.fillText(`${hits}/${HITS} hits`,width/2,96);
  ctx.textAlign='left';ctx.restore();
 }
 function hitsAt(time){return Math.max(0,Math.min(HITS,Math.floor(Math.max(0,time-.26)/.07)+1))*(time>=.26?1:0);}
 return Object.freeze({DURATION,HITS,draw,hitsAt});
})();
