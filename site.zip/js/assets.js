/* Arte da Alpha 0.9.1: HUD refinada, Tesourinha refeita e NPCs temáticos atualizados. */
window.GAME_ASSETS = {
  "backgrounds": {
    "brasilia_dia": "assets/backgrounds/brasilia/brasilia_dia.webp",
    "brasilia_tarde": "assets/backgrounds/brasilia/brasilia_tarde.webp",
    "brasilia_entardecer": "assets/backgrounds/brasilia/brasilia_entardecer.webp",
    "brasilia_noite": "assets/backgrounds/brasilia/brasilia_noite.webp"
  },
  "bosses": {
    "final": [
      "assets/bosses/final/walk_01.webp",
      "assets/bosses/final/walk_02.webp",
      "assets/bosses/final/walk_03.webp",
      "assets/bosses/final/walk_04.webp",
      "assets/bosses/final/hit_01.webp",
      "assets/bosses/final/hit_02.webp",
      "assets/bosses/final/hit_03.webp",
      "assets/bosses/final/die_01.webp",
      "assets/bosses/final/die_02.webp",
      "assets/bosses/final/die_03.webp",
      "assets/bosses/final/die_04.webp"
]
  },
  "sprites": {
    "double_jump": [
      "assets/sprites/animacoes/double_jump/01.webp",
      "assets/sprites/animacoes/double_jump/02.webp",
      "assets/sprites/animacoes/double_jump/03.webp",
      "assets/sprites/animacoes/double_jump/04.webp",
      "assets/sprites/animacoes/double_jump/05.webp",
      "assets/sprites/animacoes/double_jump/06.webp",
      "assets/sprites/animacoes/double_jump/07.webp",
      "assets/sprites/animacoes/double_jump/08.webp"
    ],
    "enemy_die": [
      "assets/sprites/animacoes/enemy_die/01.webp",
      "assets/sprites/animacoes/enemy_die/02.webp",
      "assets/sprites/animacoes/enemy_die/03.webp",
      "assets/sprites/animacoes/enemy_die/04.webp",
      "assets/sprites/animacoes/enemy_die/05.webp",
      "assets/sprites/animacoes/enemy_die/06.webp",
      "assets/sprites/animacoes/enemy_die/07.webp",
      "assets/sprites/animacoes/enemy_die/08.webp"
    ],
    "enemy_hit": [
      "assets/sprites/animacoes/enemy_hit/01.webp",
      "assets/sprites/animacoes/enemy_hit/02.webp",
      "assets/sprites/animacoes/enemy_hit/03.webp",
      "assets/sprites/animacoes/enemy_hit/04.webp"
    ],
    "enemy_walk": [
      "assets/sprites/animacoes/enemy_walk/01.webp",
      "assets/sprites/animacoes/enemy_walk/02.webp",
      "assets/sprites/animacoes/enemy_walk/03.webp",
      "assets/sprites/animacoes/enemy_walk/04.webp",
      "assets/sprites/animacoes/enemy_walk/05.webp",
      "assets/sprites/animacoes/enemy_walk/06.webp",
      "assets/sprites/animacoes/enemy_walk/07.webp",
      "assets/sprites/animacoes/enemy_walk/08.webp",
      "assets/sprites/animacoes/enemy_walk/09.webp",
      "assets/sprites/animacoes/enemy_walk/10.webp",
      "assets/sprites/animacoes/enemy_walk/11.webp",
      "assets/sprites/animacoes/enemy_walk/12.webp"
    ],
    "flying_kick": [
      "assets/sprites/animacoes/flying_kick/05.webp",
      "assets/sprites/animacoes/flying_kick/06.webp",
      "assets/sprites/animacoes/flying_kick/07.webp",
      "assets/sprites/animacoes/flying_kick/08.webp"
    ],
    "front_punch": [
      "assets/sprites/animacoes/front_punch/05.webp",
      "assets/sprites/animacoes/front_punch/06.webp",
      "assets/sprites/animacoes/front_punch/07.webp",
      "assets/sprites/animacoes/front_punch/08.webp"
    ],
    "jump": [
      "assets/sprites/animacoes/jump/01.webp",
      "assets/sprites/animacoes/jump/02.webp",
      "assets/sprites/animacoes/jump/03.webp",
      "assets/sprites/animacoes/jump/04.webp",
      "assets/sprites/animacoes/jump/05.webp",
      "assets/sprites/animacoes/jump/06.webp",
      "assets/sprites/animacoes/jump/07.webp",
      "assets/sprites/animacoes/jump/08.webp",
      "assets/sprites/animacoes/jump/09.webp",
      "assets/sprites/animacoes/jump/10.webp",
      "assets/sprites/animacoes/jump/11.webp",
      "assets/sprites/animacoes/jump/12.webp"
    ],
    "run": [
      "assets/sprites/animacoes/run/01.webp",
      "assets/sprites/animacoes/run/02.webp",
      "assets/sprites/animacoes/run/03.webp",
      "assets/sprites/animacoes/run/04.webp",
      "assets/sprites/animacoes/run/05.webp",
      "assets/sprites/animacoes/run/06.webp",
      "assets/sprites/animacoes/run/07.webp",
      "assets/sprites/animacoes/run/08.webp"
    ],
    "left_punch": [
      "assets/sprites/animacoes/left_punch/05.webp",
      "assets/sprites/animacoes/left_punch/06.webp",
      "assets/sprites/animacoes/left_punch/07.webp",
      "assets/sprites/animacoes/left_punch/08.webp"
    ]
  },
  "impacts": {
    "left_punch": [
      "assets/sprites/fx08/left_punch/01.webp",
      "assets/sprites/fx08/left_punch/02.webp",
      "assets/sprites/fx08/left_punch/03.webp",
      "assets/sprites/fx08/left_punch/04.webp"
    ],
    "front_punch": [
      "assets/sprites/fx08/front_punch/01.webp",
      "assets/sprites/fx08/front_punch/02.webp",
      "assets/sprites/fx08/front_punch/03.webp",
      "assets/sprites/fx08/front_punch/04.webp"
    ],
    "flying_kick": [
      "assets/sprites/fx08/flying_kick/01.webp",
      "assets/sprites/fx08/flying_kick/02.webp",
      "assets/sprites/fx08/flying_kick/03.webp",
      "assets/sprites/fx08/flying_kick/04.webp"
    ],
    "jump": [
      "assets/sprites/fx08/jump/01.webp",
      "assets/sprites/fx08/jump/02.webp",
      "assets/sprites/fx08/jump/03.webp",
      "assets/sprites/fx08/jump/04.webp"
    ],
    "double_jump": [
      "assets/sprites/fx08/double_jump/01.webp",
      "assets/sprites/fx08/double_jump/02.webp",
      "assets/sprites/fx08/double_jump/03.webp",
      "assets/sprites/fx08/double_jump/04.webp"
    ]
  },
  "bossMinions": {
    "miliciano": [
      "assets/sprites/boss_minions/miliciano/walk1.webp",
      "assets/sprites/boss_minions/miliciano/walk2.webp",
      "assets/sprites/boss_minions/miliciano/attack.webp",
      "assets/sprites/boss_minions/miliciano/dead.webp"
    ],
    "petroleo": [
      "assets/sprites/boss_minions/petroleo/walk1.webp",
      "assets/sprites/boss_minions/petroleo/walk2.webp",
      "assets/sprites/boss_minions/petroleo/attack.webp",
      "assets/sprites/boss_minions/petroleo/dead.webp"
    ],
    "desmatamento": [
      "assets/sprites/boss_minions/desmatamento/walk1.webp",
      "assets/sprites/boss_minions/desmatamento/walk2.webp",
      "assets/sprites/boss_minions/desmatamento/attack.webp",
      "assets/sprites/boss_minions/desmatamento/dead.webp"
    ],
    "terras_raras": [
      "assets/sprites/boss_minions/terras_raras/walk1.webp",
      "assets/sprites/boss_minions/terras_raras/walk2.webp",
      "assets/sprites/boss_minions/terras_raras/attack.webp",
      "assets/sprites/boss_minions/terras_raras/dead.webp"
    ],
    "fake_news": [
      "assets/sprites/boss_minions/fake_news/walk1.webp",
      "assets/sprites/boss_minions/fake_news/walk2.webp",
      "assets/sprites/boss_minions/fake_news/attack.webp",
      "assets/sprites/boss_minions/fake_news/dead.webp"
    ],
    "orcamento_secreto": [
      "assets/sprites/boss_minions/orcamento_secreto/walk1.webp",
      "assets/sprites/boss_minions/orcamento_secreto/walk2.webp",
      "assets/sprites/boss_minions/orcamento_secreto/attack.webp",
      "assets/sprites/boss_minions/orcamento_secreto/dead.webp"
    ],
  },
  "vote": "assets/sprites/coletaveis/voto.webp",
  "bonusAtlas": "assets/sprites/coletaveis/bonus_13x4.webp",
  "foreground": {
    "street": "assets/foreground/rua_brasilia_loop.webp"
  }
};
