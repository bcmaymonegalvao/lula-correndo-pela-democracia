/* Assets reais, separados do código. Alpha 0.7. */
window.GAME_ASSETS = {
  "backgrounds": {
    "brasilia": "assets/backgrounds/cidades/brasilia.webp"
  },
  "sprites": {
    "double_jump": [
      "assets/sprites/animacoes/double_jump/01.webp",
      "assets/sprites/animacoes/double_jump/02.webp",
      "assets/sprites/animacoes/double_jump/03.webp",
      "assets/sprites/animacoes/double_jump/04.webp",
      "assets/sprites/animacoes/double_jump/05.webp",
      "assets/sprites/animacoes/double_jump/06.webp",
      "assets/sprites/animacoes/double_jump/07.webp",
      "assets/sprites/animacoes/double_jump/08.webp"
    ],
    "enemy_die": [
      "assets/sprites/animacoes/enemy_die/01.webp",
      "assets/sprites/animacoes/enemy_die/02.webp",
      "assets/sprites/animacoes/enemy_die/03.webp",
      "assets/sprites/animacoes/enemy_die/04.webp",
      "assets/sprites/animacoes/enemy_die/05.webp",
      "assets/sprites/animacoes/enemy_die/06.webp",
      "assets/sprites/animacoes/enemy_die/07.webp",
      "assets/sprites/animacoes/enemy_die/08.webp"
    ],
    "enemy_heavy": [
      "assets/sprites/animacoes/enemy_heavy/01.webp",
      "assets/sprites/animacoes/enemy_heavy/02.webp",
      "assets/sprites/animacoes/enemy_heavy/03.webp",
      "assets/sprites/animacoes/enemy_heavy/04.webp"
    ],
    "enemy_hit": [
      "assets/sprites/animacoes/enemy_hit/01.webp",
      "assets/sprites/animacoes/enemy_hit/02.webp",
      "assets/sprites/animacoes/enemy_hit/03.webp",
      "assets/sprites/animacoes/enemy_hit/04.webp"
    ],
    "enemy_walk": [
      "assets/sprites/animacoes/enemy_walk/01.webp",
      "assets/sprites/animacoes/enemy_walk/02.webp",
      "assets/sprites/animacoes/enemy_walk/03.webp",
      "assets/sprites/animacoes/enemy_walk/04.webp",
      "assets/sprites/animacoes/enemy_walk/05.webp",
      "assets/sprites/animacoes/enemy_walk/06.webp",
      "assets/sprites/animacoes/enemy_walk/07.webp",
      "assets/sprites/animacoes/enemy_walk/08.webp",
      "assets/sprites/animacoes/enemy_walk/09.webp",
      "assets/sprites/animacoes/enemy_walk/10.webp",
      "assets/sprites/animacoes/enemy_walk/11.webp",
      "assets/sprites/animacoes/enemy_walk/12.webp"
    ],
    "flying_kick": [
      "assets/sprites/animacoes/flying_kick/01.webp",
      "assets/sprites/animacoes/flying_kick/02.webp",
      "assets/sprites/animacoes/flying_kick/03.webp",
      "assets/sprites/animacoes/flying_kick/04.webp",
      "assets/sprites/animacoes/flying_kick/05.webp",
      "assets/sprites/animacoes/flying_kick/06.webp",
      "assets/sprites/animacoes/flying_kick/07.webp",
      "assets/sprites/animacoes/flying_kick/08.webp"
    ],
    "front_punch": [
      "assets/sprites/animacoes/front_punch/01.webp",
      "assets/sprites/animacoes/front_punch/02.webp",
      "assets/sprites/animacoes/front_punch/03.webp",
      "assets/sprites/animacoes/front_punch/04.webp",
      "assets/sprites/animacoes/front_punch/05.webp",
      "assets/sprites/animacoes/front_punch/06.webp",
      "assets/sprites/animacoes/front_punch/07.webp",
      "assets/sprites/animacoes/front_punch/08.webp"
    ],
    "jump": [
      "assets/sprites/animacoes/jump/01.webp",
      "assets/sprites/animacoes/jump/02.webp",
      "assets/sprites/animacoes/jump/03.webp",
      "assets/sprites/animacoes/jump/04.webp",
      "assets/sprites/animacoes/jump/05.webp",
      "assets/sprites/animacoes/jump/06.webp",
      "assets/sprites/animacoes/jump/07.webp",
      "assets/sprites/animacoes/jump/08.webp",
      "assets/sprites/animacoes/jump/09.webp",
      "assets/sprites/animacoes/jump/10.webp",
      "assets/sprites/animacoes/jump/11.webp",
      "assets/sprites/animacoes/jump/12.webp"
    ],
    "run": [
      "assets/sprites/animacoes/run/01.webp",
      "assets/sprites/animacoes/run/02.webp",
      "assets/sprites/animacoes/run/03.webp",
      "assets/sprites/animacoes/run/04.webp",
      "assets/sprites/animacoes/run/05.webp",
      "assets/sprites/animacoes/run/06.webp",
      "assets/sprites/animacoes/run/07.webp",
      "assets/sprites/animacoes/run/08.webp"
    ],
    "left_punch": [
      "assets/sprites/animacoes/left_punch/01.webp",
      "assets/sprites/animacoes/left_punch/02.webp",
      "assets/sprites/animacoes/left_punch/03.webp",
      "assets/sprites/animacoes/left_punch/04.webp",
      "assets/sprites/animacoes/left_punch/05.webp",
      "assets/sprites/animacoes/left_punch/06.webp",
      "assets/sprites/animacoes/left_punch/07.webp",
      "assets/sprites/animacoes/left_punch/08.webp"
    ]
  },
  "impacts": {
    "flying_kick": [
      "assets/sprites/impactos/flying_kick/01.webp",
      "assets/sprites/impactos/flying_kick/02.webp",
      "assets/sprites/impactos/flying_kick/03.webp",
      "assets/sprites/impactos/flying_kick/04.webp",
      "assets/sprites/impactos/flying_kick/05.webp",
      "assets/sprites/impactos/flying_kick/06.webp",
      "assets/sprites/impactos/flying_kick/07.webp",
      "assets/sprites/impactos/flying_kick/08.webp"
    ],
    "front_punch": [
      "assets/sprites/impactos/front_punch/01.webp",
      "assets/sprites/impactos/front_punch/02.webp",
      "assets/sprites/impactos/front_punch/03.webp",
      "assets/sprites/impactos/front_punch/04.webp",
      "assets/sprites/impactos/front_punch/05.webp",
      "assets/sprites/impactos/front_punch/06.webp",
      "assets/sprites/impactos/front_punch/07.webp",
      "assets/sprites/impactos/front_punch/08.webp"
    ],
    "left_punch": [
      "assets/sprites/impactos/left_punch/01.webp",
      "assets/sprites/impactos/left_punch/02.webp",
      "assets/sprites/impactos/left_punch/03.webp",
      "assets/sprites/impactos/left_punch/04.webp",
      "assets/sprites/impactos/left_punch/05.webp",
      "assets/sprites/impactos/left_punch/06.webp",
      "assets/sprites/impactos/left_punch/07.webp",
      "assets/sprites/impactos/left_punch/08.webp"
    ]
  },
  "vote": "assets/sprites/coletaveis/voto.webp"
};
