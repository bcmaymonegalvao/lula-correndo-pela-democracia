/* Assets reais, separados do código. Alpha 0.6. */
window.GAME_ASSETS = {
  "backgrounds": {
    "brasilia": "assets/backgrounds/cidades/brasilia.webp"
  },
  "sprites": {
    "double_jump": [
      "assets/sprites/animacoes/double_jump/01.webp",
      "assets/sprites/animacoes/double_jump/02.webp",
      "assets/sprites/animacoes/double_jump/03.webp",
      "assets/sprites/animacoes/double_jump/04.webp",
      "assets/sprites/animacoes/double_jump/05.webp",
      "assets/sprites/animacoes/double_jump/06.webp",
      "assets/sprites/animacoes/double_jump/07.webp",
      "assets/sprites/animacoes/double_jump/08.webp"
    ],
    "enemy_die": [
      "assets/sprites/animacoes/enemy_die/01.webp",
      "assets/sprites/animacoes/enemy_die/02.webp",
      "assets/sprites/animacoes/enemy_die/03.webp",
      "assets/sprites/animacoes/enemy_die/04.webp",
      "assets/sprites/animacoes/enemy_die/05.webp",
      "assets/sprites/animacoes/enemy_die/06.webp",
      "assets/sprites/animacoes/enemy_die/07.webp",
      "assets/sprites/animacoes/enemy_die/08.webp"
    ],
    "enemy_heavy": [
      "assets/sprites/animacoes/enemy_heavy/01.webp",
      "assets/sprites/animacoes/enemy_heavy/02.webp",
      "assets/sprites/animacoes/enemy_heavy/03.webp",
      "assets/sprites/animacoes/enemy_heavy/04.webp"
    ],
    "enemy_hit": [
      "assets/sprites/animacoes/enemy_hit/01.webp",
      "assets/sprites/animacoes/enemy_hit/02.webp",
      "assets/sprites/animacoes/enemy_hit/03.webp",
      "assets/sprites/animacoes/enemy_hit/04.webp"
    ],
    "enemy_walk": [
      "assets/sprites/animacoes/enemy_walk/01.webp",
      "assets/sprites/animacoes/enemy_walk/02.webp",
      "assets/sprites/animacoes/enemy_walk/03.webp",
      "assets/sprites/animacoes/enemy_walk/04.webp",
      "assets/sprites/animacoes/enemy_walk/05.webp",
      "assets/sprites/animacoes/enemy_walk/06.webp",
      "assets/sprites/animacoes/enemy_walk/07.webp",
      "assets/sprites/animacoes/enemy_walk/08.webp",
      "assets/sprites/animacoes/enemy_walk/09.webp",
      "assets/sprites/animacoes/enemy_walk/10.webp",
      "assets/sprites/animacoes/enemy_walk/11.webp",
      "assets/sprites/animacoes/enemy_walk/12.webp"
    ],
    "flag": [
      "assets/sprites/animacoes/flag/01.webp",
      "assets/sprites/animacoes/flag/02.webp",
      "assets/sprites/animacoes/flag/03.webp",
      "assets/sprites/animacoes/flag/04.webp",
      "assets/sprites/animacoes/flag/05.webp",
      "assets/sprites/animacoes/flag/06.webp",
      "assets/sprites/animacoes/flag/07.webp",
      "assets/sprites/animacoes/flag/08.webp"
    ],
    "hammer": [
      "assets/sprites/animacoes/hammer/01.webp",
      "assets/sprites/animacoes/hammer/02.webp",
      "assets/sprites/animacoes/hammer/03.webp",
      "assets/sprites/animacoes/hammer/04.webp",
      "assets/sprites/animacoes/hammer/05.webp",
      "assets/sprites/animacoes/hammer/06.webp",
      "assets/sprites/animacoes/hammer/07.webp",
      "assets/sprites/animacoes/hammer/08.webp"
    ],
    "jump": [
      "assets/sprites/animacoes/jump/01.webp",
      "assets/sprites/animacoes/jump/02.webp",
      "assets/sprites/animacoes/jump/03.webp",
      "assets/sprites/animacoes/jump/04.webp",
      "assets/sprites/animacoes/jump/05.webp",
      "assets/sprites/animacoes/jump/06.webp",
      "assets/sprites/animacoes/jump/07.webp",
      "assets/sprites/animacoes/jump/08.webp",
      "assets/sprites/animacoes/jump/09.webp",
      "assets/sprites/animacoes/jump/10.webp",
      "assets/sprites/animacoes/jump/11.webp",
      "assets/sprites/animacoes/jump/12.webp"
    ],
    "run": [
      "assets/sprites/animacoes/run/01.webp",
      "assets/sprites/animacoes/run/02.webp",
      "assets/sprites/animacoes/run/03.webp",
      "assets/sprites/animacoes/run/04.webp",
      "assets/sprites/animacoes/run/05.webp",
      "assets/sprites/animacoes/run/06.webp",
      "assets/sprites/animacoes/run/07.webp",
      "assets/sprites/animacoes/run/08.webp"
    ],
    "scythe": [
      "assets/sprites/animacoes/scythe/01.webp",
      "assets/sprites/animacoes/scythe/02.webp",
      "assets/sprites/animacoes/scythe/03.webp",
      "assets/sprites/animacoes/scythe/04.webp",
      "assets/sprites/animacoes/scythe/05.webp",
      "assets/sprites/animacoes/scythe/06.webp",
      "assets/sprites/animacoes/scythe/07.webp",
      "assets/sprites/animacoes/scythe/08.webp"
    ]
  },
  "impacts": {
    "flag": [
      "assets/sprites/impactos/flag/01.webp",
      "assets/sprites/impactos/flag/02.webp",
      "assets/sprites/impactos/flag/03.webp",
      "assets/sprites/impactos/flag/04.webp",
      "assets/sprites/impactos/flag/05.webp",
      "assets/sprites/impactos/flag/06.webp",
      "assets/sprites/impactos/flag/07.webp",
      "assets/sprites/impactos/flag/08.webp"
    ],
    "hammer": [
      "assets/sprites/impactos/hammer/01.webp",
      "assets/sprites/impactos/hammer/02.webp",
      "assets/sprites/impactos/hammer/03.webp",
      "assets/sprites/impactos/hammer/04.webp",
      "assets/sprites/impactos/hammer/05.webp",
      "assets/sprites/impactos/hammer/06.webp",
      "assets/sprites/impactos/hammer/07.webp",
      "assets/sprites/impactos/hammer/08.webp"
    ],
    "scythe": [
      "assets/sprites/impactos/scythe/01.webp",
      "assets/sprites/impactos/scythe/02.webp",
      "assets/sprites/impactos/scythe/03.webp",
      "assets/sprites/impactos/scythe/04.webp",
      "assets/sprites/impactos/scythe/05.webp",
      "assets/sprites/impactos/scythe/06.webp",
      "assets/sprites/impactos/scythe/07.webp",
      "assets/sprites/impactos/scythe/08.webp"
    ]
  },
  "vote": "assets/sprites/coletaveis/voto.webp"
};
