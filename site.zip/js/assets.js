/* Arte da Alpha 0.8.3: panoramas realistas e efeitos 4 quadros RGBA. */
window.GAME_ASSETS = {
  "backgrounds": {
    "brasilia_dia": "assets/backgrounds/brasilia/brasilia_dia.webp",
    "brasilia_tarde": "assets/backgrounds/brasilia/brasilia_tarde.webp",
    "brasilia_entardecer": "assets/backgrounds/brasilia/brasilia_entardecer.webp",
    "brasilia_noite": "assets/backgrounds/brasilia/brasilia_noite.webp"
  },
  "bosses": {
    "seis_por_um": [
        "assets/bosses/seis_por_um/01.webp",
        "assets/bosses/seis_por_um/02.webp",
        "assets/bosses/seis_por_um/03.webp",
        "assets/bosses/seis_por_um/04.webp",
        "assets/bosses/seis_por_um/05.webp",
        "assets/bosses/seis_por_um/06.webp",
        "assets/bosses/seis_por_um/07.webp",
        "assets/bosses/seis_por_um/08.webp"
    ],
    "aposentadoria": [
        "assets/bosses/aposentadoria/01.webp",
        "assets/bosses/aposentadoria/02.webp",
        "assets/bosses/aposentadoria/03.webp",
        "assets/bosses/aposentadoria/04.webp",
        "assets/bosses/aposentadoria/05.webp",
        "assets/bosses/aposentadoria/06.webp",
        "assets/bosses/aposentadoria/07.webp",
        "assets/bosses/aposentadoria/08.webp"
    ],
    "saude_educacao": [
        "assets/bosses/saude_educacao/01.webp",
        "assets/bosses/saude_educacao/02.webp",
        "assets/bosses/saude_educacao/03.webp",
        "assets/bosses/saude_educacao/04.webp",
        "assets/bosses/saude_educacao/05.webp",
        "assets/bosses/saude_educacao/06.webp",
        "assets/bosses/saude_educacao/07.webp",
        "assets/bosses/saude_educacao/08.webp"
    ],
    "privatizacao": [
        "assets/bosses/privatizacao/01.webp",
        "assets/bosses/privatizacao/02.webp",
        "assets/bosses/privatizacao/03.webp",
        "assets/bosses/privatizacao/04.webp",
        "assets/bosses/privatizacao/05.webp",
        "assets/bosses/privatizacao/06.webp",
        "assets/bosses/privatizacao/07.webp",
        "assets/bosses/privatizacao/08.webp"
    ],
    "entreguismo": [
        "assets/bosses/entreguismo/01.webp",
        "assets/bosses/entreguismo/02.webp",
        "assets/bosses/entreguismo/03.webp",
        "assets/bosses/entreguismo/04.webp",
        "assets/bosses/entreguismo/05.webp",
        "assets/bosses/entreguismo/06.webp",
        "assets/bosses/entreguismo/07.webp",
        "assets/bosses/entreguismo/08.webp"
    ],
    "punitivismo": [
        "assets/bosses/punitivismo/01.webp",
        "assets/bosses/punitivismo/02.webp",
        "assets/bosses/punitivismo/03.webp",
        "assets/bosses/punitivismo/04.webp",
        "assets/bosses/punitivismo/05.webp",
        "assets/bosses/punitivismo/06.webp",
        "assets/bosses/punitivismo/07.webp",
        "assets/bosses/punitivismo/08.webp"
    ],
    "final": [
        "assets/bosses/final/01.webp",
        "assets/bosses/final/02.webp",
        "assets/bosses/final/03.webp",
        "assets/bosses/final/04.webp"
    ]
},
  "sprites": {
    "double_jump": [
      "assets/sprites/animacoes/double_jump/01.webp",
      "assets/sprites/animacoes/double_jump/02.webp",
      "assets/sprites/animacoes/double_jump/03.webp",
      "assets/sprites/animacoes/double_jump/04.webp",
      "assets/sprites/animacoes/double_jump/05.webp",
      "assets/sprites/animacoes/double_jump/06.webp",
      "assets/sprites/animacoes/double_jump/07.webp",
      "assets/sprites/animacoes/double_jump/08.webp"
    ],
    "enemy_die": [
      "assets/sprites/animacoes/enemy_die/01.webp",
      "assets/sprites/animacoes/enemy_die/02.webp",
      "assets/sprites/animacoes/enemy_die/03.webp",
      "assets/sprites/animacoes/enemy_die/04.webp",
      "assets/sprites/animacoes/enemy_die/05.webp",
      "assets/sprites/animacoes/enemy_die/06.webp",
      "assets/sprites/animacoes/enemy_die/07.webp",
      "assets/sprites/animacoes/enemy_die/08.webp"
    ],
    "enemy_heavy": [
      "assets/sprites/animacoes/enemy_heavy/01.webp",
      "assets/sprites/animacoes/enemy_heavy/02.webp",
      "assets/sprites/animacoes/enemy_heavy/03.webp",
      "assets/sprites/animacoes/enemy_heavy/04.webp"
    ],
    "enemy_hit": [
      "assets/sprites/animacoes/enemy_hit/01.webp",
      "assets/sprites/animacoes/enemy_hit/02.webp",
      "assets/sprites/animacoes/enemy_hit/03.webp",
      "assets/sprites/animacoes/enemy_hit/04.webp"
    ],
    "enemy_walk": [
      "assets/sprites/animacoes/enemy_walk/01.webp",
      "assets/sprites/animacoes/enemy_walk/02.webp",
      "assets/sprites/animacoes/enemy_walk/03.webp",
      "assets/sprites/animacoes/enemy_walk/04.webp",
      "assets/sprites/animacoes/enemy_walk/05.webp",
      "assets/sprites/animacoes/enemy_walk/06.webp",
      "assets/sprites/animacoes/enemy_walk/07.webp",
      "assets/sprites/animacoes/enemy_walk/08.webp",
      "assets/sprites/animacoes/enemy_walk/09.webp",
      "assets/sprites/animacoes/enemy_walk/10.webp",
      "assets/sprites/animacoes/enemy_walk/11.webp",
      "assets/sprites/animacoes/enemy_walk/12.webp"
    ],
    "flying_kick": [
      "assets/sprites/animacoes/flying_kick/01.webp",
      "assets/sprites/animacoes/flying_kick/02.webp",
      "assets/sprites/animacoes/flying_kick/03.webp",
      "assets/sprites/animacoes/flying_kick/04.webp",
      "assets/sprites/animacoes/flying_kick/05.webp",
      "assets/sprites/animacoes/flying_kick/06.webp",
      "assets/sprites/animacoes/flying_kick/07.webp",
      "assets/sprites/animacoes/flying_kick/08.webp"
    ],
    "front_punch": [
      "assets/sprites/animacoes/front_punch/01.webp",
      "assets/sprites/animacoes/front_punch/02.webp",
      "assets/sprites/animacoes/front_punch/03.webp",
      "assets/sprites/animacoes/front_punch/04.webp",
      "assets/sprites/animacoes/front_punch/05.webp",
      "assets/sprites/animacoes/front_punch/06.webp",
      "assets/sprites/animacoes/front_punch/07.webp",
      "assets/sprites/animacoes/front_punch/08.webp"
    ],
    "jump": [
      "assets/sprites/animacoes/jump/01.webp",
      "assets/sprites/animacoes/jump/02.webp",
      "assets/sprites/animacoes/jump/03.webp",
      "assets/sprites/animacoes/jump/04.webp",
      "assets/sprites/animacoes/jump/05.webp",
      "assets/sprites/animacoes/jump/06.webp",
      "assets/sprites/animacoes/jump/07.webp",
      "assets/sprites/animacoes/jump/08.webp",
      "assets/sprites/animacoes/jump/09.webp",
      "assets/sprites/animacoes/jump/10.webp",
      "assets/sprites/animacoes/jump/11.webp",
      "assets/sprites/animacoes/jump/12.webp"
    ],
    "run": [
      "assets/sprites/animacoes/run/01.webp",
      "assets/sprites/animacoes/run/02.webp",
      "assets/sprites/animacoes/run/03.webp",
      "assets/sprites/animacoes/run/04.webp",
      "assets/sprites/animacoes/run/05.webp",
      "assets/sprites/animacoes/run/06.webp",
      "assets/sprites/animacoes/run/07.webp",
      "assets/sprites/animacoes/run/08.webp"
    ],
    "left_punch": [
      "assets/sprites/animacoes/left_punch/01.webp",
      "assets/sprites/animacoes/left_punch/02.webp",
      "assets/sprites/animacoes/left_punch/03.webp",
      "assets/sprites/animacoes/left_punch/04.webp",
      "assets/sprites/animacoes/left_punch/05.webp",
      "assets/sprites/animacoes/left_punch/06.webp",
      "assets/sprites/animacoes/left_punch/07.webp",
      "assets/sprites/animacoes/left_punch/08.webp"
    ]
  },
  "impacts": {
    "left_punch": [
      "assets/sprites/fx08/left_punch/01.webp",
      "assets/sprites/fx08/left_punch/02.webp",
      "assets/sprites/fx08/left_punch/03.webp",
      "assets/sprites/fx08/left_punch/04.webp"
    ],
    "front_punch": [
      "assets/sprites/fx08/front_punch/01.webp",
      "assets/sprites/fx08/front_punch/02.webp",
      "assets/sprites/fx08/front_punch/03.webp",
      "assets/sprites/fx08/front_punch/04.webp"
    ],
    "flying_kick": [
      "assets/sprites/fx08/flying_kick/01.webp",
      "assets/sprites/fx08/flying_kick/02.webp",
      "assets/sprites/fx08/flying_kick/03.webp",
      "assets/sprites/fx08/flying_kick/04.webp"
    ],
    "jump": [
      "assets/sprites/fx08/jump/01.webp",
      "assets/sprites/fx08/jump/02.webp",
      "assets/sprites/fx08/jump/03.webp",
      "assets/sprites/fx08/jump/04.webp"
    ],
    "double_jump": [
      "assets/sprites/fx08/double_jump/01.webp",
      "assets/sprites/fx08/double_jump/02.webp",
      "assets/sprites/fx08/double_jump/03.webp",
      "assets/sprites/fx08/double_jump/04.webp"
    ]
  },
  "vote": "assets/sprites/coletaveis/voto.webp",
  "bonusAtlas": "assets/sprites/coletaveis/bonus_13x4.webp",
  "foreground": {
    "street": "assets/foreground/rua_brasilia_loop.webp"
  }
};
