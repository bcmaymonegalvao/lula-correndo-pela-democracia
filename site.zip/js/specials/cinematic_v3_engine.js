
/* Motor de teste V3 Ana/Janones. Não substitui o loop do jogo principal.
 * Construção: new EspecialCinematico(canvas,config,{onHit,onEnd}); await preload(); start(); update(dt); render().
 * O motor fornece eventos de dano com IDs únicos; a integração principal decide dano real e congelamento.
 */
(function(root){'use strict';
const LIMIT={total:6.10,cutin:.12,hold:.47,retract:1.12,entry:1.47,charge:1.80,fire:2.56,hit:3.23,hitEnd:4.86,fin:5.53};
const clamp=(v,min,max)=>Math.min(max,Math.max(min,v));
const ease=v=>{v=clamp(v,0,1);return v*v*(3-2*v)};
const lerp=(a,b,p)=>a+(b-a)*p;
const eventInterval=(LIMIT.hitEnd-LIMIT.hit)/13;
function image(src){return new Promise((resolve,reject)=>{const im=new Image();im.onload=()=>resolve(im);im.onerror=()=>reject(Error('Falha na imagem '+String(src).slice(0,80)));im.src=src;});}
function txt(ctx,s,x,y,size,color,stroke='#09112b',align='left'){
 ctx.save();ctx.font=`900 ${size}px system-ui,sans-serif`;ctx.textAlign=align;ctx.lineJoin='round';ctx.lineWidth=Math.max(3,size*.15);ctx.strokeStyle=stroke;ctx.fillStyle=color;ctx.strokeText(s,x,y);ctx.fillText(s,x,y);ctx.restore();
}
class EspecialCinematico{
 constructor(canvas,cfg,callbacks={}){this.canvas=canvas;this.ctx=canvas.getContext('2d');this.cfg=cfg;this.cb=callbacks;this.img={};this.ready=false;this.active=false;this.paused=true;this.done=false;this.time=0;this.hits=0;this.session=0;this.speed=1;}
 async preload(){this.img=Object.fromEntries(await Promise.all(Object.entries(this.cfg.assets).map(async([key,val])=>[key,await image(val)])));this.ready=true;if(!this.cfg.overlay)this.render();return this;}
 start(){if(!this.ready)return false;this.time=0;this.hits=0;this.done=false;this.active=true;this.paused=false;this.session++;if(!this.cfg.overlay)this.render();return true;}
 pause(){this.paused=true;} resume(){if(!this.done&&this.ready){this.paused=false;this.active=true;}} toggle(){this.paused?this.resume():this.pause();}
 cancel(){this.active=false;this.paused=true;this.done=true;}
 isActive(){return this.active&&!this.done;} setSpeed(s){this.speed=clamp(Number(s)||1,.25,3);}
 hitsAt(t){return t<LIMIT.hit?0:clamp(Math.floor((t-LIMIT.hit)/eventInterval)+1,0,13);}
 get phase(){let t=this.time;return t<LIMIT.cutin?'CONGELAMENTO':t<LIMIT.entry?'CARD CINEMATOGRÁFICO':t<LIMIT.charge?'ENTRADA':t<LIMIT.fire?'CONCENTRAÇÃO DE ENERGIA':t<LIMIT.hit?'PODER AVANÇANDO':t<LIMIT.hitEnd?'13 IMPACTOS':t<LIMIT.fin?'FINALIZAÇÃO':'RESTAURAÇÃO';}
 seek(sec){this.time=clamp(Number(sec)||0,0,LIMIT.total);this.hits=this.hitsAt(this.time);this.active=this.time<LIMIT.total;this.paused=true;this.done=false;if(!this.cfg.overlay)this.render();}
 update(dt){if(!this.active||this.paused||this.done)return; const old=this.time;this.time=clamp(this.time+clamp(Number(dt)||0,0,.15)*this.speed,0,LIMIT.total);const next=this.hitsAt(this.time);
  for(let n=this.hits+1;n<=next;n++){this.cb.onHit?.({character:this.cfg.id,hit:n,total:13,eventId:`${this.cfg.id}_${this.session}_${n}`});}this.hits=next;
  if(old<LIMIT.total&&this.time>=LIMIT.total){this.active=false;this.paused=true;this.done=true;this.cb.onEnd?.();}
 }
 sprite(name,x,y,w,h,alpha=1){const im=this.img[name];if(!im)return;const ctx=this.ctx;ctx.save();ctx.globalAlpha=alpha;ctx.imageSmoothingEnabled=false;ctx.drawImage(im,Math.round(x),Math.round(y),Math.round(w),Math.round(h));ctx.restore();}
 scene(t){let ctx=this.ctx;ctx.clearRect(0,0,960,540);this.sprite('background',0,0,960,540);ctx.fillStyle='rgba(8,12,33,.28)';ctx.fillRect(0,0,960,540);
  // Freeze all background entities: neither road nor Lula moves during the special.
  this.sprite('road',0,413,960,127);this.sprite('lula',73,278,144,145,.80);
  const contact=t>=LIMIT.hit&&t<LIMIT.hitEnd;let pulse=0,shake=0;
  if(contact){let r=(t-LIMIT.hit)/eventInterval;let sub=r-Math.floor(r);pulse=1-sub;shake=Math.round(Math.sin(t*173)*7*pulse);}
  ctx.save();ctx.translate(shake,0);this.sprite('boss',694,146,276,270);
  if(contact&&pulse>.45){ctx.globalCompositeOperation='screen';ctx.globalAlpha=pulse*.70;ctx.fillStyle=this.cfg.flash;ctx.fillRect(697,148,263,256);}ctx.restore();
  // Wind over the frozen backdrop is the only ambient animation.
  ctx.save();ctx.beginPath();ctx.rect(0,0,960,413);ctx.clip();ctx.lineCap='round';
  for(let i=0;i<32;i++){const x=960-((t*(350+(i%5)*73)+i*151)%1350);const y=23+(i*43)%390;
   ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+(65+(i%6)*26),y-4);ctx.strokeStyle=i%3===0?'rgba(255,255,255,.31)':this.cfg.wind;ctx.lineWidth=i%7===0?3:1.6;ctx.stroke();}
  ctx.restore();
 }
 cutin(t){if(t<LIMIT.cutin||t>=LIMIT.entry)return;
  const ctx=this.ctx,W=960,H=540;const p=ease((t-LIMIT.cutin)/.35)*(1-ease((t-LIMIT.retract)/.30)),x=-348+348*p;
  ctx.save();ctx.fillStyle=`rgba(5,5,23,${.36+p*.48})`;ctx.fillRect(0,0,W,H);
  ctx.fillStyle=this.cfg.cardBg;ctx.shadowColor=this.cfg.tint;ctx.shadowBlur=18;ctx.fillRect(x+1,7,320,526);ctx.shadowBlur=0;
  ctx.save();ctx.beginPath();ctx.rect(x+8,14,306,510);ctx.clip();this.sprite('portrait',x+8,14,306,510);ctx.restore();
  ctx.strokeStyle=this.cfg.tint;ctx.lineWidth=5;ctx.strokeRect(x+4,10,312,518);
  ctx.globalAlpha=p;
  let g=ctx.createLinearGradient(323,0,840,0);g.addColorStop(0,this.cfg.cardGradient);g.addColorStop(1,'rgba(0,0,0,0)');ctx.fillStyle=g;ctx.fillRect(324,95,520,269);
  txt(ctx,this.cfg.name,351,187,34,'#ffffff','#140928');
  txt(ctx,this.cfg.card1,352,256,this.cfg.cardSize||43,this.cfg.headline,'#130e2a');
  txt(ctx,this.cfg.card2,352,311,this.cfg.cardSize2||42,'#ffffff','#13142a');ctx.restore();
 }
 hero(t){if(t<LIMIT.retract||t>LIMIT.total)return;const ctx=this.ctx;
  const layout=this._layout||{};
  const x=(layout.heroX??75)-175*(1-ease((t-LIMIT.entry)/.30)),y=(layout.ground??448)-208,size=208;
  let key='idle1';
  if(t>=LIMIT.entry&&t<LIMIT.charge)key=(Math.floor(t*8)%2)?'idle1':'idle2';
  else if(t>=LIMIT.charge&&t<LIMIT.fire){const seq=['charge0','charge1','charge2','charge3'];key=seq[Math.min(3,Math.floor((t-LIMIT.charge)/(LIMIT.fire-LIMIT.charge)*4))];}
  else if(t>=LIMIT.fire&&t<LIMIT.hitEnd)key=this.cfg.id==='ana_eliza'?'charge3':'attack0';
  else if(t>=LIMIT.hitEnd)key='finish';
  if(t>LIMIT.charge&&t<LIMIT.fire){for(let i=3;i>=1;i--){ctx.save();ctx.filter='hue-rotate(26deg) brightness(1.5)';this.sprite(key,x-i*15,y+i*1,size,size,.07*i);ctx.restore();}}
  this.sprite(key,x,y,size,size);
  if(t>=LIMIT.charge&&t<LIMIT.fire){let cx=x+153,cy=y+124,r=33+6*Math.sin(t*26);
   ctx.save();ctx.globalCompositeOperation='screen';const g=ctx.createRadialGradient(cx,cy,2,cx,cy,r);g.addColorStop(0,'#ffffff');g.addColorStop(.25,this.cfg.tint);g.addColorStop(1,'rgba(255,255,255,0)');ctx.fillStyle=g;ctx.beginPath();ctx.arc(cx,cy,r,0,Math.PI*2);ctx.fill();ctx.restore();}
 }
 projectile(t){if(t<LIMIT.fire||t>=LIMIT.hitEnd)return;const ctx=this.ctx,contact=t>=LIMIT.hit, f=ease((t-LIMIT.fire)/(LIMIT.hit-LIMIT.fire));
  const layout=this._layout||{};
  const targetX=layout.projectileContactX??619;
  const x=contact?targetX:lerp((layout.projectileStartX??204),targetX,f);
  const y=(layout.projectileY??254);
  ctx.save();ctx.globalCompositeOperation='screen';let trail=ctx.createLinearGradient(x-240,y,x+150,y);trail.addColorStop(0,'rgba(255,255,255,0)');trail.addColorStop(.5,this.cfg.trail);trail.addColorStop(1,this.cfg.tint);ctx.fillStyle=trail;ctx.fillRect(x-218,y+65,280,19);
  if(this.cfg.id==='janones'){
    const wave=Math.min(5,Math.floor((t-LIMIT.fire)*12)%6);
    // The wave is made of real artwork with flags and crowds, separate from Janones.
    this.sprite('projectile'+(contact?5:wave),x-42,y-69,224+f*45,210+f*10,.97);
    ctx.save();ctx.globalAlpha=.58;this.sprite('flagfx',x+118,y+23,43,45);ctx.restore();
  }else{
    // Ana's attack: four original projectile frames plus the isolated justice-scales icon.
    const frame=Math.max(0,Math.floor((t-LIMIT.fire)*13))%4;
    this.sprite('projectile'+(contact?3:frame),x-22,y-57,238,204,.98);
    this.sprite('justiceicon',x+72,y+3,76,76,.80);
  }
  ctx.restore();
 }
 impacts(t){if(t<LIMIT.hit||t>LIMIT.fin)return;let ctx=this.ctx,n=this.hitsAt(t),cx=(this._layout?.impactX??763),cy=(this._layout?.impactY??272);
  if(t<LIMIT.hitEnd){let sub=((t-LIMIT.hit)/eventInterval)%1,opacity=1-sub;
    ctx.save();ctx.globalCompositeOperation='screen';ctx.globalAlpha=.86*opacity;
    if(this.cfg.id==='janones')this.sprite('burst',cx-121,cy-145,260,245,1);
    else this.sprite('justiceicon',cx-94,cy-98,187,182,1);
    for(let k=0;k<14;k++){const a=(k/14)*Math.PI*2+t*7;ctx.strokeStyle=k%2?this.cfg.tint:'#fff';ctx.lineWidth=2.5;
      ctx.beginPath();ctx.moveTo(cx+Math.cos(a)*13,cy+Math.sin(a)*13);ctx.lineTo(cx+Math.cos(a)*(37+opacity*35),cy+Math.sin(a)*(37+opacity*35));ctx.stroke();}
    ctx.restore();
  }else{
    const q=ease((t-LIMIT.hitEnd)/(LIMIT.fin-LIMIT.hitEnd));ctx.save();ctx.globalCompositeOperation='screen';ctx.globalAlpha=.7*(1-q);
    if(this.cfg.id==='janones')this.sprite('burst',cx-170,cy-185,340,300);else this.sprite('justiceicon',cx-170,cy-170,330,310);
    ctx.restore();txt(ctx,this.cfg.finish,484,109,32,this.cfg.headline,'#091127','center');
  }
  txt(ctx,`${n} / 13 HITS`,479,80,27,this.cfg.headline,'#09152e','center');
 }
 render(targetCtx=null,layout=null){
  if(!this.ready)return;
  const before=this.ctx;
  if(targetCtx)this.ctx=targetCtx;
  if(layout)this._layout=layout;
  const t=this.time,ctx=this.ctx;
  try{
   if(this.cfg.overlay){
    // Already-drawn real world is frozen by the main game update loop.
    const L=this._layout||{};
    ctx.save();ctx.imageSmoothingEnabled=false;
    ctx.fillStyle='rgba(7,9,30,.37)';ctx.fillRect(0,0,960,540);
    // Cinematic wind drawn on top of the frozen actual scene.
    ctx.save();ctx.beginPath();ctx.rect(0,0,960,430);ctx.clip();
    for(let i=0;i<33;i++){
     const x=960-((t*(360+(i%5)*60)+i*139)%1280);
     const y=22+(i*43)%389;
     ctx.globalAlpha=.16+(i%5)*.045;ctx.lineCap='round';
     ctx.strokeStyle=i%3===0?'#ffffff':this.cfg.tint;ctx.lineWidth=i%5===0?3:1.3;
     ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+68+(i%6)*23,y-3);ctx.stroke();
    }
    ctx.restore();
    if(t>=LIMIT.hit&&t<LIMIT.hitEnd&&L.bossImage&&L.bossRect){
     const q=((t-LIMIT.hit)/eventInterval)%1;
     if(q<.52){
      const B=L.bossRect;
      ctx.save();ctx.translate(Math.sin(t*189)*4,Math.cos(t*131)*2);
      ctx.globalAlpha=.82;ctx.filter=this.cfg.id==='ana_eliza'?'brightness(0) saturate(100%) invert(85%) sepia(26%) saturate(2100%) hue-rotate(280deg)':'brightness(0) saturate(100%) invert(84%) sepia(28%) saturate(1228%) hue-rotate(157deg)';
      ctx.drawImage(L.bossImage,Math.round(B.x),Math.round(B.y),Math.round(B.w),Math.round(B.h));
      ctx.restore();
     }
    }
    this.cutin(t);this.hero(t);this.projectile(t);this.impacts(t);
    // The in-game HUD occupies the top 100px; the card already labels the move.
    // Do not duplicate a headline underneath the HUD.
    if(t>=LIMIT.fin)txt(ctx,'ESPECIAL CONCLUÍDO',480,375,22,this.cfg.headline,'#080d28','center');
    ctx.restore();
   }else{
    this.scene(t);this.cutin(t);this.hero(t);this.projectile(t);this.impacts(t);
    txt(ctx,this.cfg.screen,480,39,24,this.cfg.headline,'#061027','center');
    if(t>=LIMIT.fin)txt(ctx,'ESPECIAL CONCLUÍDO',480,94,24,this.cfg.headline,'#080d28','center');
   }
  }finally{this.ctx=before;}
 }
}
root.EspecialCinematico=EspecialCinematico;root.EspecialTiming=Object.freeze({...LIMIT,eventInterval,hitCount:13});
})(typeof window!=='undefined'?window:globalThis);
