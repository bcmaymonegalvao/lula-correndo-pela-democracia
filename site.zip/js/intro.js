/* Animated title scene, Alpha 0.9.2: no separate game mode state. */
(()=>{'use strict';
const view=document.getElementById('introCanvas'),page=document.getElementById('start'),btn=document.getElementById('startBtn');
if(!view||!page||!btn)return;
const ctx=view.getContext('2d');const W=960,H=540,G=423;
const asset=window.GAME_ASSETS;
const image=src=>{const im=new Image();if(src)im.src=src;return im;};
const bg=image(asset.backgrounds.brasilia_dia),road=image(asset.foreground.street);
const run=asset.sprites.run.map(image),atlas=image(asset.bonusAtlas),votes=image(asset.vote);
let last=0,t=0,world=0,collected=0,bonusSpawn=2;
const bonusItems=[];let ready=false;
const rng=(a,b)=>a+Math.random()*(b-a);
function draw(){
 ctx.clearRect(0,0,W,H);
 if(bg.complete&&bg.naturalWidth){
  const s=Math.max(W/bg.width,H/bg.height)*1.22,bw=bg.width*s,bh=bg.height*s;
  const travel=Math.max(0,bw-W);
  ctx.drawImage(bg,-((world*.09)%Math.max(1,travel)),(H-bh)/2,bw,bh);
 }else{ctx.fillStyle='#196a9e';ctx.fillRect(0,0,W,H);}
 if(road.complete&&road.naturalWidth){const tw=1140,off=world*1.05%tw;
  ctx.imageSmoothingEnabled=false;for(let x=-tw-off;x<W+tw;x+=tw)ctx.drawImage(road,x,G-100,tw,240);
 }
 for(const e of bonusItems){const x=e.x-world+180,dy=G-e.height+Math.sin(t*5+e.x)*5;
  if(atlas.complete&&atlas.naturalWidth){const f=Math.floor(t*6)%4;ctx.drawImage(atlas,f*192,e.row*192,192,192,x-28,dy-28,56,56);}
  else if(votes.complete&&votes.naturalWidth)ctx.drawImage(votes,x-22,dy-22,44,44);
 }
 const pic=run[Math.floor(t*11)%run.length];if(pic&&pic.complete&&pic.naturalWidth){
  ctx.imageSmoothingEnabled=false;
  window.drawFramedSprite(ctx,pic,172,G,1.15,'run');
 }
 ctx.textAlign='right';ctx.lineWidth=4;ctx.font='900 15px sans-serif';ctx.strokeStyle='#111e32';ctx.fillStyle='#ffe688';
 if(collected){const msg=`★ +${collected*1000} PONTOS`;ctx.strokeText(msg,W-30,H-44);ctx.fillText(msg,W-30,H-44);}
 ctx.textAlign='left';
}
function update(now){if(!page.classList.contains('hidden')){
 const dt=Math.min(.045,(now-last)/1000||0);t+=dt;world+=180*dt;bonusSpawn-=dt;
 if(bonusSpawn<=0){bonusItems.push({x:world+940,height:rng(68,132),row:Math.floor(Math.random()*13)});bonusSpawn=rng(1.8,3.7);}
 for(const b of bonusItems){if(!b.done&&b.x-world<15){b.done=true;collected++;}}
 for(let i=bonusItems.length-1;i>=0;i--)if(bonusItems[i].done||bonusItems[i].x-world<-300)bonusItems.splice(i,1);
 draw();}
 last=now;requestAnimationFrame(update);
}
requestAnimationFrame(update);
// Pointer/click uses the existing start button, which is only enabled after core sprites loaded.
window.addEventListener('keydown',e=>{
 if(page.classList.contains('hidden')||e.repeat||btn.disabled)return;
 if(['shift','control','alt','meta','tab'].includes(e.key.toLowerCase()))return;
 e.preventDefault();btn.click();
});
})();
