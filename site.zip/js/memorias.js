/* Parafraseado do PDF oficial; consulta em 18/10/2026. Não são indicadores de execução. */
window.MEMORIAS_QUIZ = [
  [
    "Trabalho",
    "Proposta eleitoral: Continuidade da valorização do salário mínimo. Fonte: programa de governo no TSE, p. 74. A presença no plano não comprova execução.",
    "https://www.tse.jus.br/eleicoes/eleicoes-2026-content/arquivos/proposta-pt/@@display-file/file/proposta-pt.pdf#page=74"
  ],
  [
    "Educação",
    "Proposta eleitoral: Prioridade à expansão da educação em tempo integral. Fonte: programa de governo no TSE, p. 31. A presença no plano não comprova execução.",
    "https://www.tse.jus.br/eleicoes/eleicoes-2026-content/arquivos/proposta-pt/@@display-file/file/proposta-pt.pdf#page=31"
  ],
  [
    "Energia",
    "Proposta eleitoral: Ampliar fontes renováveis, armazenamento e combustíveis de baixo carbono. Fonte: programa de governo no TSE, p. 64. A presença no plano não comprova execução.",
    "https://www.tse.jus.br/eleicoes/eleicoes-2026-content/arquivos/proposta-pt/@@display-file/file/proposta-pt.pdf#page=64"
  ],
  [
    "Agricultura",
    "Proposta eleitoral: Expandir o Plano Safra da Agricultura Familiar e simplificar o acesso ao crédito. Fonte: programa de governo no TSE, p. 59. A presença no plano não comprova execução.",
    "https://www.tse.jus.br/eleicoes/eleicoes-2026-content/arquivos/proposta-pt/@@display-file/file/proposta-pt.pdf#page=59"
  ],
  [
    "Emprego",
    "Proposta eleitoral: Integrar qualificação profissional e ampliar a plataforma de empregabilidade na rede SINE. Fonte: programa de governo no TSE, p. 74. A presença no plano não comprova execução.",
    "https://www.tse.jus.br/eleicoes/eleicoes-2026-content/arquivos/proposta-pt/@@display-file/file/proposta-pt.pdf#page=74"
  ],
  [
    "Infância",
    "Proposta eleitoral: Ampliar o apoio a estados e municípios para creches e educação infantil. Fonte: programa de governo no TSE, p. 31. A presença no plano não comprova execução.",
    "https://www.tse.jus.br/eleicoes/eleicoes-2026-content/arquivos/proposta-pt/@@display-file/file/proposta-pt.pdf#page=31"
  ]
];
