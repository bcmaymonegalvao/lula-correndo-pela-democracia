/* Lula — Correndo pela Democracia · Alpha 0.8.9
   Golpes nativos dos arquivos do Sprites Fusion:
   soco com braço esquerdo → soco frontal → voadora ascendente.
   Apenas os 4 quadros finais de cada ataque (originais 05–08).
   Coordenadas relativas ao centro do personagem, com Y em relação aos pés;
   logo, ataques acompanham verticalmente os pulos sem hitbox fantasma no chão. */
window.GameCombat = (() => {
 const MOVES = Object.freeze([
  {
   name:'SOCO ESQUERDO',clip:'left_punch',impact:'left_punch',flashColor:'#64deff',duration:.34,damage:1,
   boxes:[{x:27,y:-95,w:66,h:49},{x:19,y:-92,w:57,h:44},{x:20,y:-93,w:51,h:43},null]
  },
  {
   name:'SOCO FRONTAL',clip:'front_punch',impact:'front_punch',flashColor:'#b1f0ff',duration:.35,damage:1,
   boxes:[{x:29,y:-96,w:78,h:50},{x:24,y:-92,w:68,h:49},{x:20,y:-94,w:60,h:45},null]
  },
  {
   name:'VOADORA ASCENDENTE',clip:'flying_kick',impact:'flying_kick',flashColor:'#367aff',duration:.40,damage:1,
   boxes:[{x:30,y:-120,w:90,h:100},{x:25,y:-108,w:77,h:85},{x:23,y:-103,w:70,h:78},null]
  }
 ]);
 // Every button press advances to the next move, cyclically: 1 → 2 → 3 → 1.
 // Presses during an attack are queued, not merged into a stronger first sprite.
 const COMBO_WINDOW=1.05;
 function create(){
  const state={step:0,left:0,queue:0,nextStep:1,serial:0,hitTargets:new Set()};
  function reset(){Object.assign(state,{step:0,left:0,queue:0,nextStep:1,serial:0,hitTargets:new Set()});}
  function begin(step){
   if(!Number.isInteger(step)||step<1||step>3)return false;
   state.step=step;state.left=MOVES[step-1].duration;
   state.hitTargets=new Set();state.serial++;return true;
  }
  function press(key='combo'){
   if(key!=='combo')return false; // Only one attack action/button exists.
   if(state.step){
    if(state.queue>=3)return false;
    state.queue++;return true;
   }
   return begin(state.nextStep);
  }
  function update(dt){
   if(dt<=0)return;
   if(state.step){
    state.left-=dt;
    if(state.left<=0){
     const following=state.step===3?1:state.step+1;
     state.nextStep=following;
     if(state.queue>0){state.queue--;begin(following);}
     else{state.step=0;state.left=0;}
    }
   }
  }
 function move(){return state.step?MOVES[state.step-1]:null;}
  function frame(){
   const m=move();if(!m)return 0;
   const p=Math.max(0,Math.min(.999999,1-state.left/m.duration));
   return Math.floor(p*4);
  }
  function hitbox(world,feet){
   const m=move();if(!m)return null;
   const box=m.boxes[frame()];if(!box)return null;
   return {x:world+box.x,y:feet+box.y,w:box.w,h:box.h};
  }
  return {state,reset,begin,press,update,move,frame,hitbox};
 }
 return {MOVES,COMBO_WINDOW,create};
})();
