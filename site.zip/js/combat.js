/* Combos com três golpes distintos: foice vertical -> martelo horizontal -> bandeira.
   Três toques são três golpes, inclusive durante o pulo. */
window.GameCombat=(()=>{
 const MOVES=Object.freeze([
   {name:'FOICE',clip:'scythe',duration:.43,active:[.13,.34],reach:115,width:98,height:138,damage:1},
   {name:'MARTELO',clip:'hammer',duration:.50,active:[.16,.39],reach:125,width:117,height:95,damage:1},
   {name:'BANDEIRA',clip:'flag',duration:.62,active:[.18,.50],reach:159,width:152,height:142,damage:1}
 ]);
 const COMBO_WINDOW=1.05;
 function create(){
  const state={step:0,left:0,queue:0,window:0,nextStep:1,serial:0,hitTargets:new Set()};
  function reset(){Object.assign(state,{step:0,left:0,queue:0,window:0,nextStep:1,serial:0,hitTargets:new Set()});}
  function begin(step){state.step=step;state.left=MOVES[step-1].duration;state.window=0;state.hitTargets=new Set();state.serial++;}
  function press(key='combo'){
   if(key!=='combo'&&key!=='flag')return false;
   if(state.step){if(state.queue>=2||state.step+state.queue>=3)return false;state.queue++;return true;}
   if(key==='flag')begin(3);
   else begin(state.window>0?state.nextStep:1);
   return true;
  }
  function update(dt){
   if(state.step){state.left-=dt;
    if(state.left<=0){const step=state.step;
      if(state.queue&&step<3){state.queue--;begin(step+1);}
      else{state.step=0;state.left=0;state.queue=0;state.nextStep=step===3?1:step+1;state.window=step===3?0:COMBO_WINDOW;}
    }
   }else{state.window=Math.max(0,state.window-dt);if(!state.window)state.nextStep=1;}
  }
  function move(){return MOVES[Math.max(0,state.step-1)];}
  function frame(){if(!state.step)return 0;const m=move(),t=Math.min(.9999,(m.duration-state.left)/m.duration);return Math.floor(t*8);}
  function hitbox(world,feet){
   if(!state.step)return null;
   const m=move(),t=m.duration-state.left;if(t<m.active[0]||t>m.active[1])return null;
   return {x:world+11,y:feet-m.height,w:m.width,h:m.height+12};
  }
  return {state,reset,begin,press,update,move,frame,hitbox};
 }
 return {MOVES,COMBO_WINDOW,create};
})();
