/* Alpha 0.4 — uma pressão física = uma etapa de combo.
   1) varredura lateral; 2) golpe vertical; 3) finalização dupla.
   Toques recebidos durante a animação ficam enfileirados (máx. 2).
   Depois de um intervalo sem outro toque, o combo volta ao golpe 1. */
window.GameCombat = (() => {
  const FLAG_SCORE = 1000;
  const COMBO_WINDOW = 0.92;
  const MOVES = Object.freeze([
    {name:'1 • Varredura lateral', duration:0.42, frames:12, scale:1.30, reach:120, active:[0.13,0.30], damage:1},
    {name:'2 • Ataque vertical', duration:0.48, frames:12, scale:1.39, reach:127, active:[0.18,0.37], damage:1},
    {name:'3 • Golpe final', duration:0.58, frames:12, scale:1.48, reach:160, active:[0.20,0.49], damage:2}
  ]);
  function create() {
    const state={weapon:'',step:0,left:0,queue:0,nextStep:1,window:0,lastWeapon:'',hitTargets:new Set()};
    function reset(){Object.assign(state,{weapon:'',step:0,left:0,queue:0,nextStep:1,window:0,lastWeapon:'',hitTargets:new Set()});}
    function begin(weapon,step){state.weapon=weapon;state.step=step;state.left=MOVES[step-1].duration;state.lastWeapon=weapon;state.window=0;state.hitTargets=new Set();}
    function press(weapon,flagUnlocked){
      if(!['hammer','flag'].includes(weapon)||(weapon==='flag'&&!flagUnlocked))return false;
      if(state.weapon){
        if(weapon!==state.weapon || state.step+state.queue>=3)return false;
        state.queue++;return true;
      }
      const step=state.window>0&&state.lastWeapon===weapon?state.nextStep:1;
      begin(weapon,step);return true;
    }
    function update(dt){
      if(!state.weapon){state.window=Math.max(0,state.window-dt);if(!state.window)state.nextStep=1;return;}
      state.left-=dt;
      if(state.left<=0){
        const {weapon,step}=state;
        if(state.queue&&step<3){state.queue--;begin(weapon,step+1);}
        else{state.weapon='';state.left=0;state.queue=0;state.nextStep=step===3?1:step+1;state.window=step===3?0:COMBO_WINDOW;}
      }
    }
    function move(){return MOVES[Math.max(0,state.step-1)];}
    function frame(){const m=move(),progress=Math.max(0,Math.min(.999,(m.duration-state.left)/m.duration));return Math.floor(progress*m.frames);}
    function hitbox(world,feet){
      if(!state.weapon)return null;
      const m=move(),t=m.duration-state.left;
      if(t<m.active[0]||t>m.active[1])return null;
      const flag=state.weapon==='flag';
      const high=state.step===2,final=state.step===3;
      return {x:world+(high?18:8), y:feet-(high?170:final?148:flag?144:115),
        w:m.reach+(flag?42:0),h:high?170:final?145:flag?140:112};
    }
    return {state,press,update,reset,move,frame,hitbox};
  }
  return {FLAG_SCORE,COMBO_WINDOW,MOVES,create};
})();
