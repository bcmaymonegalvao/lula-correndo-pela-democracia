/* Lula — Correndo pela Democracia · Alpha 0.9.1
   Golpes nativos dos arquivos do Sprites Fusion:
   soco com braço esquerdo → soco frontal → voadora ascendente.
   Caixas de acerto independentes para os frames 3..6 (índices 2..5).
   Coordenadas relativas ao centro do personagem, com Y em relação aos pés;
   logo, ataques acompanham verticalmente os pulos sem hitbox fantasma no chão. */
window.GameCombat = (() => {
 const MOVES = Object.freeze([
  {
   name:'SOCO ESQUERDO',clip:'left_punch',impact:'left_punch',flashColor:'#64deff',duration:.48,damage:1,
   boxes:[{x:22,y:-94,w:50,h:42},{x:28,y:-97,w:62,h:48},
          {x:27,y:-95,w:66,h:49},{x:19,y:-92,w:49,h:44}]
  },
  {
   name:'SOCO FRONTAL',clip:'front_punch',impact:'front_punch',flashColor:'#b1f0ff',duration:.50,damage:1,
   boxes:[{x:24,y:-97,w:56,h:46},{x:31,y:-97,w:74,h:48},
          {x:29,y:-96,w:78,h:50},{x:24,y:-92,w:58,h:49}]
  },
  {
   name:'VOADORA ASCENDENTE',clip:'flying_kick',impact:'flying_kick',flashColor:'#367aff',duration:.61,damage:1,
   boxes:[{x:21,y:-104,w:63,h:75},{x:28,y:-112,w:81,h:87},
          {x:30,y:-120,w:90,h:100},{x:25,y:-108,w:72,h:85}]
  }
 ]);
 // Restrict each chain to three strikes.  Button bounce is ignored, and the
 // cooldown begins only after the third attack animation finishes.
 const COMBO_WINDOW=1.05, COOLDOWN_SECONDS=0.5, INPUT_DEBOUNCE=0.11;
 function create(){
  const state={step:0,left:0,queue:0,nextStep:1,serial:0,hitTargets:new Set(),
    chainCount:0,cooldown:0,debounce:0,idle:0};
  function reset(){Object.assign(state,{step:0,left:0,queue:0,nextStep:1,serial:0,
    hitTargets:new Set(),chainCount:0,cooldown:0,debounce:0,idle:0});}
  function begin(step){
   if(!Number.isInteger(step)||step<1||step>3||state.cooldown>0||state.chainCount>=3)return false;
   state.step=step;state.left=MOVES[step-1].duration;
   state.chainCount++;state.idle=0;state.hitTargets=new Set();state.serial++;
   return true;
  }
  function press(key='combo'){
   if(key!=='combo'||state.cooldown>0||state.debounce>0)return false;
   // Refuse a fourth buffered strike even when the player taps rapidly.
   if(state.step){
    if(state.chainCount+state.queue>=3)return false;
    state.queue++;state.debounce=INPUT_DEBOUNCE;return true;
   }
   if(state.chainCount>=3)return false;
   const succeeded=begin(state.nextStep);
   if(succeeded)state.debounce=INPUT_DEBOUNCE;
   return succeeded;
  }
  function update(dt){
   if(dt<=0)return;
   state.debounce=Math.max(0,state.debounce-dt);
   if(state.cooldown>0){
    state.cooldown=Math.max(0,state.cooldown-dt);
    if(state.cooldown===0){state.chainCount=0;state.nextStep=1;state.idle=0;}
   }
   if(state.step){
    state.left-=dt;
    if(state.left<=0){
     const completed=state.step;
     state.step=0;state.left=0;
     if(state.chainCount>=3){
      state.queue=0;state.cooldown=COOLDOWN_SECONDS;state.nextStep=1;state.idle=0;
     }else{
      state.nextStep=completed+1;
      if(state.queue>0){state.queue--;begin(state.nextStep);}
      else state.idle=0;
     }
    }
   }else if(state.cooldown===0&&state.chainCount>0){
    state.idle+=dt;
    if(state.idle>=COMBO_WINDOW){state.chainCount=0;state.nextStep=1;state.queue=0;state.idle=0;}
   }
  }
  function move(){return state.step?MOVES[state.step-1]:null;}
  function frame(){const m=move();if(!m)return 0;
   const p=Math.max(0,Math.min(.999999,1-state.left/m.duration));return Math.floor(p*4);
  }
  function hitbox(world,feet){const m=move();if(!m)return null;
   const box=m.boxes[frame()];if(!box)return null;
   return {x:world+box.x,y:feet+box.y,w:box.w,h:box.h};
  }
  return {state,reset,begin,press,update,move,frame,hitbox};
 }
 return {MOVES,COMBO_WINDOW,COOLDOWN_SECONDS,INPUT_DEBOUNCE,create};
})();
