/* Somente mapeamento de quadros e cadência.
   Imagens são arquivos PNG físicos em assets/sprites/animacoes/. */
window.GameAnimation=(()=>{
 const FPS_RUN=19;
 const LENGTHS=Object.freeze({run:16,jump:12,hammer_1:12,hammer_2:12,hammer_3:12,flag_1:12,flag_2:12,flag_3:12});
 function clip({attack,onGround,landing,velocityY,jumpAge,step}){
   if(attack)return attack+'_'+Math.max(1,Math.min(3,step));
   return (!onGround || landing>0)?'jump':'run';
 }
 function frame({clipId,elapsed,landing,velocityY,jumpAge,combat}){
   const len=LENGTHS[clipId]||1;
   if(clipId==='run') return Math.floor(elapsed*FPS_RUN)%len;
   if(clipId==='jump'){
      if(landing>0)return 11;
      if(jumpAge<.045)return 0;
      if(jumpAge<.10)return 2;
      if(velocityY<-180)return 4;
      if(velocityY<50)return 6;
      if(velocityY<210)return 8;
      return 10;
   }
   return Math.min(len-1,combat.frame());
 }
 return {LENGTHS,FPS_RUN,clip,frame};
})();
