/* Todos os PNGs têm 384×384, mesma âncora e escala corporal.
   Aumentar o golpe nunca altera a posição dos pés ou a física do jogador. */
window.SpriteLayout={width:384,height:384,anchorX:160,anchorY:345,bodyHeight:190};
window.drawFramedSprite=function(ctx,image,footX,footY,bodyHeight,multiplier=1){
 const m=window.SpriteLayout,scale=bodyHeight/m.bodyHeight*multiplier;
 ctx.drawImage(image,footX-m.anchorX*scale,footY-m.anchorY*scale,m.width*scale,m.height*scale);
};
