/* Frame anchors apply to all animation files (192x192). Don't enlarge attacks. */
window.SpriteLayout={width:192,height:192,anchorX:88,anchorY:169};
window.drawFramedSprite=(ctx,img,x,feet,scale=1,clip='run')=>{
 if(!img||!img.width)return;
 const a=window.SpriteLayout;
 // Punches and kick were authored ~6% taller than the running animation.
 // Shrink the entire attack clip once; never scale it dynamically on contact.
 const safeScale=scale*(['left_punch','front_punch','flying_kick'].includes(clip)?102/108:1);
 ctx.drawImage(img,x-a.anchorX*safeScale,feet-a.anchorY*safeScale,a.width*safeScale,a.height*safeScale);
};
