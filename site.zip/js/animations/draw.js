/* Todos os sprites normalizados em 192x192 e com o solo na âncora Y 169. */
window.SpriteLayout={width:192,height:192,anchorX:88,anchorY:169};
window.drawFramedSprite=(ctx,img,x,feet,scale=1)=>{
 if(!img||!img.width)return;
 const a=window.SpriteLayout;
 ctx.drawImage(img,x-a.anchorX*scale,feet-a.anchorY*scale,a.width*scale,a.height*scale);
};
