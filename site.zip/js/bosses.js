/* Alpha 0.8.5 · Encontros sequenciais: seis rivais de 20 HP e um final de 40 HP.
 * A ordem é fixa: nenhum encontro pode começar antes do anterior terminar. */
window.GameBosses=(()=>{
 const catalog=Object.freeze([
  {id:'seis_por_um',name:'Guardião da Escala 6×1',hp:20},
  {id:'aposentadoria',name:'Conde da Aposentadoria',hp:20},
  {id:'saude_educacao',name:'Colosso da Saúde e Educação',hp:20},
  {id:'privatizacao',name:'Barão da Privatização',hp:20},
  {id:'entreguismo',name:'Marionetista',hp:20},
  {id:'punitivismo',name:'Sentinela do Punitivismo',hp:20},
  {id:'final',name:'Tariflávio — Escavadeira',hp:40,final:true}
 ]);
 function make(index,x){const def=catalog[index];if(!def)return null;return {
  id:`boss_${index}`,kind:def.id,name:def.name,hp:def.hp,maxHp:def.hp,final:!!def.final,
  x,age:0,walkTime:0,flash:0,flashColor:'#ffdf91',stun:0,dead:false,deathAge:0,
  shotClock:def.final?3.8:4.4,telegraph:0,shotsFired:0
 };}
 return Object.freeze({catalog,make});
})();
