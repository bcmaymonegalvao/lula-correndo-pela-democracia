/* Alpha 0.9.0 — Tariflávio permanece como chefão final com entrada gradual pela direita. */
window.GameBosses = (() => {
 const catalog=Object.freeze([Object.freeze({id:'final',name:'Tariflávio — Invocador do Tesouraço',hp:40,final:true})]);
 function make(index,x){
  const def=catalog[index];if(!def)return null;
  return {id:`boss_${index}`,kind:def.id,name:def.name,hp:def.hp,maxHp:def.hp,final:true,
   x,age:0,walkTime:0,flash:0,flashColor:'#ffdf91',stun:0,dead:false,deathAge:0,
   shotClock:3.8,telegraph:0,shotsFired:0,warned:false};
 }
 return Object.freeze({catalog,make});
})();
