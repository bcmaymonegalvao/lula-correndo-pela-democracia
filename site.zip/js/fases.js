/* Brasília · ciclo de dia para noite. A corrida continua sem limite. */
window.CAPITAIS = Object.freeze([
 {id:'brasilia_dia',name:'Brasília • Eixo Monumental • Manhã',period:'day'},
 {id:'brasilia_tarde',name:'Brasília • Catedral • Tarde',period:'afternoon'},
 {id:'brasilia_entardecer',name:'Brasília • Ponte JK • Pôr do sol',period:'sunset'},
 {id:'brasilia_noite',name:'Brasília • Praça dos Três Poderes • Noite',period:'night'}
]);
window.CityRotation=(()=>{
 function create(list=window.CAPITAIS){let ix=0;return {next(){const scene=list[ix%list.length];ix++;return scene;},get index(){return ix;}};}
 return {create};
})();
