/* Duração total: 180 segundos. Tempos e nomes editáveis. */
window.FASES_BRASIL = [
 {id:'south',name:'Região Sul',city:false,seconds:24},
 {id:'curitiba',name:'Curitiba • PR',city:true,seconds:6},
 {id:'north',name:'Região Norte',city:false,seconds:24},
 {id:'manaus',name:'Manaus • AM',city:true,seconds:6},
 {id:'centerwest',name:'Centro-Oeste',city:false,seconds:24},
 {id:'cuiaba',name:'Cuiabá • MT',city:true,seconds:6},
 {id:'southeast',name:'Sudeste',city:false,seconds:24},
 {id:'saopaulo',name:'São Paulo • SP',city:true,seconds:6},
 {id:'northeast',name:'Nordeste',city:false,seconds:24},
 {id:'salvador',name:'Salvador • BA',city:true,seconds:6},
 {id:'brasilia',name:'Brasília • DF',city:false,seconds:30}
];
