/* Cenário focado em Brasília para ajustes visuais e testes de gameplay. */
window.CAPITAIS = [
  { id: "brasilia", name: "Brasília • DF", quality: "panorama-longo" }
];
window.CityRotation = (()=>{
 function create(list=window.CAPITAIS){
  return { next(){ return list[0]; } };
 }
 return {create};
})();
