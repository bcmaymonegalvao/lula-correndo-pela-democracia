/* 27 capitais do Brasil, duração variável de 12-17s, ordem embaralhada sem repetição no ciclo. */
window.CAPITAIS = [
  {
    "id": "curitiba",
    "name": "Curitiba • PR",
    "quality": "panorama-original"
  },
  {
    "id": "florianopolis",
    "name": "Florianópolis • SC",
    "quality": "panorama-original"
  },
  {
    "id": "porto_alegre",
    "name": "Porto Alegre • RS",
    "quality": "panorama-original"
  },
  {
    "id": "sao_paulo",
    "name": "São Paulo • SP",
    "quality": "panorama-original"
  },
  {
    "id": "rio_de_janeiro",
    "name": "Rio de Janeiro • RJ",
    "quality": "panorama-original"
  },
  {
    "id": "belo_horizonte",
    "name": "Belo Horizonte • MG",
    "quality": "panorama-original"
  },
  {
    "id": "salvador",
    "name": "Salvador • BA",
    "quality": "panorama-original"
  },
  {
    "id": "recife",
    "name": "Recife • PE",
    "quality": "panorama-original"
  },
  {
    "id": "fortaleza",
    "name": "Fortaleza • CE",
    "quality": "panorama-original"
  },
  {
    "id": "brasilia",
    "name": "Brasília • DF",
    "quality": "panorama-original"
  },
  {
    "id": "vitoria",
    "name": "Vitória • ES",
    "quality": "recorte-prancha"
  },
  {
    "id": "goiania",
    "name": "Goiânia • GO",
    "quality": "recorte-prancha"
  },
  {
    "id": "campo_grande",
    "name": "Campo Grande • MS",
    "quality": "recorte-prancha"
  },
  {
    "id": "cuiaba",
    "name": "Cuiabá • MT",
    "quality": "recorte-prancha"
  },
  {
    "id": "aracaju",
    "name": "Aracaju • SE",
    "quality": "recorte-prancha"
  },
  {
    "id": "joao_pessoa",
    "name": "João Pessoa • PB",
    "quality": "recorte-prancha"
  },
  {
    "id": "maceio",
    "name": "Maceió • AL",
    "quality": "recorte-prancha"
  },
  {
    "id": "natal",
    "name": "Natal • RN",
    "quality": "recorte-prancha"
  },
  {
    "id": "sao_luis",
    "name": "São Luís • MA",
    "quality": "recorte-prancha"
  },
  {
    "id": "manaus",
    "name": "Manaus • AM",
    "quality": "recorte-prancha"
  },
  {
    "id": "rio_branco",
    "name": "Rio Branco • AC",
    "quality": "recorte-prancha"
  },
  {
    "id": "porto_velho",
    "name": "Porto Velho • RO",
    "quality": "recorte-prancha"
  },
  {
    "id": "boa_vista",
    "name": "Boa Vista • RR",
    "quality": "recorte-prancha"
  },
  {
    "id": "belem",
    "name": "Belém • PA",
    "quality": "recorte-prancha"
  },
  {
    "id": "macapa",
    "name": "Macapá • AP",
    "quality": "recorte-prancha"
  },
  {
    "id": "palmas",
    "name": "Palmas • TO",
    "quality": "recorte-prancha"
  },
  {
    "id": "teresina",
    "name": "Teresina • PI",
    "quality": "recorte-prancha"
  }
];
window.CityRotation = (()=>{
 function create(list=window.CAPITAIS,random=Math.random){
  let queue=[],lastId=null;
  function next(){
   if(!queue.length){queue=list.slice();for(let i=queue.length-1;i>0;i--){const j=Math.floor(random()*(i+1));[queue[i],queue[j]]=[queue[j],queue[i]];}
     if(queue.length>1&&queue[queue.length-1].id===lastId){const a=0,b=queue.length-2;[queue[a],queue[b]]=[queue[b],queue[a]];}
   }
   const city=queue.pop();lastId=city.id;return city;
  }
  return {next};
 }
 return {create};
})();
