/* 13 bônus simbólicos: 4 quadros de 192x192 por linha do atlas. */
window.GameBonuses = (() => {
  const FRAME_SIZE=192,FRAMES=4,FPS=8,POINTS_PER_BONUS=1000;
  const catalog=Object.freeze([{"id":"fim_escala_6x1","name":"Fim da escala 6x1","row":0,"frames":4,"points":1000},{"id":"passe_livre","name":"Passe livre","row":1,"frames":4,"points":1000},{"id":"aumento_real_salario_minimo","name":"Aumento real do salário mínimo","row":2,"frames":4,"points":1000},{"id":"mais_especialistas","name":"Mais especialistas","row":3,"frames":4,"points":1000},{"id":"susp","name":"SUSP","row":4,"frames":4,"points":1000},{"id":"pe_de_meia","name":"Pé-de-Meia","row":5,"frames":4,"points":1000},{"id":"desenrola","name":"Desenrola","row":6,"frames":4,"points":1000},{"id":"isencao_ir","name":"Isenção do IR","row":7,"frames":4,"points":1000},{"id":"farmacia_popular","name":"Farmácia Popular","row":8,"frames":4,"points":1000},{"id":"universidades_publicas","name":"Universidades públicas","row":9,"frames":4,"points":1000},{"id":"minha_casa_minha_vida","name":"Minha Casa, Minha Vida","row":10,"frames":4,"points":1000},{"id":"reducao_desmatamento","name":"Redução do desmatamento","row":11,"frames":4,"points":1000},{"id":"reindustrializacao","name":"Reindustrialização","row":12,"frames":4,"points":1000}].map(b=>Object.freeze(b)));
  function initialCounts(){return Object.fromEntries(catalog.map(b=>[b.id,0]));}
  function choose(counts,lastId=null,random=Math.random){
    // Dá preferência a tipos ainda pouco coletados; nunca repete o mesmo consecutivamente.
    const eligible=catalog.filter(item=>item.id!==lastId);
    const weights=eligible.map(item=>1/(1+(counts[item.id]||0)*.65));
    const sum=weights.reduce((a,b)=>a+b,0);
    let roll=Math.max(0,Math.min(.999999,random()))*sum;
    for(let i=0;i<eligible.length;i++)if((roll-=weights[i])<0)return eligible[i];
    return eligible[eligible.length-1];
  }
  function award(state,id){
    const bonus=catalog.find(item=>item.id===id);
    if(!bonus)return 0;
    state.bonusCounts[id]=(state.bonusCounts[id]||0)+1;
    state.superPoints+=bonus.points;
    state.bonusTotal++;
    return bonus.points;
  }
  return {catalog,FRAME_SIZE,FRAMES,FPS,POINTS_PER_BONUS,initialCounts,choose,award};
})();
