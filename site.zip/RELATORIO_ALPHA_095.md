# Relatório de integração — Alpha 0.9.5

**Projeto:** Lula – Correndo pela Democracia  
**Base:** último `site.zip` Alpha 0.9.4 com quatro especiais, Tariflávio e correções anteriores.  
**Mudança de versão:** Alpha 0.9.4 → **Alpha 0.9.5**.  
**Publicação remota:** não realizada.

## Pacotes recebidos e incorporados

- `sprites_npcs_cenario_7tipos_final.zip`: 28 WebP RGBA dos sete conjuntos (quatro quadros cada).
- `mecanica_corredores_calcada_9_npcs_integracao.zip`: 12 WebP RGBA de dois corredores (oito + quatro quadros), módulos JavaScript e testes.
- `Pacote_Dialogo_Inicial_Integracao.zip`: módulo de prólogo, CSS e cinco retratos.

## Arquivos criados

- `js/mechanics/scenery_npcs.js`
- `js/mechanics/sidewalk_runners.js`
- `js/opening_dialogue.js`
- `css/opening_dialogue.css`
- `assets/sprites/scenery_npcs/` (28 sprites)
- `assets/sprites/sidewalk_runners/` (12 sprites)
- `assets/story/intro/` (cinco imagens)
- `docs/ESPECIFICACOES_ALPHA_095.md`
- `tests/scenery_npcs.test.js`
- `tests/sidewalk_runners.test.js`

## Arquivos alterados

- `index.html`: importação do CSS e módulos, revisão dos caminhos e título 0.9.5.
- `js/assets.js`: catálogos dos 9 conjuntos de NPCs.
- `js/game.js`: criação, atualização e desenho dos módulos, além do início do diálogo congelando o jogo.
- `css/style.css`: HUD e barra de ações ocultas enquanto o prólogo está ativo.
- `README.md`, `CHANGELOG.md`, `VERSAO.txt`.

## Comportamento testado

- Sintaxe de todos os arquivos JavaScript: **APROVADA** (`node --check`).
- Integridade dos 170 caminhos de imagens encontrados no manifesto `js/assets.js`: **nenhum ausente**.
- Verificação dos novos sprites: **28 imagens 192×192 RGBA** e **12 imagens 384×512 RGBA**; cinco retratos de 300×300.
- Testes unitários independentes `scenery_npcs.test.js`: **APROVADO**.
- Testes unitários independentes `sidewalk_runners.test.js`: **APROVADO**.
- Teste existente `combat_stamina.test.cjs`: **APROVADO**.
- O prólogo também foi percorrido até a última fala (cinco personagens) em simulação de navegador: após o brilho final da estrela, o módulo foi encerrado e o tempo/rolagem do cenário retomaram normalmente.
- Simulação Chromium com **código HTML/JavaScript real e imagens de teste**: botão Jogar disponível, prólogo inicia, relógio e posição do mundo permanecem em zero enquanto aberto, Pular diálogo libera a fase, sete conjuntos de NPCs reportam quatro frames carregados, corredor aparece, reinício reabre o prólogo e a ativação do boss limpa corredores. Sem erros JavaScript nas sessões simuladas.
- Captura visual com subconjunto de **sprites e cenário reais** do projeto: verificada posição dos NPCs ao fundo da calçada e jogador à frente. A escala do corredor com joinha foi ajustada de 0,35 para 0,25 para manter proporção com o protagonista.
- Layout de diálogo em viewport mobile horizontal de 844×390: card contido na área visível e com retrato e texto.

## Limitações de teste

O Chromium disponível nesta sessão bloqueou navegação direta ao servidor HTTP local e a domínios de teste (`ERR_BLOCKED_BY_ADMINISTRATOR`). Por isso, as verificações de execução no navegador foram realizadas com os scripts reais embutidos na página e gráficos carregados em memória; para alguns recursos antigos foram usadas imagens substitutas somente no **harness de teste**, não no ZIP final. Isto **não equivale à validação completa do pacote publicado por HTTP**. Não foram executadas sessões prolongadas em celular físico, publicação GitHub Pages ou partida até o final de Tariflávio. Validar especialmente a reprodução dos quatro especiais no ambiente publicado antes de considerar o release encerrado.

## Publicação / rollback

`site.zip` contém `index.html` na raiz, pronto para ser enviado pelo workflow existente de deploy de ZIP no GitHub. Nenhum commit, push ou alteração remota foi feito. Conserve uma cópia do ZIP anterior caso seja necessário reverter.
