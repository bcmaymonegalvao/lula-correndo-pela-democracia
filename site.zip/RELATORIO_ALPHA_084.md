# Relatório — Alpha 0.8.4

## Alterações implementadas
- Vilões/chefes agora surgem **sequencialmente** e somente quando a pontuação total alcança cada múltiplo de **1.000 pontos**.
- O inimigo comum foi substituído pelo **novo monstro-tesoura pequeno** baseado na imagem enviada.
- Removida a oscilação vertical dos chefes (efeito de “subir e descer”).
- Feedback de contato reforçado com efeitos de impacto maiores, partículas e knockback visual.
- Ajustado o enquadramento do background para reduzir falhas visuais em telas de computador.
- Controles de teclado reforçados para PC:
  - **Pulo:** Espaço / W / Seta para cima
  - **Golpe:** Z / X / Enter / J / K
  - **Pausa:** P / Esc

## Arquivos principais alterados
- `index.html`
- `css/style.css`
- `js/game.js`
- `assets/sprites/animacoes/enemy_walk/*.webp`
- `assets/sprites/animacoes/enemy_hit/*.webp`
- `assets/sprites/animacoes/enemy_die/*.webp`

## Validações realizadas
- Verificação de sintaxe JavaScript com `node --check`.
- Verificação estrutural do `site.zip` e dos assets atualizados.
