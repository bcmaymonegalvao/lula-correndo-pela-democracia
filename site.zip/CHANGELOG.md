# Alpha 0.9.1
- Novo Tariflávio com 11 frames reais (andar/dano/destruição).
- Intro animada e sprites separados de logo e frase piscante.
- Golpes usam somente os quatro quadros finais.
- Teclas/botões de mudança de plano vertical.
- NPCs sem caixas de fundo preto e maior recuo ao serem atingidos.
- Cada bônus recupera +1 HP sem limitar acúmulo.

