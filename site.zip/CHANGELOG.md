# Alpha 0.8.3 — Chefes sequenciais

- Seis novas spritesheets originais dos vilões, com oito quadros e fundo transparente; chefão final recortado da imagem do usuário em quatro quadros.
- Combates em série: seis inimigos com 20 HP e um último com 40 HP; nenhum próximo chefe aparece antes de o anterior ter sido derrotado.
- Encontros começando depois de um trecho inicial; robôs-tesoura comuns não surgem durante os duelos contra chefes.
- Barra de HP, animação de piscar, projéteis, impacto por golpe, recompensa em super pontos e recuperação parcial de vidas.
- Tela de vitória após a derrota do último chefão, mantendo a contagem individual dos 13 bônus e os demais placares.
- Console `animacoes.html` ampliado com a prévia dos sete chefes; assets tratados como opcionais no carregamento.
