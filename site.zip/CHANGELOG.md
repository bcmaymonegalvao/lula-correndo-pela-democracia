## Alpha 0.8.9 — Barra ESPECIAL, NPCs desacelerados e animações curtas
- Barra ESPECIAL e botão exibidos exclusivamente durante encontro ativo com o chefão.
- NPCs desacelerados de ~300–350 para 125 px/s em tela; Tesourinha em 148 px/s.
- Tempo de aviso dos ataques aumentado, reação e recuo visual revisados.
- Soco esquerdo, soco frontal e voadora usam apenas os 4 últimos quadros de cada animação (05–08).
- Console de animações inclui laboratório de ESPECIAL com 13 hits e mesmos efeitos visuais do jogo.
- Versionamento de cache atualizado para 0.8.9.

## Alpha 0.8.8 — Inimigos alternados, sempre pela direita

- Tesourinha novo e os sete monstrinhos adicionais alternam de forma garantida: Tesourinha → um de sete sorteados → Tesourinha → outro sorteado.
- A alternância vale tanto para a corrida quanto para as invocações de Tariflávio, sem gado eleitoral.
- Novos NPCs aparecem inicialmente fora da borda direita da tela, não surgem no meio do cenário.
- Nenhum NPC novo aparece enquanto o anterior estiver ativo ou em animação de destruição.
- Retirado o antigo robô-tesoura (`enemy_heavy`) do carregamento, console e recursos do site.
- Mantida a barra de especial (cada 3 NPCs invocados derrotados), o golpe de 13 hits e o chefão aos 10.000 pontos.

## Alpha 0.8.7

- Tariflávio agora permanece no canto direito da tela na batalha final.
- O chefão invoca um NPC aleatório entre: Miliciano, Petróleo Privatizado, Desmatamento, Terras Raras, Fake News, Orçamento Secreto e Repressão.
- Após derrotar cada grupo de 3 NPCs invocados, uma carga do especial é liberada.
- Novo botão de especial no mobile e atalho C/L no PC.
- Novo super golpe global: Maromba's Comunista, com 13 hits em overlay cinematográfico estilo Marvel vs Capcom.

## Alpha 0.8.7
- Apenas monstrinhos da tesoura e Tariflávio aparecem na fase.
- Tariflávio surge após 10.000 pontos, com a pista livre, e tem 40 HP.
- Animações das tesourinhas refeitas sem recorte de pixels pretos do corpo, eliminando transparência indevida.
- Chefão travado à base do chão; movimento apenas horizontal, sem saltos.
- Demais chefes desativados e preservados apenas no projeto.

## Alpha 0.8.7
- Apenas monstrinhos da tesoura e Tariflávio aparecem na fase.
- Tariflávio surge após 10.000 pontos, com a pista livre, e tem 40 HP.
- Animações das tesourinhas refeitas sem recorte de pixels pretos do corpo, eliminando transparência indevida.
- Chefão travado à base do chão; movimento apenas horizontal, sem saltos.
- Demais chefes desativados e preservados apenas no projeto.

# Alpha 0.8.5 — Movimentação, combate e aparição por pontuação

- Chefes em ordem com limite de 3.000 pontos a mais por encontro: 3.000, 6.000, 9.000 etc.; só aparece o próximo quando o inimigo anterior já saiu da pista.
- Inimigo tesoura atualizado com sprites substitutos.
- Chefes recuam e avançam horizontalmente sem oscilação vertical.
- Sinalização antecipada dos ataques e efeitos de contato reforçados.
- Mantidos os controles móveis e de teclado no PC.
- Corrigidos os carimbos de versão do HTML, CSS, JavaScript, console de animações, manifestos e cache de imagens.

## Alpha 0.8.4
- Chefes agora surgem em ordem a cada 1.000 pontos acumulados.
- Inimigo comum substituído pelo novo monstro-tesoura pequeno.
- Feedback de acerto reforçado e suporte ampliado a teclado no PC.
- Ajustes de enquadramento do background e alinhamento visual.

# Alpha 0.8.3 — Chefes sequenciais

- Seis novas spritesheets originais dos vilões, com oito quadros e fundo transparente; chefão final recortado da imagem do usuário em quatro quadros.
- Combates em série: seis inimigos com 20 HP e um último com 40 HP; nenhum próximo chefe aparece antes de o anterior ter sido derrotado.
- Encontros começando depois de um trecho inicial; robôs-tesoura comuns não surgem durante os duelos contra chefes.
- Barra de HP, animação de piscar, projéteis, impacto por golpe, recompensa em super pontos e recuperação parcial de vidas.
- Tela de vitória após a derrota do último chefão, mantendo a contagem individual dos 13 bônus e os demais placares.
- Console `animacoes.html` ampliado com a prévia dos sete chefes; assets tratados como opcionais no carregamento.
