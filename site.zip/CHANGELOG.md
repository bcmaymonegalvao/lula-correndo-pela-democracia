# Alpha 0.9.2 — Correção de transparência e piso

- Corrigidos buracos nos sprites da Tesourinha, com restauração direta do PNG RGBA original.
- Recriados os 11 sprites do boss Tariflávio diretamente da prancha original, preservando os detalhes escuros da armadura e evitando recortes retangulares artificiais. O separador horizontal da prancha original não integra os sprites.
- Rua expandida no Canvas: posição vertical G-100 e altura 240px; personagens dos três planos ficam visualmente sobre o pavimento.
- Mesmo ajuste da rua aplicado à abertura animada.
- Atualizada a versão dos scripts/assets para evitar imagens antigas no cache após o deploy no GitHub Pages.
- Criado backup completo de especificações em `docs/BACKUP_ESPECIFICACOES_ALPHA_092.md`.
- Preservadas as demais mecânicas da Alpha 0.9.1.

# Alpha 0.9.1
- Novo Tariflávio com 11 frames reais (andar/dano/destruição).
- Intro animada e sprites separados de logo e frase piscante.
- Golpes usam somente os quatro quadros finais.
- Teclas/botões de mudança de plano vertical.
- NPCs sem caixas de fundo preto e maior recuo ao serem atingidos.
- Cada bônus recupera +1 HP sem limitar acúmulo.

