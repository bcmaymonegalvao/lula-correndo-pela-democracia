## Alpha 0.9.3 (21/10/2026)

- Medidor **ESPECIAL** vertical no canto superior esquerdo; permanece oculto fora da batalha contra Tariflávio.
- Botão **PULAR** do lado direito, ao lado dos comandos de golpe e do especial.
- Mudança entre cenários com transição por **varredura nítida** (wipe), sem sobreposição transparente dos panoramas que causava borrão/ghosting.
- Canvas passa a **cobrir** toda a área da cena, evitando faixas pretas nas laterais no início da fase em telas com outra proporção.
- Combo limitado a **3 golpes** antes de **0,5 s** de recuperação após a terceira animação; debounce de **0,11 s** e janela de combo de 1,05 s, sem fila extra acima de 3.
- Tariflávio varia de posição vertical **ocasionalmente**, transicionando gradualmente entre planos e ficando alguns segundos parado.
- Mantidos sprites, NPCs, 13 bônus, HP, road, intro e original do projeto Alpha 0.9.2.

# Alpha 0.9.2 — Correção de transparência e piso

- Corrigidos buracos nos sprites da Tesourinha, com restauração direta do PNG RGBA original.
- Recriados os 11 sprites do boss Tariflávio diretamente da prancha original, preservando os detalhes escuros da armadura e evitando recortes retangulares artificiais. O separador horizontal da prancha original não integra os sprites.
- Rua expandida no Canvas: posição vertical G-100 e altura 240px; personagens dos três planos ficam visualmente sobre o pavimento.
- Mesmo ajuste da rua aplicado à abertura animada.
- Atualizada a versão dos scripts/assets para evitar imagens antigas no cache após o deploy no GitHub Pages.
- Criado backup completo de especificações em `docs/BACKUP_ESPECIFICACOES_ALPHA_092.md`.
- Preservadas as demais mecânicas da Alpha 0.9.1.

# Alpha 0.9.1
- Novo Tariflávio com 11 frames reais (andar/dano/destruição).
- Intro animada e sprites separados de logo e frase piscante.
- Golpes usam somente os quatro quadros finais.
- Teclas/botões de mudança de plano vertical.
- NPCs sem caixas de fundo preto e maior recuo ao serem atingidos.
- Cada bônus recupera +1 HP sem limitar acúmulo.

