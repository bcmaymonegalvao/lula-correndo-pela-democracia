## Alpha 0.9.5 — Revisão de benefícios, estrela, impacto e chefão (sem incrementar versão)
- Reintroduzidas as 13 categorias e suas contagens reais no resultado final e no PNG.
- Ortografia do prólogo revisada; estrela vermelha brilhante.
- Novo efeito de estrela vermelha no quarto hit real do combo.
- Poeira contínua em transparência sobre as lagartas de Tariflávio.
- Enquadramento vertical médio do boss ajustado para smartphones.
- Teste offline de relatório com 13 contadores; documentação dos testes e limitações.

## Alpha 0.9.5 — Ajustes experimentais do epílogo (sem nova versão)
- Cinemática de comemoração em caso de vitória, derrota sem celebração.
- Estrela vermelha com Lula e transição até resultados.
- Relatório Canvas 1080×1350 com PNG/compartilhamento e nome editável, usando snapshot real do jogo.
- Captação do cenário congelado e efeitos de torcida; teste offline incluído.

## Alpha 0.9.5 — relatório dinâmico de missão (revisão sem alteração de versão)
- Tela de fim de partida: comemoração apenas na vitória, estrela vermelha com Lula e arte PNG 1080x1350.
- Exportação local dos resultados reais, nome do jogador, replay e início; contagem total de inimigos derrotados.
- Preservação do antigo painel de pausa e da lógica de combate/especiais.

# Alpha 0.9.5 — Prólogo e novos NPCs de cenário

- Incorporados **sete conjuntos de NPCs decorativos** (4 frames de idle cada): eleitores L, trompetista, vira-voto, amor contra ódio e três artistas populares.
- Incorporados **dois NPCs móveis** na calçada (8 frames do corredor joia e 4 do caminhão), entrando pela esquerda; velocidade relativa da tela 340/295 px/s.
- Os nove conjuntos são apenas cenário: não interferem em HP, ataques, colisões, pontuação ou especiais.
- Integrado prólogo dialogado, após clicar JOGAR, na sequência Janones → Jones Manoel → Erika Hilton → Ana Eliza → Lula; cinco retratos e estrela de finalização.
- Durante o diálogo a física, o mundo e inimigos congelam; Enter/Espaço e toque avançam, com botão para pular; reinício repete o prólogo.
- Quatro especiais cinematográficos, boss Tariflávio, sistema de fôlego, medidores laterais, bônus e animação de poeira preservados.
- Atualizados caches dos scripts para Alpha 0.9.5; arquivos de sprites decorativos carregados de modo opcional.
- Integração local preparada para GitHub Pages; nenhuma publicação executada.

## Integração Diva Guerreira V2 — sem incrementar Alpha 0.9.4
- Módulo `js/specials/erika_diva_special.js` adaptado da versão enviada, usando sprites reais, retrato e card ERIKA HILTON.
- Ordem dos especiais: Jones (Maromba's Comunist) → 3/3 novamente → Érika (Diva Guerreira) → alternância.
- 13 impactos com identificadores únicos, mundo congelado, sem rAF adicional.
- Um único botão contextual e teclas C/L/V; energia somente com 3/3; Jones preservado.
- CSS: corrigido `@media` sem fechamento que restringia indevidamente estilos da HUD cinematográfica.
- Arquivos independentes e documentação preservados, sem publicação remota.

## Ajuste experimental pós-Alpha 0.9.4 (sem nova versão)
- Removido bloqueio obrigatório após três golpes; quarto ataque e seguintes permitidos.
- Sistema de fôlego para evitar repetição indefinida de ataques ao pressionar rapidamente.
- Pausa de fadiga de 0,25 s, com guarda por 0,34 s.
- Buffer máximo de um ataque; regeneração apenas após intervalo real sem golpear.
- Atordoamento dos NPCs prolongado para 0,78 s, para permitir o quarto golpe.
- Medidor discreto de fôlego no botão GOLPE.

## Revisão do especial — sem incremento de versão
- Substituição do especial antigo por **Maromba's Comunist**, executado por Jones Manoel com Hadouken de Livros de História.
- Apenas um botão e uma ação `special`; teclas C/L (V permanece alias para compatibilidade).
- Removidas a animação antiga e sua lógica de 13 golpes; preservados os 13 hits da nova animação.
- A barra de energia permanece compartilhada com a mesma progressão existente (3 NPCs = uma carga), mas já não há outros especiais.
- Sem publicação no GitHub.

## Integração experimental · Jones Hadouken (revisão local, sem publicação)
- Especial Hadouken de Livros de História, módulo independente `js/specials/jones_hadouken.js`.
- Visual cinematográfico com recorte do Jones e sprites originais fornecidos (8 + 7 células de 256×256), 13 impactos.
- Compartilha até 3 cargas de ESPECIAL e mantém Maromba's Comunista.
- Ativação: **V** no teclado ou botão 📚 JONES (durante Tariflávio). **C/L** continuam acionando Maromba.
- Congelamento da simulação do jogo durante o especial; apenas o relógio do módulo avança.
- Projétil horizontal com colisão baseada na área visual congelada do chefão.
- 13 eventos de dano (1 por impacto) com encerramento após efeitos finais.
- `teste_jones_hadouken.html` é o laboratório integrado; `assets/specials/jones/` contém os recursos.

## Alpha 0.9.4 — Poeira e hit-stun
- Efeito de 4 quadros de poeira e terra RGBA sob as esteiras do Tariflávio, com intensidade dependente da movimentação.
- NPCs atingidos entram em hit-stun por 0,64s: sem ataque ou caminhada e com deslocamento em coordenadas de mundo igual à velocidade de corrida, mantendo a posição na tela durante os golpes.
- Removidos os impulsos que afastavam NPCs para fora do alcance do combo.
- Preservei a sequência de até três golpes e o cooldown de 0,5s.
- Documentação e backup atualizados.

## Alpha 0.9.3 (21/10/2026)

- Medidor **ESPECIAL** vertical no canto superior esquerdo; permanece oculto fora da batalha contra Tariflávio.
- Botão **PULAR** do lado direito, ao lado dos comandos de golpe e do especial.
- Mudança entre cenários com transição por **varredura nítida** (wipe), sem sobreposição transparente dos panoramas que causava borrão/ghosting.
- Canvas passa a **cobrir** toda a área da cena, evitando faixas pretas nas laterais no início da fase em telas com outra proporção.
- Combo limitado a **3 golpes** antes de **0,5 s** de recuperação após a terceira animação; debounce de **0,11 s** e janela de combo de 1,05 s, sem fila extra acima de 3.
- Tariflávio varia de posição vertical **ocasionalmente**, transicionando gradualmente entre planos e ficando alguns segundos parado.
- Mantidos sprites, NPCs, 13 bônus, HP, road, intro e original do projeto Alpha 0.9.2.

# Alpha 0.9.2 — Correção de transparência e piso

- Corrigidos buracos nos sprites da Tesourinha, com restauração direta do PNG RGBA original.
- Recriados os 11 sprites do boss Tariflávio diretamente da prancha original, preservando os detalhes escuros da armadura e evitando recortes retangulares artificiais. O separador horizontal da prancha original não integra os sprites.
- Rua expandida no Canvas: posição vertical G-100 e altura 240px; personagens dos três planos ficam visualmente sobre o pavimento.
- Mesmo ajuste da rua aplicado à abertura animada.
- Atualizada a versão dos scripts/assets para evitar imagens antigas no cache após o deploy no GitHub Pages.
- Criado backup completo de especificações em `docs/BACKUP_ESPECIFICACOES_ALPHA_092.md`.
- Preservadas as demais mecânicas da Alpha 0.9.1.

# Alpha 0.9.1
- Novo Tariflávio com 11 frames reais (andar/dano/destruição).
- Intro animada e sprites separados de logo e frase piscante.
- Golpes usam somente os quatro quadros finais.
- Teclas/botões de mudança de plano vertical.
- NPCs sem caixas de fundo preto e maior recuo ao serem atingidos.
- Cada bônus recupera +1 HP sem limitar acúmulo.


## Ajuste experimental — medidor do especial (sem alteração de versão)
- Botão e atalhos ativam Maromba's Comunist apenas quando a barra estiver completa (3/3).
- Uso consome 3 cargas, mensagens parciais corrigidas.
