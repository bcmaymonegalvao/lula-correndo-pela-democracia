# Estrutura ZIP de publicação — Alpha 0.9.5

Este arquivo faz parte do site.zip para preservar o backup das especificações.

- `site.zip`: site jogável completo, com `index.html` na raiz, recursos `assets/`, `js/`, `css/` e backups técnicos Markdown em `docs/`.
- `projeto_apoio.zip`: laboratórios, testes offline, fontes originais e demais referências não necessárias à publicação.
- O workflow atual pode continuar extraindo exclusivamente `site.zip`. A biblioteca de sprites, cenários e mecânicas NÃO foi dividida.
- Os dois pacotes devem ser descompactados na mesma pasta se quiser reconstruir integralmente o conteúdo original.
- Os manifests contêm SHA-256 de cada arquivo original para checagem de integridade.

**Atenção:** a ausência de arquivos de laboratório no site publicado é deliberada, não é perda de recursos do jogo.
