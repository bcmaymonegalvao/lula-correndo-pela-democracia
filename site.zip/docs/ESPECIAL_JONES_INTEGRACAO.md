# Maromba's Comunist — especial único (Hadouken de Livros de História de Jones Manoel)

Estado atualizado do jogo (ainda NÃO publicado). O especial antigo **Maromba's Comunista** foi substituído completamente; não existem dois especiais selecionáveis.

- O único especial ativo chama-se **Maromba's Comunist** (grafia exata).
- A animação do golpe é **Hadouken de Livros de História**, executado por Jones Manoel, 13 hits e 13 eventos de dano.
- Código: `js/specials/jones_hadouken.js` (métodos `preload/start/update/render/cancel/isActive`).
- HUD vertical **ESPECIAL** aparece apenas quando Tariflávio está na fase.
- Um único botão 📚 **MAROMBA'S COMUNIST** aparece durante o boss; teclado: `C` ou `L` (e `V` como alias para compatibilidade).
- Cada uso consome uma carga do medidor de 3 cargas; cada 3 NPCs convocados eliminados concede 1 carga.
- Não ativa sem carga, durante animação, no cooldown de combo ou antes da entrada completa do chefe.
- A partida inteira congela durante a sequência Jones e retorna ao estado preservado; não há loop extra.
- Não foi realizado commit nem publicação remota.
