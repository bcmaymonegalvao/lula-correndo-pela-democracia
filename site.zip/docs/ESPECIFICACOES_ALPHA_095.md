# Especificações — Alpha 0.9.5

Fonte de verdade: última build Alpha 0.9.4 com quatro especiais e HP vertical, atualizada com os três pacotes enviados em 22/10/2026.

## Jogabilidade mantida
- Runner 2D com beat’em up, canvas base 960×540, corrida automática e movimento vertical; pulos duplos.
- Três golpes em sequência, fôlego/recovery, hit-stun, votos, bônus de políticas públicas (+HP).
- Tesourinha e seis tipos de inimigos que podem carregar a barra durante o boss.
- Tariflávio surge após 10.000 pontos, tem 40 HP, entrada lateral gradual, movimento vertical ocasional e poeira animada.
- Barra HP do boss à direita; especial vertical à esquerda, 3/3 cargas; quatro cinematográficos em ordem Jones, Erika, Ana Eliza, Janones (13 hits cada).
- Brasília em quatro períodos, rua larga e transições sem ghosting.

## Novidades
- `js/mechanics/scenery_npcs.js` desenha 7 conjuntos de sprites (4 quadros/cada), distribuídos em sequência ao longo da calçada, sem colisão.
- `js/mechanics/sidewalk_runners.js` anima um corredor de joinha (8 quadros, escala visual ajustada a 0,25 para manter proporção com o protagonista) ou caminhão (4 quadros) em baixa densidade, entre ~5.2–7.6 s, até 2 simultâneos, com interrupção no boss.
- `js/opening_dialogue.js`, CSS e 5 retratos entregam prólogo interativo ao clicar Jogar. Enquanto ativo, `update()` apenas avança o relógio do diálogo, preservando estado da partida.
- NPCs de calçada nunca entram em `state.enemies`, não dão nem recebem dano, não somam pontos e não participam do especial.

## Entradas do prólogo (mantidas conforme pacote enviado)
1. Janones alerta sobre Tariflávio.
2. Jones Manoel menciona tesouraço e terras raras.
3. Erika Hilton menciona Bolsa Família, SUS e milicianos.
4. Ana Eliza defende os direitos.
5. Lula conclama a defesa dos benefícios; estrela de encerramento.

## Integração
- Módulos opcionais carregam imagens por `Image` e falhas registram aviso sem bloquear carregamento principal.
- Ordem de render: cenário > rua > NPCs decorativos e corredores > colecionáveis > inimigos > boss > protagonista > FX/especiais.
- O jogo mantém um só `requestAnimationFrame`; módulos utilizam `update(dt)` e `render(ctx)`.
- Reiniciar repete o prólogo e reinicializa os NPCs. Voltar ao início descarta o diálogo em progresso.

## Alterações técnicas
- `index.html`: registra novos scripts e CSS com revisão 0.9.5.
- `js/assets.js`: acrescenta manifestos `sceneryNpcs` e `sidewalkRunners`.
- `js/game.js`: integra `reset`, `update` e `render`; congelamento inicial.
- Sprites: 28 WebP dos sete conjuntos (192×192); 12 WebP dos corredores (384×512).
- Sem alteração nas imagens ou nos motores dos quatro especiais.

## Validação
- Verificar HTML/JS, manifestos, 40 sprites novos e 5 retratos.
- Em desktop e mobile: prólogo, pular diálogo, corrida com NPCs, pausa, boss e quatro especiais. Não confundir testes de carregamento com partida completa.
