# Relatório de atualização — Alpha 0.9.4

## Alterações
1. Integrados os quatro sprites RGBA de poeira ao mapa, animados a 9 FPS sob as esteiras do Tariflávio; transparência ajustada conforme a movimentação. A prancha original foi preservada em `docs/fontes_originais/poeira_terra_original.png`.
2. Implementado hit-stun de 0,64 s para Tesourinha e seis NPCs especiais: alvo interrompe ações e acompanha a rolagem na coordenada de mundo na mesma velocidade do jogador (214 unidades/s), permanecendo alcançável durante a sequência de golpes.
3. Retirados os impulsos de recuo excessivo que atrapalhavam concluir o combo. Dano, animações de impacto, combo triplo e cooldown 0,5s preservados.

## Verificações efetuadas
- Sintaxe: `node --check` em JavaScript (sem erros).
- Pré-carregamento em Chromium com assets embutidos: 130/130 arquivos; falhas: 0; sem erros de console.
- Teste de movimento: NPC não gera projéteis no hit-stun e mantém posição visual constante (249,86 px antes e depois de 0,30 s de atordoamento).
- Dano sequencial: miliciano (4 HP) tomou 3 hits distintos; Tesourinha (3 HP) foi destruída no combo de 3 hits.
- Chefão: quatro quadros de poeira carregados, barra do especial visível durante boss; 40 HP preservados.
- Teste em localhost/publicação GitHub Pages e dispositivos móveis não realizado neste pacote. Publicar para validar no celular.
