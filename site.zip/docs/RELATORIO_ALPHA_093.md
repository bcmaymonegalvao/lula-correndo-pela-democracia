# Relatório técnico Alpha 0.9.3 — 21/10/2026

## Mudanças

1. Medidor **ESPECIAL** vertical à esquerda, com preenchimento de baixo para cima e ARIA `progressbar`; permanece invisível fora do combate final.
2. Botão **PULAR** transferido para a extremidade direita. SUBIR e DESCER continuam à esquerda, enquanto GOLPE/ESPECIAL ficam no grupo da direita.
3. Transição de cenário agora é um *wipe* nítido de **1,1 segundo**: um panorama não é misturado com o outro por transparência, evitando o ghosting/borrado. O preenchimento do Canvas usa escala de cobertura, evitando laterais pretas em formatos distintos de 16:9.
4. Combate em sequências de até **três golpes** (três ações no máximo, incluindo ações enfileiradas), com **0,5 segundo de cooldown** após a animação do terceiro. Anti-bouncing/debounce de **0,11 segundo**; janela de continuação de combo de **1,05 segundo**. Feedback `RECUPERANDO 0.xs` no HUD. Os ataques usam quatro quadros preservados.
5. Chefão Tariflávio: muda ocasionalmente de plano (alturas -62, -40, 0 e +22 pixels), transicionando a 34 px/s, e mantém a posição durante 3–5 s entre tentativas. Impactos do especial acompanham a posição vertical.
6. Mantidos os 13 bônus, o +1 HP por bônus, a tesourinha, os seis NPCs temáticos, as animações reconstituídas e os backups originais.

## Testes realizados

- **Node / V8**: sintaxe dos módulos `game.js` e `combat.js` verificada, sem erros.
- **Teste automatizado do combo**: conferiu cadeia exatamente de 3 golpes, bloqueio de quarto golpe, debounce contra cliques duplicados, cooldown após o terceiro, liberação após 0,5 s e reinício da cadeia. **Aprovado.**
- **Chromium local em build de teste com assets embutidos**: 126/126 imagens carregadas; início da partida, HUD do especial oculto antes de Tariflávio, botão PULAR localizado à direita, ativação da HUD durante a luta, medidor vertical à esquerda, entrada do chefe e deslocamento vertical ocasional verificados; nenhum erro JS de página. **Aprovado.**
- **Troca de cenário no Chromium**: transição manhã → tarde testada após avanço de fase; nova imagem ocupa região recortada com limite visível e sem composição alpha dos fundos; pixel examinado na lateral esquerda opaco e não preto. **Aprovado.**
- **Recursos gráficos**: caminhos em `assets.js` verificados contra conteúdo real do ZIP; nenhum arquivo ausente.

## Limitações

A sessão de validação foi realizada no ambiente local, com os arquivos gráficos reais carregados em memória. O comportamento no GitHub Pages e no Android deve ser confirmado após o deploy; não afirmamos publicação remota automática.

## Backup

- `docs/BACKUP_ESPECIFICACOES_ALPHA_093.md` — especificações atualizadas e histórico 0.9.2 integral.
- `docs/BACKUP_ESPECIFICACOES_ALPHA_092.md` — cópia anterior preservada.
- `docs/fontes_originais/` — originais dos sprites da Tesourinha e de Tariflávio.
