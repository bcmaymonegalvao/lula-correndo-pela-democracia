# Relatório técnico — correções de NPCs, controles e especiais

## Ajustes aplicados

1. **NPCs decorativos corrigidos**
   - Substituição dos 28 sprites de cenário por versões íntegras do pacote `sprites_npcs_fundo_azul_28_webp.zip`.
   - Eliminados os artefatos visuais recorrentes nas figuras.

2. **Controles mobile reorganizados**
   - Botões **SUBIR** e **DESCER** ampliados.
   - Botão **ESPECIAL** reposicionado em uma pilha vertical no canto direito, acima do botão **PULAR**.
   - Ajustes responsivos adicionais para telas em retrato e paisagem.

3. **HUD refinado**
   - Compactação adicional das barras verticais de HUD em telas pequenas.
   - Pequeno reposicionamento das barras do boss e do especial para preservar legibilidade.

4. **Tesourinha causando dano**
   - A Tesourinha agora tem telegraph, ataque curto e dano confiável no contato/ataque.
   - Adicionado feedback visual do golpe.

5. **Correções defensivas no especial**
   - Atualização robusta do botão do especial (ícone, rótulo e acessibilidade).
   - Mantido o bloqueio correto quando a barra não está completa ou quando há cinemática ativa.

## Arquivos alterados

- `index.html`
- `css/style.css`
- `js/game.js`
- `assets/sprites/scenery_npcs/**` (28 arquivos substituídos)

## Testes recomendados

1. Abrir o jogo no celular em modo retrato e paisagem.
2. Verificar os 7 NPCs decorativos ao longo da calçada.
3. Confirmar que os botões **SUBIR** e **DESCER** ficaram maiores.
4. Confirmar que o botão **ESPECIAL** ficou acima do botão **PULAR**.
5. Deixar a Tesourinha alcançar o Lula e verificar perda de vida.
6. Encher a barra de especial e validar acionamento e retorno ao jogo.
