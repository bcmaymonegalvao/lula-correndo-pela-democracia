# Revisão — Maromba's Comunist (especial único)

Esta revisão mantém a base Alpha 0.9.4 sem incremento de versão e sem publicação.

## Regra atual (substitui toda documentação histórica divergente)

- **Nome definitivo:** Maromba's Comunist.
- **Executante:** Jones Manoel; animação: Hadouken de Livros de História.
- **Especial anterior:** removido do sistema jogável (sem botão, atalho, animação ou lógica de dano concorrente).
- **Ativação:** um único botão 📚 **MAROMBA'S COMUNIST**, ou `C`/`L` no teclado (`V` aceito como alias legado de teclado). Aparece durante Tariflávio.
- **Carga:** usa o medidor vertical existente. A cada três NPCs invocados derrotados, uma carga (máximo 3). Cada especial consome 1 carga.
- **Efeito:** cut-in do Jones, disparo de livros de história, 13 impactos e 13 eventos de dano (1 HP por hit), depois restauração integral da partida.
- **Restrições:** boss ativo e totalmente introduzido, carga disponível, imagens prontas, sem animação concorrente e sem ataque/combo/cooldown ativo.
- **Módulo único:** `js/specials/jones_hadouken.js`; comandado por `triggerSpecial()` de `js/game.js`.

## Verificação local executada

Teste determinístico do módulo com imagens simuladas: duas ativações sequenciais no mesmo chefe de 40 HP; cada sequência emitindo 13 callbacks de dano, com HP 40 → 27 → 14, sem especial simultâneo. Sintaxe validada com `node --check`.

A validação visual na página publicada e no celular ainda depende de publicação/autorização. Nenhum commit ou deploy foi realizado.
