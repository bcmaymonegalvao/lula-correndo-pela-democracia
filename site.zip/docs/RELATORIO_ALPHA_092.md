# Relatório da Alpha 0.9.2

## Problemas tratados
**Furos em sprites:** decorriam de recortes e máscara de transparência que suprimiam pixels escuros reais ou cortavam partes do desenho. Reconstruí os 24 quadros da Tesourinha a partir do PNG RGBA original e os 11 quadros do Tariflávio a partir da prancha de origem, removendo rótulos e barras da composição que não pertenciam aos personagens.

**Rua estreita e personagens flutuando:** antes o desenho do pavimento começava em `G-10` e tinha apenas 146 px de altura, deixando a faixa traseira acima do asfalto. Agora o desenho começa em `G-100` e tem 240 px, cobrindo os pés em todo o alcance de profundidade. A introdução recebeu a mesma correção. O arquivo-fonte da rua não foi redesenhado.

**Cache:** adicionado `v=0.9.2` aos recursos visuais que foram substituídos e aos scripts/CSS da página, evitando que o navegador utilize versões anteriores depois do deploy.

## Testes realizados
- Sintaxe: `node --check` dos JS essenciais — aprovado.
- Inspeção de sprites: quadros do boss e da Tesourinha renderizados com fundo de contraste — aprovado.
- Chromium com recursos reais incorporados como URLs de dados (sem servidor externo): 126/126 imagens carregadas, 0 erros no console/pageerror.
- Telas: inicial e jogo, corrida e pavimento ampliado visíveis; entrada gradual do Tariflávio constatada (`offset` de 1120 para ~721 durante o teste), HUD especial visível na batalha.
- Publicação GitHub Pages: depende de upload do `site.zip` no repositório e confirmação no navegador do usuário.

## Arquivo de backup
`docs/BACKUP_ESPECIFICACOES_ALPHA_092.md`, acompanhado dos dois PNGs originais em `docs/fontes_originais/`.
