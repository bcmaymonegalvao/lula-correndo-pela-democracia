# Integração de dois especiais — Ana Eliza e Janones (build experimental, sem versionamento)

**Jogo:** Lula – Correndo pela Democracia  
**Base:** Alpha 0.9.4 com sistema de fôlego, medidor 3/3, Tariflávio e especiais Jones/Érika.  
**Publicação:** nenhuma (somente pacote local para revisão).  

## Sequência configurada

Um único botão e as teclas `C` ou `L` (alternativamente `V`), **somente durante o confronto contra Tariflávio**:

1. **Jones Manoel — Maromba's Comunist:** Hadouken de Livros de História, 13 impactos.
2. **Érika Hilton — Diva Guerreira:** Bandeira da Diversidade, 13 impactos.
3. **Ana Eliza — Justiça Popular:** energia rosa, balança da justiça e corações, 13 impactos.
4. **Janones — Mobilização Popular:** onda azul com bandeiras e representação de multidão, 13 impactos.

Depois do Janones, a ordem volta ao Jones. Cada especial consome 3/3 cargas; **a barra precisa encher novamente** antes do próximo. Apenas um cinematográfico pode estar ativo por vez. Continua sendo preciso derrotar 3 NPCs convocados para obter uma carga (9 para um especial completo). O boss continua com seus 40 HP originais.

## Módulos adicionados

- `js/specials/cinematic_v3_engine.js` — adaptação do motor V3 para desenhar somente as camadas cinematográficas sobre o **mundo real congelado**. Sem `requestAnimationFrame` separado.
- `js/specials/ana_eliza_special.js` — configuração de Ana e referência aos sprites do pacote.
- `js/specials/janones_special.js` — configuração do Janones e seus sprites.
- `assets/specials/ana/` e `assets/specials/janones/` — arquivos RGBA reais fornecidos.
- `laboratorio/teste_ana_eliza_offline.html` e `laboratorio/teste_janones_offline.html` — HTMLs originais de testes visuais, fornecidos pelo usuário.

## Modificações no motor

- `index.html`: carrega os três scripts adicionais **antes** de `js/game.js`; atualiza descrição dos controles.
- `js/game.js`: sequência circular de quatro especiais; pré-carregamento independente e tolerante a falhas; atualização e renderização integradas ao loop original; atualização do medidor, botão e mensagens; controle de danos deduplicado por `eventId`; cancelamento seguro no reinício/retorno ao menu.
- Nenhuma alteração no funcionamento interno dos especiais Jones/Érika, sistema de corrida, pulos, NPCs, colisões, fôlego, cenários ou pontuação.
- O motor V3 originalmente tinha imagens provisórias de cenário/rua/Lula/chefão: **não são usadas** na versão integrada. A renderização é uma camada sobre a cena verdadeira, incluindo flashes sincronizados no boss.

## Comportamento dos novos especiais

`Congela jogo → Vento → Retrato à esquerda → Ana/Janones entra → Carregamento → Projétil original horizontal → 13 eventos de dano e flashes → Explosão → Retoma o mundo`.

O relógio cinematográfico continua avançando enquanto o estado do jogo (tempo, cenário, NPCs, câmera) fica congelado. Os componentes visuais usam os PNG/WebP recebidos e preservam transparência.

## Verificação executada

- `node --check` em todos os módulos e `js/game.js`: sem erros de sintaxe.
- `node --test tests/combat_stamina.test.cjs`: passou, preservando a mecânica de combate.
- Chromium desktop em ambiente de teste com scripts reais e imagens dos dois novos especiais carregadas em memória: carregamento da tela inicial e jogo funcionais; sequência **Jones → Érika → Ana → Janones → Jones** confirmada; 13 eventos de dano por especial; barra 2/3 bloqueia, 3/3 libera; cena congelada no decorrer de cada especial; nenhuma exceção JavaScript.
- Para evitar afirmar teste não executado: **não houve navegação HTTP de ponta a ponta dentro do Chromium**, nem teste físico em celular ou publicação no GitHub Pages. O pacote ainda deve passar pela validação nesses ambientes.
- O teste de sequência utiliza boss com HP ampliado **somente dentro do harness** para permitir verificar os quatro especiais completos na mesma simulação; o jogo entregue preserva 40 HP.

## Como testar

Após publicar numa hospedagem HTTP de testes, abra `index.html?test=1` para inspecionar o estado do jogo no console via `window.__game`, caso deseje testes de desenvolvimento. No fluxo normal, alcance 10.000 pontos, derrote inimigos invocados pelo Tariflávio e preencha a barra 3/3 antes de cada especial. Os HTMLs independentes da pasta `laboratorio/` também podem ser abertos localmente para revisar os gráficos de cada personagem.

**Sem alteração de número de versão** e sem commit/push/publicação remota.
