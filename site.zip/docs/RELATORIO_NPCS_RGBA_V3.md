# Correção de NPCs — alfa RGBA V3

- 28 PNGs RGBA 192×192 regenerados diretamente das sete pranchas originais do usuário.
- Assets com caminho novo (`assets/sprites/npc_rgba_v3/`) para impedir cache de sprites antigos.
- `js/assets.js` atualizado: usa exclusivamente os arquivos novos para os sete NPCs de calçada.
- Carregador verifica a transparência do canto e rejeita imagens opacas, evitando retângulos azuis/pretos mesmo em caso de arquivo incorreto.
- A tela inicial mostra `NPC RGBA V3 · fontes originais`: se esta inscrição não aparecer no site publicado, o deploy ainda está servindo uma versão antiga (verifique a origem de Pages em Settings → Pages, selecionando GitHub Actions).
- `site.zip` é o pacote para publicação. Não se requer alteração de versão Alpha 0.9.5.
- Não altera controles, especiais, a lógica de pontuação, cenas ou o caminhão.

## Validação concluída
- Jogo real, scripts completos e artes essenciais carregados no Chromium via recursos incorporados em memória, pois o navegador do ambiente bloqueia navegação HTTP local.
- `window.__game` reportou os sete NPCs com 4/4 quadros carregados, sem recursos faltantes e sem exceções JavaScript.
- Screenshot de jogo integrado (desktop e largura 915 px) gerado sem fundos artificiais.
- Teste independente com fundos Brasília, branco, verde, magenta e preto, 28/28 quadros carregados e sem erros no Chromium.
- O repositório GitHub atualmente contém um `index.html` antigo na raiz e `site.zip`; se Settings → Pages estiver configurado como *Deploy from a branch*, a versão publicada poderá continuar sendo o `index.html` antigo. O workflow `deploy-zip-pages.yml` exige origem **GitHub Actions**.
- A próxima publicação deve ser verificada pela inscrição `NPC RGBA V3` na tela inicial. Se ela não aparecer, a versão atual não foi publicada — não é possível concluir que o novo PNG falhou.
- Não foram testados o GitHub Pages ao vivo nem aparelho físico. Nenhuma alteração foi enviada ao repositório.
