# Relatório — correção de disponibilidade do especial (sem versionamento)

**Base:** Alpha 0.9.4 com combate por fôlego e especial único Maromba's Comunist (Jones Manoel).  
**Status:** alterações locais para revisão; nenhuma atualização feita no GitHub.

## Defeito e causa

O jogo exibiu `2 / 3`, porém habilitou Maromba's Comunist. Em `js/game.js`, tanto a aparência/estado do botão quanto `triggerSpecial()` autorizavam a ativação com `specialCharge > 0`. O medidor não era tratado como limite obrigatório.

## Correção

1. Em `js/game.js`, habilitar o especial somente quando `state.specialCharge === MAX_SPECIAL_CHARGES` (3/3) e as outras precondições de combate forem cumpridas.
2. Em `triggerSpecial()`, bloquear também o teclado enquanto houver menos de três cargas. Após `jones.start()` bem-sucedido, consumir a barra inteira e zerar os fragmentos.
3. Mensagens parciais `ENERGIA +1` e `Faltam X cargas`; somente `ESPECIAL PRONTO!` ao alcançar 3/3.
4. Corrigidos texto inicial e parâmetro de cache do arquivo JS para evitar que navegadores continuem executando a versão anterior.
5. Mantido ganho de uma carga a cada três NPCs invocados derrotados, nove NPCs do zero ao especial.

## Testes realmente executados

- `node --check js/game.js`: sintaxe válida.
- `node tests/combat_stamina.test.cjs`: aprovado; sequência de ataque e recuperação por fôlego preservadas.
- Chromium headless, `page.set_content` com HTML e JS reais; imagens substituídas por PNG 1×1 apenas no ambiente de teste, para superar bloqueio de navegação `localhost`:
  - 0/3, 1/3, 2/3: botão desabilitado, `triggerSpecial()` retorna `false` e nenhuma energia é consumida.
  - 3/3: botão habilitado; `triggerSpecial()` retorna `true`, inicia animação e a barra vai para 0/3.
  - 13 hits no boss: HP 40 → 27, personagem retorna ao controle ao terminar a animação.
  - Nenhuma exceção JavaScript no navegador.

Não foi possível testar navegação HTTP local no Chromium deste ambiente. É necessária validação adicional após publicação no GitHub Pages.
