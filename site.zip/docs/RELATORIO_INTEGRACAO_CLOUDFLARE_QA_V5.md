# Compatibilidade Cloudflare QA — V5

Workflow verificado no GitHub `bcmaymonegalvao/lula-correndo-pela-democracia`, branch main: `.github/workflows/cloudflare-pages-qa.yml`.
Este ZIP permite ambos os modos do workflow `workflow_dispatch`: `validar` e `publicar-qa` (somente autorizacao explicita para publicacao).

## Preparacao
- HTML/css/js/assets mantidos na raiz.
- `tests/scenery_npcs.test.js`, `tests/sidewalk_runners.test.js`, `tests/combat_stamina.test.cjs` disponiveis para `node --test`.
- `_headers` equivalente ao pacote candidato QA, preservando CSP e cache-control do fluxo ja testado.
- `npc_rgba_v5` mantem 28 sprites de 192x192; `npc_rgba_v4` removido da entrega por nao possuir referencias em runtime.
- `index.html` e `js/assets.js` atualizados para V5 em vez de etiquetas V3/V4.
- `MANIFESTO_ARQUIVOS_SHA256.json` antigo transferido para docs por nao corresponder aos novos arquivos. O workflow nao publica docs.

## Nao executado
Nenhuma alteracao no GitHub nem deploy do Cloudflare foi feita por este pacote.
