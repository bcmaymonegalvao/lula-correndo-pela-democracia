# Correção do medidor do especial — sem nova versão

Base preservada: Alpha 0.9.4 experimental com combate por fôlego e especial único Maromba's Comunist (Jones Manoel).

## Causa

A interface mostrava uma capacidade de 3 cargas (0/3 até 3/3), mas `js/game.js` habilitava o especial quando `specialCharge > 0`. Ou seja, 1/3 ou 2/3 permitiam usar o especial, apesar da barra incompleta.

## Regra corrigida

- Só liberar o botão e o atalho C/L (e V, por compatibilidade) com 3/3 cargas, Tariflávio ativo, Jones carregado e sem outra animação/conflito.
- Ao iniciar com sucesso, consumir todas as três cargas. Em caso de falha em `jones.start()`, não consumir nada.
- Ao acumular energia, cada três NPCs invocados derrotados acrescentam uma carga, até o máximo de três (nove derrotas para preencher de 0/3 a 3/3).
- Exibir mensagem `ENERGIA +1` em cargas parciais e `ESPECIAL PRONTO!` apenas em 3/3.
- Durante 0/3 a 2/3, o texto do HUD informa quantas cargas faltam e quantos NPCs faltam para a próxima.
- Reinício do jogo zera a carga como anteriormente. HUD só aparece na batalha contra Tariflávio.
- Mantidas todas as mecânicas de corrida, combate por fôlego, efeitos, animação Jones 13 hits, bônus e chefão.

Sem commit, publicação nem incremento de versão.
