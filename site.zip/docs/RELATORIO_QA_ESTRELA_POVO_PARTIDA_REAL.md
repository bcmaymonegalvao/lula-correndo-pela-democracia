# QA integrado — Estrela do Povo KOF / Alpha 0.9.5

**Estado:** pronto para revisão manual no Cloudflare QA; **sem deploy ou commit**.

## Escopo

Inspeção do `site.zip` que incorpora o combo de quatro golpes e NPCs RGBA V5. Execução de JavaScript original do jogo em Chromium headless. O harness de QA embute os scripts/CSS e intercepta as requisições de assets localmente, porque a navegação ao localhost é bloqueada neste ambiente. Para reproduzir origem de imagens CORS durante o teste, o harness configura `crossOrigin` apenas no JS injetado em memória (sem alteração dos fontes distribuídos). O loop de animação foi substituído por passos manuais do **mesmo** `update()`/`render()` do jogo, para manter condições reprodutíveis; os eventos de colisão, dano e FX são aqueles do motor real.

## Bug adicional corrigido

O módulo `js/reports/mission_report.js` ainda apontava para quatro recursos `npc_rgba_v3/`, ausentes do ZIP V5. Substituídas as quatro referências por `npc_rgba_v5/`; todos os caminhos agora existem. `index.html` recebeu um identificador novo no carregamento de `mission_report.js` para evitar cache antigo. Adicionado teste de regressão ao `tests/scenery_npcs.test.js`.

## Evidências verificadas

- Inicialização do motor e botão jogar: **OK**, com `loadingReport.essentialMissing=[]`.
- Assets carregados pelo gerenciador principal: **158/158**, sem falhas.
- NPCs decorativos V5: **28/28** carregados.
- Golpes por acionamento: **1 → 2 → 3 → 4 → 1**.
- 4 quadros de impacto em cada golpe: quadros **0,1,2,3** observados nos eventos reais de contato.
- Dano por acionamento: **-1 HP por alvo**, sem múltiplas aplicações no mesmo golpe.
- Sem inimigos no alcance: **0 efeitos de contato**.
- Dano por colisão verificado com **6 inimigos temáticos registrados no código original** (Miliciano, Petróleo Privatizado, Desmatamento, Terras Raras, Fake News e Orçamento Secreto), além do inimigo normal Tesourinha; nenhum NPC demonstrativo foi inserido no pacote.
- Teste de interação `pointerdown` com o botão de ataque em viewport mobile horizontal **844×390**: exatamente um acionamento do combo.
- Quatro módulos de especiais existentes foram inicializados; não foram editados.
- Chromium: **0 erros JS**, **0 recursos de imagem inexistentes** durante o teste.
- Node: **16 testes aprovados**, incluindo os três arquivos obrigatórios do workflow Cloudflare QA; `node --check` em todos os JS: **OK**.

## Limitações

Não foi realizado percurso completo do jogo com usuário humano, nem confronto integral com o chefão e uso completo de todos os especiais cinematográficos. A validade visual e a ergonomia em um aparelho Android real ainda dependem de revisão; testes headless e viewport não substituem hardware físico. A implementação da rotação de 180° no golpe 2 e a integridade de PNGs RGBA são verificadas pelos testes existentes e pelo código anterior; a inspeção visual em celular continua recomendada.

**O `site.zip` permanece compatível com o fluxo manual Cloudflare QA existente, que exige testes e seleção da operação `validar` ou `publicar-qa`.** Um push em `main` também pode acionar o workflow legado GitHub Pages; nenhuma operação remota foi efetuada.
