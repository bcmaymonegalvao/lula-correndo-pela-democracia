# Alpha 0.9.5 · Patch QA3 — créditos

**Criação e desenvolvimento:** Bruno César Maymone Galvão.

Identificação visível na tela de abertura, menu de pausa, tela final e exportação PNG. Versão discreta no rodapé da cena.

A identificação não altera o licenciamento de recursos de terceiros nem representa reivindicação de autoria sobre materiais externos.

Para versões seguintes, atualizar `js/build_info.js`, `VERSAO.txt` e as referências estáticas em `index.html`; manter coerência com `CHANGELOG.md`.
