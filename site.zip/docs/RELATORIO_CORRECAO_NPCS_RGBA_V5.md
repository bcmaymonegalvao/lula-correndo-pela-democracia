# Correção NPCs RGBA V5

Ajustes aplicados:
- limpeza de halos/artefatos residuais em bordas semitransparentes;
- promoção de pixels quase opacos para opacidade total;
- remoção de pixels residuais com alpha muito baixo;
- novos sprites em `assets/sprites/npc_rgba_v5/`;
- atualização dos caminhos em `js/assets.js`;
- offsets verticais individuais por tipo em `js/mechanics/scenery_npcs.js`.

Offsets aplicados (px na malha-fonte 192x192):
- eleitores_l: +0
- trompetista: -6
- vira_voto: +8
- amor_contra_odio: +10
- artista_pop: -7
- artista_tropical: -6
- artista_cancioneiro: -2
