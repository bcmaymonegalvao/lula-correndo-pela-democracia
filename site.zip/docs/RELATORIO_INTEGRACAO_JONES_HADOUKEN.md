# Relatório — Integração experimental do especial Jones Manoel

**Projeto:** Lula – Correndo pela Democracia  
**Base preservada:** Alpha 0.9.4  
**Estado:** Arquivos para revisão. **Não publicado no GitHub e sem versionamento.**

## Objetivo e entregas

Foi integrado o **Hadouken de Livros de História**, uma segunda opção de especial, usando os recursos gráficos fornecidos no pacote enviado e as transições de animação inspiradas no HTML original. O especial anterior **Maromba's Comunista** continua funcional.

A integração utiliza `js/specials/jones_hadouken.js`, uma máquina de estados com `preload()`, `start()`, `update(dt)`, `render(ctx)`, `cancel()`, `isActive()`, `isReady()` e `getState()`. O módulo não cria `requestAnimationFrame` próprio dentro do jogo.

A página `teste_jones_hadouken.html` é um laboratório independente, offline e autocontido, contendo o **mesmo módulo do jogo** e os sprites reais embutidos. O HTML original recebido permanece arquivado em `docs/referencias/`.

## Implementação

- `js/game.js`: integração com o loop existente, interrupção das atualizações normais durante a animação e retomada após a finalização; gasto de carga e aplicação de dano 1:1.
- `index.html`: botão **📚 JONES** durante a batalha, ao lado de **💥 ESPECIAL** (Maromba). Tecla **V** para Jones; teclas **C/L** permanecem para Maromba.
- `css/style.css`: botão e sobreposição cinematográfica sobre a HUD (barra de HP do chefão permanece disponível).
- `assets/manifest.json`: declaração dos novos recursos e laboratório.
- `assets/specials/jones/`: retrato vertical, sprite de Jones com 8 quadros, sprite de livros com 7 quadros, 3 efeitos de 256×256 e manifesto original.
- `docs/ESPECIAL_JONES_INTEGRACAO.md`: contrato de integração e regras de compatibilidade.

O movimento do projétil é horizontal, com colisão contra os limites visuais congelados do chefe. Os frames são recortados de **256×256 pixels** individualmente, sem vazamento entre células. Os **13 impactos** são disparados por transições temporais independentes, com piscadas branco/ciano sincronizadas a cada evento de dano. A explosão final não contabiliza um 14º golpe. O HP não cai abaixo de zero; a morte é concluída depois da sequência.

**Regras:** necessário chefão presente, completamente introduzido na tela, pelo menos uma carga, arte carregada, nenhuma animação de ataque/cooldown ativa e nenhum outro especial simultâneo. Se falhar o carregamento da arte de Jones, o jogo e Maromba permanecem disponíveis, com aviso no console.

## Testes efetivamente executados

| Teste | Resultado |
| --- | --- |
| Sintaxe JavaScript (`node --check`) | Aprovada |
| Integridade de PNG/WEBP da animação (Pillow) | 6/6 recursos novos válidos |
| HTML independente no Chromium (imagens reais) | Executou a animação completa; sem erros JS |
| Simulação de 13 impactos no HTML independente | 40 → 27 HP, **13 eventos de dano** |
| Jogo real no Chromium (assets inline para contornar bloqueio de navegação; parte dos assets não relevantes substituídos por imagens mínimas no teste) | Jogo iniciou, Jones ativou, ausência de erros JS |
| Congelamento de `state.time` e `state.world` enquanto Jones ativo | Confirmado |
| Compartilhamento da energia especial | Confirmado, 2 → 1 carga após ativar Jones |
| Jones + especial Maromba em sequência | Confirmado, 40 → 27 → 14 HP |
| Dois Hadoukens sucessivos | Confirmado, 40 → 27 → 14 HP, 13 danos por ativação |
| Exclusividade de especiais | Confirmada; disparo de Maromba recusado durante Jones |
| Retorno ao ataque normal após a animação | Confirmado |
| Servidor HTTP local | `GET /index.html`, JS, sprites, laboratório: **HTTP 200** |
| Navegação do Chromium ao servidor HTTP local | **Bloqueada pelo ambiente** (`ERR_BLOCKED_BY_ADMINISTRATOR`); não foi possível validar gameplay usando URL local |
| Testes no celular / GitHub Pages | **Não executados**; nenhum deploy foi feito |

**Limitação:** os testes completos do navegador com os assets reais do projeto servido por HTTP e a compatibilidade em dispositivos móveis requerem uma rodada externa ao ambiente; o jogo foi testado no Chromium com scripts reais e imagens embarcadas, e o laboratório usou os sprites reais fornecidos.

## Como revisar

1. Abrir `teste_jones_hadouken.html` diretamente no navegador ou a cópia disponibilizada fora do ZIP.
2. Na página, pressionar **Iniciar especial** e conferir retrato, animação, projétil, hits e explosão.
3. Publicar somente após autorização do usuário e confirmar pela versão real no GitHub Pages, preferencialmente fazendo upload do ZIP com o workflow atual.
4. No jogo: juntar 10.000 pontos, aguardar Tariflávio, derrotar 3 inimigos invocados para obter uma carga, pressionar **V/📚 JONES**. **C/L/💥 ESPECIAL** mantém Maromba.

A base Alpha 0.9.4 foi preservada. Nenhum commit, push ou deploy foi realizado.
