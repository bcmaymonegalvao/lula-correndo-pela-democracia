# Integração — Estrela do Povo KOF (4 golpes)

Base: Alpha 0.9.5 / NPC RGBA V5 / GitHub Actions + Cloudflare QA, sem alterações nos workflows.

- Combo em 4 toques: soco primeira mão → soco outra mão → chute esquerdo → soco primeira mão → repetição.
- 16 PNGs RGBA reais, 4 por golpe, 256×256 com margens transparentes; golpe 2 rotacionado 180° diretamente no PNG.
- FX são eventos gerados **exclusivamente** pela colisão verdadeira contra a hitbox do inimigo (deduplicação por `hitTargets` do motor), posicionados no centro da sobreposição.
- Brilho moderado com `shadowBlur=7`, alpha e `screen`; tamanho 92/94/104/100 pixels; duração .25/.255/.307/.265s.
- Ativados os 8 quadros corporais já oficiais de cada clipe (sem alterar escala, âncora, tamanho e alinhamento do personagem).
- Os 16 PNGs são carregados como essenciais antes de liberar o início do jogo.
- O exemplo standalone incorpora o mesmo GameCombat e o mesmo GameEstrelaPovo com sprites originais do jogo, e pode ser aberto offline.
- Fonte de inimigos original preservada. Não houve restauração de NPCs nem alterações nos especiais.

## Testes

- 15 testes Node executados e aprovados, inclusive testes anteriores de fôlego, NPCs V5 e runners.
- Sintaxe de todos os JavaScripts verificada com `node --check`.
- PNGs exportados comparados pixel a pixel com o HTML de referência (rotação de 180° no golpe 2).
- Chromium: laboratório offline verificou cinco acionamentos 1→2→3→4→1 com um acerto por toque, e tela mobile 390×844 sem erros de JavaScript.
- Chromium: contato de teste verificado com seis variantes de inimigos atualmente registradas, todas 1 HP por acionamento.
- **Limitação:** a renderização completa de `index.html` no Chromium não pôde ser concluída neste ambiente devido à restrição de navegação local; os testes do laboratório não substituem uma partida real, nem cobrem especiais/chefão/introdução.
- Deploy, commit, publicação em GitHub ou Cloudflare: **não realizados**.

## Instalação de QA

Substitua somente `site.zip` após revisão; o workflow existente `Cloudflare Pages - QA` usa operação `validar` para testar sem publicar. Atenção: o workflow GitHub Pages antigo no repositório publica no `push` da branch `main`; não faça push antes de desejar essa ação.
