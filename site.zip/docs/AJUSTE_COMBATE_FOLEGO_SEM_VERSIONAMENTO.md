# Alteração experimental – Combate por fôlego

**Projeto:** Lula – Correndo pela Democracia  
**Base preservada:** Alpha 0.9.4 + especial único Maromba's Comunist (Jones Manoel)  
**Status:** Integração para revisão, sem incremento de versão e sem publicação.

## Problema

Na implementação anterior, cada três golpes acionavam 0,5 s de bloqueio, durante o qual o NPC recuperava a movimentação e podia atingir Lula antes do quarto ataque. Como NPCs normais (não Tesourinha) possuem quatro HP, não era possível derrotá-los facilmente em uma única sequência.

## Solução aplicada

1. **Sem limite fixo de três.** Os três clipes visuais se alternam circularmente: soco esquerdo → soco frontal → voadora → soco esquerdo → ...
2. **Fôlego:** de 0 a 100; cada golpe aceito custa 18 pontos. Cinco golpes rápidos cabem em uma rajada com energia total.
3. **Antiespam:** não há golpes gerados simplesmente por manter a tecla pressionada; um comando antecipado por vez pode ser armazenado no buffer. O clique repetido deixa de disparar infinitos ataques sem intervalos: ao esgotar o fôlego entra uma recuperação obrigatória.
4. **Fadiga:** após esgotar os recursos para um próximo golpe, uma pausa breve de 0,25 s repõe pelo menos 95 pontos de fôlego. A recarga **não** acontece automaticamente após o terceiro golpe.
5. **Janela defensiva:** ao iniciar a recuperação, Lula fica protegido de dano de contato e projéteis por 0,34 s, evitando punições inevitáveis durante o bloqueio.
6. **Regeneração natural:** após 0,40 s sem atacar, o fôlego volta a 65 pontos/s (até 100). Pequenas lacunas entre toques rápidos não restauram energia e não viabilizam ataques ininterruptos.
7. **Agilidade:** durações de 0,40 s / 0,43 s / 0,50 s por movimento. Cada sprite original continua usando seus últimos quatro quadros e apenas um evento de dano por ataque/por NPC.
8. **NPCs:** tempo de atordoamento aumentado de 0,64 para 0,78 s, com atraso no retorno do ataque após o hit-stun. Mantida a compensação do scroll enquanto o inimigo está atordoado.
9. **Interface:** barra compacta de fôlego dentro do botão GOLPE, sem interferir no HUD especial vertical (que continua exclusivo do Tariflávio).

## Contrato técnico

- Arquivo proprietário: `js/combat.js`; `window.GameCombat.create()` preserva `press`, `update`, `move`, `frame`, `hitbox`, `reset`, `state`.
- Método adicional: `isRecoveryProtected()` indica janela de proteção por fadiga.
- Estado adicional: `stamina` (0–100), `recoveryGuard` (segundos), `cooldown` (segundos).
- `js/game.js` chama `isRecoveryProtected()` antes de aplicar dano a Lula e estende o hit-stun do NPC.
- Alterações de UI em `index.html` e `css/style.css`.
- O método e controle do Maromba's Comunist/Jones não foram removidos, nem foram alterados os pontos necessários para chamar o boss ou a coleta de bônus.

## Testes efetuados

- `node --check js/combat.js` e `node --check js/game.js`: passaram.
- Simulação Node.js: passos 1 → 2 → 3 → 1 → 2; início de fadiga ao fim da quinta animação rápida; bloqueio de buffer duplicado e guarda ativa durante recuperação.
- Chromium (scripts do jogo reais, assets essenciais e imagem do inimigo, incorporados em memória): o jogo iniciou e o miliciano passou de 4 HP a 0 em quatro ataques consecutivos, sem erro JavaScript de página. A recarga não bloqueou o quarto movimento.
- Navegação HTTP externa/localhost não foi executada no Chromium deste ambiente devido à política de bloqueio de URLs. **Testar no GitHub Pages e celular antes de considerar produção.**

## Critérios para ajustes futuros

- Testar cadência sob 30, 60 e 120 FPS, teclado e touchscreen.
- Ajustar `ATTACK_COST`, `STAMINA_REGEN`, `COOLDOWN_SECONDS` e `RECOVERY_GUARD` em `js/combat.js` conforme feedback da jogabilidade.
- Manter um único ataque aceito por comando intencional; evitar autorepeat quando pressionar e segurar.
