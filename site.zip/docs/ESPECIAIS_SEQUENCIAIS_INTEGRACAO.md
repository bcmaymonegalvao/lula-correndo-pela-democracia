# Especiais cinematográficos — integração sequencial sem publicação

A base é o site.zip recebido (Alpha 0.9.4, sem alterar numeração de versão).

## Ordem / controles

- Um único botão especial e teclas `C`, `L` (alias `V`).
- Especial **1: Maromba's Comunist**, Hadouken de livros do Jones Manoel — 13 hits.
- Assim que esse especial termina, o próximo é **Diva Guerreira — Bandeira da Diversidade**, da **Érika Hilton**, mas **só quando a barra é preenchida outra vez (3/3)**.
- Após a Diva Guerreira terminar, a ordem reinicia no Jones e assim sucessivamente.
- A barra exige 3/3 cargas; cada 3 NPCs convocados derrotados fornece 1 carga.
- Ambos consomem as três cargas completas e não podem ser disparados simultaneamente.

## Arquitetura

- `js/specials/erika_diva_special.js` — adaptação do módulo v2 enviado, com sprites originais e maquina de estados, utiliza o único rAF existente.
- `assets/specials/erika_hilton/` — spritesheets 8×320, 8×320, 6×256, retrato e manifesto.
- `js/game.js` — alternância sequencial, condições de carga, callbacks de dano único, congelamento da partida, botões e HUD.
- `teste_erika_diva_guerreira.html` — laboratório offline enviado pelo usuário com card e nome ERIKA HILTON.
- O especial Jones, sua lógica e sprites foram preservados.
- `docs/ESPECIAIS_SEQUENCIAIS_INTEGRACAO.md` — decisões técnicas e limitações de testes.

## Critérios

1. Jones precisa ser usado integralmente antes de a Diva ficar disponível.
2. Erika aparece no card: ERIKA HILTON / DIVA GUERREIRA / BANDEIRA DA DIVERSIDADE.
3. 13 eventos de dano deduplicados por ID.
4. Simulação, cenário, NPCs e timers congelados no especial, sem rAF adicional.
5. Ao terminar, restaura o mundo sem reposicionar personagens.
6. Nenhum commit nem publicação remota.

Documentação base: Alpha 0.9.4. Este é um ajuste sem incremento de número de versão.
