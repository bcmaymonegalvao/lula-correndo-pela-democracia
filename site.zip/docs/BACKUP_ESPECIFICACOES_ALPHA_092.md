# BACKUP DAS ESPECIFICAÇÕES DO JOGO
## Lula – Correndo pela Democracia | Alpha 0.9.2 | 21/10/2026

**Finalidade:** cópia portátil das regras, do projeto visual, da organização técnica e do estado atual. Este arquivo acompanha o `site.zip` publicado no GitHub Pages. É uma descrição do estado do produto e deve ser atualizado em futuras versões. O ZIP contém a versão jogável; o backup registra decisões e contratos da implementação.

### 1. Identidade, proposta e escopo
- Nome: **Lula – Correndo pela Democracia**.
- Gênero: runner 2D com deslocamento horizontal automático e profundidade vertical limitada, inspirada em jogos *beat 'em up* de rua.
- Estética: pixel art de arcade 16 bits com maior detalhamento, evocando SNES/PS1, Metal Slug e Mega Man X4 sem reutilizar assets desses jogos.
- Plataforma atual: navegador HTML5 Canvas, execução em celular (preferencialmente na horizontal) e desktop com teclado; distribuição de testes por GitHub Pages.
- Obra independente de sátira política e ficção, sem associação oficial a governo, partido ou campanha. Políticas e personagens são elementos ficcionais da jogabilidade.
- Cena protótipo: **Brasília**, do amanhecer à noite. Os outros panoramas de capitais brasileiras são ideias em desenvolvimento, não estão ativos nesta versão.

### 2. Motor e organização
- Tela lógica: **960 × 540 px**, canvas adaptado à janela e à densidade da tela.
- `index.html`: página inicial e tela do jogo.
- `css/style.css`: estilos, HUD, botões e comportamento responsivo.
- `js/game.js`: estado da partida, física, inimigos, boss, colisões, renderização e coleta.
- `js/intro.js`: abertura animada; Lula corre, aparecem bônus, logo e aviso piscam/flutuam.
- `js/assets.js`: endereços de sprites, cenários, efeitos, NPCs e chefão; consulta por `window.GAME_ASSETS`.
- `js/animations/{draw,timeline}.js`: desenho e temporização dos quadros.
- `js/combat.js`: três golpes, duração, fila de comandos e hitboxes.
- `js/bonus.js`: catálogo dos 13 bônus e seus valores.
- `js/bosses.js`: definição do Tariflávio.
- `js/fases.js`: sequência dos quatro panoramas de Brasília.
- `assets/sprites/animacoes`: corridas, saltos, golpes e animações da Tesourinha.
- `assets/sprites/boss_minions`: sprites de NPCs temáticos (andar/dano/ataque/destruição).
- `assets/bosses/final`: Tariflávio (4 frames de andamento, 3 de dano, 4 de destruição).
- `assets/foreground/rua_brasilia_loop.webp`: faixa de pavimento repetida horizontalmente.
- `assets/intro/{logo,press_start}.png`: elementos independentes da tela inicial.
- `assets/bonus` e `assets/sprites/coletaveis`: registros e atlas de bônus/votos.
- `animacoes.html`: console visual para inspecionar sprites.
- `assets/manifest.json`: manifesto dos caminhos e dos quatro cenários.

### 3. Personagem controlável
- Protagonista: caricatura em pixel art de Lula, idoso sorridente, barba e sobrancelhas brancas, chapéu de palha bege com faixa azul, paletó e calça azul-marinho, camisa vermelha, sapatos marrons.
- Corrida automática: **214 unidades de mundo/segundo**, com oito quadros.
- Pulo e pulo duplo; física: gravidade **1.300 unidades/s²**; pulo inicial aproximado **−530 unidades/s**.
- Três ataques em sequência ao apertar o mesmo botão: **soco esquerdo** (0,48 s), **soco frontal** (0,50 s), **voadora ascendente** (0,61 s). A animação de cada ataque usa **somente os arquivos `05.webp` a `08.webp`**, quatro quadros. As hitboxes acompanham a altura do personagem (inclusive durante o pulo) e geram impacto de quatro quadros ao acertar.
- Vida inicial: **3 HP**, apresentados em corações; sofrer contato/projétil reduz um ponto. O jogo termina quando vidas chegam a zero.
- A coleta de **qualquer bônus concede +1 HP**, sem limite máximo geral de corações imposto no código da coleta. A vitória contra o chefe restaura até o máximo de três corações pela lógica específica do chefe.
- Posição da base da corrida: `FLOOR = 423` no mapa lógico.
- Movimento vertical: corredor em três profundidades possíveis, com `laneY` entre **−48 e +45** em relação ao piso, alterado gradualmente a **152 px/s**; tocar subir/descer permite deslocamento discreto adicional.

### 4. Pavimento e nova correção Alpha 0.9.2
- Arquivo de textura: `assets/foreground/rua_brasilia_loop.webp`, que tem resolução fonte de **1140 × 146 px**.
- O desenho é repetido horizontalmente com largura lógica **1140 px** e deslocamento contínuo em função do avanço do mundo.
- Na Alpha 0.9.2, a textura é **exibida com 240 px de altura**, a partir de **FLOOR − 100 = 323**; não confundir resolução-fonte com tamanho exibido. Isso cobre a área do corredor incluindo a profundidade traseira `FLOOR−48=375` e dianteira `FLOOR+45=468`.
- A mesma projeção/altura é usada no cenário animado da tela inicial.
- Objetivo: evitar que pés dos personagens pareçam flutuar sobre o horizonte; sombra de contato acompanha o `laneY` dos personagens.
- A textura original foi mantida; foi alterado somente o modo de renderização no Canvas, para preservar a continuidade da rolagem e dos arquivos.

### 5. Cenários
- Quatro panoramas de Brasília: **manhã, tarde, pôr do sol, noite**; alternância por rolagem com transições graduais, clima visual ajustado por sobreposições.
- Cada período permanece em média **38 segundos** antes da mudança; duração de transição de aproximadamente **4,5 segundos**.
- O cenário avança como uma paisagem ampla; o pavimento passa por cima da base do panorama e rola independentemente.

### 6. Inimigos comuns
- Um oponente ativo por vez; após sua derrota, concluir os quadros de destruição antes do seguinte aparecer. Os inimigos entram pela **direita**.
- A alternância de tipos parte da sequência **Tesourinha → NPC temático aleatório → Tesourinha → NPC temático aleatório**, evitando repetir imediatamente o mesmo NPC temático quando possível.
- **Tesourinha:** pequeno monstro robótico cinza metálico de olhos vermelhos e tesoura acima da cabeça. Tem **3 HP**. Usa animações de andar (12 quadros), dano (4 quadros) e destruição (8 quadros).
- NPCs especiais ativos (**4 HP cada**): Miliciano, Petróleo Privatizado (tanque), Desmatamento (tronco com motosserra), Terras Raras (rocha com gemas), Fake News (TV), Orçamento Secreto (sacos de dinheiro). Os ativos utilizam sprites individuais de andar, ataque e derrota.
- Não utilizar NPCs PM nem gado eleitoral na rotação; outras definições históricas podem permanecer arquivadas, mas não devem ser ativadas sem decisão expressa.
- A velocidade dos NPCs é reduzida para dar espaço a combos; cada dano causa recuo perceptível e breve atordoamento. Efeitos de hit devem ser desenhados no contato efetivo.
- No ataque, o NPC pode sinalizar sua ação antes de lançar o projétil; sua barra individual reflete o HP restante.

### 7. Chefão e especial
- **Tariflávio:** chefão final, representado dentro de uma máquina perfuradora azul/amarela com esteiras, broca frontal e bandeira dos EUA (recurso visual satírico).
- O encontro ocorre quando o jogador atinge **10.000 pontos**, desde que não exista outro inimigo pendente.
- A entrada é **gradual pelo lado direito** da tela, sem teleportar à posição final.
- Chefão com **40 HP**, quatro poses de andamento, três de dano e quatro de destruição; posicionado visualmente num plano posterior/mais alto.
- Durante a luta, invoca inimigos **um por vez**. Após cada **três NPCs invocados derrotados**, o jogador recebe **uma carga** do especial. Podem ser acumuladas até **três cargas**.
- HUD de ESPECIAL e respectivo botão ficam **invisíveis fora da batalha contra Tariflávio**. Durante a batalha, o medidor surge no canto superior da interface.
- **Especial:** “Maromba's Comunista”; consome uma carga e aplica **13 golpes** sucessivos no chefão com sobreposição gráfica de tela inteira.
- A derrota do chefe dispara animação de destruição, vitória e tela de resultados.

### 8. Recompensas e resultados
- Votos coletáveis concedem **100 pontos** por voto ao total exibido (contagem de votos guardada separadamente).
- Benefícios protegidos: métrica de golpes acertados, somada separadamente, contribuindo **50 pontos por benefício** à pontuação total.
- Cada bônus especial rende **1.000 SUPER PONTOS** e um coração/HP extra.
- O total é `pontosEspeciais + votos × 100 + benefíciosProtegidos × 50`.
- O sorteio dos bônus dá preferência a tipos menos coletados, procurando não repetir o último imediatamente.
- Os **13 bônus** e seus identificadores: `fim_escala_6x1`, `passe_livre`, `aumento_real_salario_minimo`, `mais_especialistas`, `susp`, `pe_de_meia`, `desenrola`, `isencao_ir`, `farmacia_popular`, `universidades_publicas`, `minha_casa_minha_vida`, `reducao_desmatamento`, `reindustrializacao`.
- Fim de jogo/vitória: exibir votos, benefícios protegidos, maior combo, pontos totais e contagem individual de cada um dos 13 bônus. Premiação em jogo é simbólica, não factual.

### 9. Controles e interface
- **Desktop:** Espaço para pulo (duplo), W/↑ para subir de plano, S/↓ para descer, Z/X/Enter/J/K para golpe sequencial, C/L para especial durante luta final e P/Esc para pausa.
- **Mobile:** botões SUBIR, DESCER, PULAR, GOLPE; ESPECIAL aparece apenas com chefão.
- Tela inicial: Lula corre e coleta itens num panorama, logo independente flutua e “PRESSIONE QUALQUER BOTÃO PARA INICIAR” pisca; carregamento essencial antecede a ação de iniciar.
- HUD: votos, pontos totais, benefícios protegidos, hits do combo, tempo e vida; barra de HP do boss quando o boss entra; medidor ESPECIAL apenas durante o chefe.

### 10. Reparo dos sprites na Alpha 0.9.2
- Defeito anterior: recortes/máscaras do preto de fundo das pranchas deixavam **lacunas no corpo/armadura e áreas recortadas**, mais visíveis no robô-tesoura e no perfurador Tariflávio.
- Tesourinha: **restaurada a partir do PNG de origem com transparência RGBA original**, mantendo preto de contorno e interior, preenchendo apenas pequenos furos isolados na máscara; foram renderizados novamente 12 + 4 + 8 quadros `.webp`, em células de 192 × 192.
- Tariflávio: **11 quadros renderizados novamente da prancha de origem**, preservando as regiões internas escuras com máscara opaca reparada; retirados título, separadores horizontais e interferências da prancha. Cada quadro é salvo em célula transparente de **480 × 310**.
- Evitar “color key” indiscriminado para preto (ex.: tornar todo pixel `#000000` transparente): isso apaga detalhes reais dos inimigos e provoca o bug original.
- Os URLs dos assets corrigidos em `js/assets.js` receberam `?v=0.9.2` para invalidar versões antigas em cache após publicação.

### 11. Publicação e recuperação
1. Arquivo de deploy do jogo: **`site.zip`** com `index.html` na raiz, sem pasta extra envolvendo o site.
2. Publicação: enviar novo `site.zip` para a raiz do repositório GitHub Pages, substituindo o existente, e disparar/aguardar o workflow `deploy-zip-pages.yml` configurado anteriormente.
3. A URL online é a URL do projeto GitHub Pages configurado no repositório; a atualização remota não ocorre até o ZIP ser enviado e o workflow concluir.
4. Para recuperar a versão em outro chat, apresentar este backup e o arquivo `site.zip` ou repositório. As regras descritas devem prevalecer sobre um histórico de mensagens possivelmente desatualizado.
5. Não reconstruir o projeto do zero. Manter mecânicas existentes, comparando o manifesto com os recursos reais antes de qualquer alteração.
6. A pasta `docs/` também contém este backup. Ao liberar uma nova versão, incrementar o número no HTML, nos scripts, no `VERSAO.txt`, no manifesto e neste documento.

### 12. Critérios de regressão antes de nova publicação
- Tela inicial carrega, começa o jogo, corre e reproduz a instrução pulsante.
- Rua cobre as posições dos pés nas três faixas sem áreas vazias ou flutuação perceptível.
- Robô-tesoura e Tariflávio sem furos artificiais de transparência e sem partes da prancha invadindo outros quadros.
- Golpes usam quatro quadros, hitbox ativa e recuo no inimigo; salto duplo não perde os quadros.
- Cada um dos 13 bônus fornece exatamente 1.000 pontos e +1 HP; contadores são exibidos no encerramento.
- NPCs temáticos 4 HP; Tesourinha 3 HP; sem PM ou gado eleitoral.
- Apenas um NPC ativo por vez. Tariflávio chega aos 10.000 pontos, entra pelo lado direito e tem 40 HP.
- Carga do especial após três NPCs invocados derrotados; especial aplica 13 hits.
- Ausência de erros de sintaxe JS, arquivos ausentes ou falhas de carregamento que impeçam iniciar.
- Validar em navegador desktop e Android depois de publicar, pois conferência de arquivos locais não substitui teste remoto.

**Última consolidação deste backup:** Alpha 0.9.2, 21/10/2026.

### 13. Fontes de arte de recuperação preservadas neste backup
Além do backup textual, este ZIP guarda os PNGs completos de referência que permitiram reparar os furos de transparência:
- `docs/fontes_originais/tesourinha_original.png`: PNG RGBA com oito poses de Tesourinha em duas fileiras.
- `docs/fontes_originais/tariflavio_original.png`: prancha original do perfurador com movimentos, danos e destruição.

Estes originais servem apenas para futura reconstrução/revisão e **não são carregados pelo jogo**. A execução utiliza os quadros WebP otimizados em `assets/`.
