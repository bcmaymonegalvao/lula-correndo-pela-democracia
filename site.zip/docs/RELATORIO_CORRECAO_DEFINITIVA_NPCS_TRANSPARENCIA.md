# Correção de transparência — NPCs de cenário — Alpha 0.9.5

## Problema identificado

Os 28 quadros dos sete grupos decorativos de NPCs foram distribuídos como WebP RGB **sem canal alfa**. O fundo de trabalho do Sprite Fusion era azul opaco (#0000FF) e o renderizador 2D desenhava o quadrado inteiro. A troca anterior dos arquivos não eliminou o fundo azul.

## Solução aplicada

- Corrigidos os 28 arquivos no diretório `assets/sprites/scenery_npcs/` por pré-processamento offline.
- Removido apenas o fundo de croma-azul conectado às bordas da imagem, com proteção para tons azuis do desenho.
- Exceção para ilhas de azul estritamente equivalente ao fundo, quando internas ao sprite.
- Exportação WebP com canal **RGBA real**, compactação **lossless**, sem alterar a resolução de 192×192 px, nome, ordem ou enquadramento.
- Adicionada nova revisão de cache (`npc-rgba-clean-20261023`) ao script de carregamento e às URLs das imagens para reduzir a chance de visualização dos recursos antigos.
- Mantidos comportamentos, velocidades, posições, colisões e mecânicas da Alpha 0.9.5.

## Arquivos modificados

- 28 quadros em `assets/sprites/scenery_npcs/**/idle_*.webp`
- `js/mechanics/scenery_npcs.js` (cache busting)
- `index.html` (cache busting do módulo)
- Este documento.

## Validação executada

- Todos os 28 WebP possuem 192×192 pixels e canal alfa real (alfa mínimo zero e imagem com pixels opacos preservados).
- Verificada a transparência em diferentes fundos com visualização de sete conjuntos no Chromium, utilizando o HTML de testes offline.
- Teste HTML offline carregou 7 de 7 sprites animados e não produziu erros JavaScript.
- `node --check` passou para o módulo de NPCs e para `js/game.js`.
- ZIP teve integridade verificada e `index.html` está na raiz.

**Limitação:** o Chromium deste ambiente bloqueou a navegação direta pelo servidor HTTP local; portanto, o jogo inteiro não pôde ser validado por navegação normal. O teste visual foi executado com os recursos reais incorporados em memória no navegador. Após o upload no GitHub, valide em janela anônima ou com atualização forçada (cache).

## Sem alteração de versão

A versão continua **Alpha 0.9.5**. Nenhum commit ou deploy foi realizado.
