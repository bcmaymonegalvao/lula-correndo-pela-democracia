# Epílogo cinematográfico e relatório dinâmico — Alpha 0.9.5 (build experimental)

## Estrutura

- `js/epilogue.js`: motor de cinema independente, sem controle de movimento, pontuação ou colisão; compõe a cena congelada, multidão real dos NPCs, Lula (quadros reais da animação), confetes, estrela e áudio de comemoração.
- `js/reports/mission_report.js`: coordena o fluxo, captura única do resumo, painel, arte 1080×1350, PNG e Web Share API.
- `css/mission_report.css`: interface da cinematografia e resultados adaptada a telas pequenas.
- `assets/epilogue/lula_celebracao.webp`: sprite do pacote de referência.
- `assets/epilogue/aplausos_torcida.wav`: acompanhamento sonoro sintetizado localmente (sem gravações comerciais). Voz de torcida via síntese pt-BR quando disponível no navegador.
- `teste_epilogo.html`: laboratório completamente offline com estatísticas de **simulação**, exclusivo para testes.

## Fluxos

- Vitória (evento real `win()`): `victory (3,9s) → star (2,1s) → results → PNG/share/restart`.
- Derrota (evento real `end()`): `defeat (1,6s) → star (2,1s) → results → PNG/share/restart`.
- Reentradas durante a execução cinematográfica ou visualização dos resultados não são aceitas.
- Pular a cinemática não perde o resumo nem impede baixar o resultado.
- Compartilhamento utiliza arquivo PNG pela Web Share API quando suportada; caso contrário, baixa-se o arquivo.

## Dados de produção

O único ponto de captura é `makeRunSummary()` em `js/game.js` no exato `win()` ou `end()`. Os valores vêm de:

| Saída | Fonte no motor |
|---|---|
| Resultado | Evento `win()` ou `end()` |
| Fase e região | `cityCount`, `currentCity.name` |
| Pontuação | `totalScore()` |
| Votos | `state.votes` |
| Benefícios | `state.benefits` |
| Melhor combo | `state.bestCombo` |
| Tempo (ms) | `state.time * 1000` |
| Inimigos derrotados | `state.enemiesDefeated` |
| Chefão derrotado | `state.bossesDefeated > 0` |
| Bônus | `state.bonusTotal`, `state.bonusCounts` |

`makeSummary` retorna um objeto congelado; ao mudar o nome, o relatório cria uma cópia do resumo congelado, mudando apenas o nome. Valores de teste não existem no código de produção.

## Controles

- **Gerar minha arte**: redesenha Canvas 2D com as variáveis capturadas e o nome informado.
- **Baixar imagem**: PNG de 1080×1350 (4:5).
- **Compartilhar**: Web Share API com `File` PNG e download alternativo quando sem suporte.
- **Jogar novamente**: `onRestart → start()` do motor existente; zera contadores e executa prólogo habitual.
- **Tela inicial**: `onHome → goHome()` do motor.

## Restrições

Preserva a versão Alpha 0.9.5 e todos os outros recursos. Não inclui JSON/CSV como entrega final. Não publica no GitHub. O áudio pode ser bloqueado pelo autoplay e não interrompe a cena; o efeito visual independe de áudio.
