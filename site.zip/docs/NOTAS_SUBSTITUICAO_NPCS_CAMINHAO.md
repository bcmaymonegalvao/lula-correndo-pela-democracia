# Substituição de sprites — Alpha 0.9.5 (sem mudança de versão)

- Substituídos 28 quadros dos 7 conjuntos decorativos pelos arquivos enviados no pacote azul, convertidos para RGBA com chroma key de contorno (sem apagar as cores azuis internas).
- Recortados os quatro caminhões a partir da prancha fornecida e espelhados para apontarem à direita, mantendo 384×512 px e âncora dos pés em Y=489.
- A remoção do fundo azul foi limitada à região conectada às bordas e processada sem desenhar retângulos opacos.
- Mantidos JavaScript da jogabilidade, golpes, especiais, barra e demais recursos. Adicionados sufixos de cache somente nos módulos/arquivos gráficos alterados.

Arquivos gráficos alterados: 32 (28 NPCs + 4 caminhões).
