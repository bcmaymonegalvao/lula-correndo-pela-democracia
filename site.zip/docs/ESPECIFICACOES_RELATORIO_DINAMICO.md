# Relatório dinâmico final — Lula – Correndo pela Democracia

**Base preservada:** Alpha 0.9.5 (sem incremento da versão).  
**Módulo:** `js/reports/mission_report.js` e `css/mission_report.css`.

## Objetivo

Depois de vitória ou derrota, mostrar transição com estrela vermelha contendo o Lula, painel de resultados e arte 4:5 (Canvas 2D, 1080 × 1350), baixável como PNG para redes sociais. A vitória tem comemoração prévia; a derrota vai diretamente à transição sem parabéns. O relatório final substitui o modal antigo de fim de partida. O modal de pausa continua funcionando normalmente.

## Fonte dos dados

O jogo chama `makeRunSummary(result)` em `js/game.js` exatamente na conclusão de cada partida. O objeto enviado ao renderizador é uma **fotografia imutável das variáveis reais do jogo**, com estes campos:

| Campo | Fonte |
|---|---|
| `playerName` | Campo digitado pelo jogador na tela final |
| `result` | `win()` ou `end()` (`victory`/`defeat`) |
| `phaseName` | `currentCity.name` (cenário atual de Brasília) |
| `phaseReached` | `cityCount` (quantidade de cenários iniciados) |
| `score` | `totalScore()` |
| `votesCollected` | `state.votes` |
| `protectedBenefits` | `state.benefits` |
| `bestCombo` | `state.bestCombo` |
| `playTimeMs` | `state.time * 1000` |
| `enemiesDefeated` | `state.enemiesDefeated` incrementado uma vez por inimigo derrotado |
| `bossDefeated` | `state.bossesDefeated > 0` |
| `bonusesCollected` | `state.bonusTotal` |
| `bonusCounts` | Cópia de `state.bonusCounts` |

O objeto não recebe números de teste. **O HTML isolado usa um formulário de simulação explicitamente sinalizado como teste**, porque não dispõe do estado de uma partida executada.

## Fluxo de estados

1. Jogabilidade termina; `state.paused=true` e `state.ended=true` congelam a cena e impedem movimentações e colisões.
2. Vitória: overlay por 2,2 s com a mensagem “O povo venceu!” e confetes. Derrota: essa etapa é omitida.
3. Animação de estrela vermelha com Lula centralizado; estrela expande pela tela.
4. Painel final responsivo com o resumo real da partida e um campo para nome.
5. Arte Canvas 2D 4:5 gerada automaticamente; a prévia se atualiza quando o nome muda e pode ser atualizada via “Gerar arte”.
6. Botão “Baixar imagem PNG” serializa o Canvas como `image/png` e oferece arquivo `.png` sem CSV/JSON.
7. Botões “Jogar novamente” e “Tela inicial” retornam pelos métodos existentes, com reset da tela final.

## Dados e privacidade

O nome não é armazenado em servidor nem enviado a APIs. Os contadores são lidos localmente. A arte é gerada no próprio dispositivo. O jogo continua sendo obra independente de ficção e sátira; o relatório apresenta apenas métricas simbólicas da partida.

## Exportação e compatibilidade

- Canvas 2D com recursos gráficos locais do próprio site.
- PNG 1080 × 1350, tipografia legível, estrela vermelha e Brasília ao fundo.
- Prévia HTML responsiva para desktop e mobile, com rolagem vertical no celular.
- Download por Blob + `<a download>`; alternativa `toDataURL` se `toBlob` falhar.
- Recursos de imagem opcionais possuem renderização substituta se a imagem ainda não carregou; sem bloquear a partida.
- Não há novo loop de física: o próprio `requestAnimationFrame` da transição é usado só após o fim da partida, com o loop principal congelado.
- Em modo de teste, os resultados podem ser simulados via `?test=1` e `__game.win()/end()`; não existe exposição pública das estatísticas fora do modo teste.

## Manutenção

Ao adicionar novas métricas, alterar a criação do snapshot em `js/game.js` e a projeção visual em `renderArt()` do módulo. Ao acrescentar outra tela de finalização, evitar recriar timers ou lógica de pontuação. Preservar sempre a sequência de especiais e a lógica de combate já existentes.
