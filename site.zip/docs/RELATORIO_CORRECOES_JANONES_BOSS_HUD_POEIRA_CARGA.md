# Correções técnicas — build de revisão (versão Alpha 0.9.4 mantida)

## Escopo
- Correção anterior ainda pendente: card Janones na íntegra (`object-fit: contain` no canvas), escala fixa durante a concentração (sprite `charge1` sem aumentar/diminuir) e comemoração com `finish_clean.png` transparente, sem fundo azul retangular.
- HP do Tariflávio vertical no canto direito (HTML acessível com `progress` nativo e track visual CSS), sem modificar a barra de especial vertical à esquerda.
- Poeira das esteiras: mantém 4 frames em loop enquanto Tariflávio está presente e vivo, com camada de poeira por trás e névoa leve na frente; acompanha entrada e posição vertical.
- Recarga dos especiais: qualquer inimigo derrotado durante a batalha, incluindo Tesourinha e NPCs de todas as variantes, conta **uma única vez**. Não exige a flag `summoned`. A barra visual cresce parcialmente a cada inimigo (1/9 do total). A regra permanece 3 derrotas/carga, 3 cargas para usar (9 derrotas).
- Nenhum especial foi removido: Jones → Érika → Ana Eliza → Janones. Cada especial causa 13 impactos.

## Alterações em arquivos
- `index.html` — HUD de HP vertical, progresso parcial dos NPCs e cache-busting pontual.
- `css/style.css` — HP vertical à direita e visibilidade da cinematografia sem HUD sobre o retrato.
- `js/game.js` — HUD, poeira, recarga robusta, modo contain para cut-in em telas estreitas.
- `js/specials/cinematic_v3_engine.js` — card Janones sem recorte/deformação, carga estável, finalização transparente.
- `js/specials/janones_special.js` — referência adicional a `finish_clean.png`.
- `assets/specials/janones/finish_clean.png` — isolamento do personagem em transparência RGBA.
- `teste_janones_corrigido.html` — teste autossuficiente com assets embutidos.
- `docs/BACKUP_ESPECIFICACOES_ATUALIZACAO_JANONES_HUD_HP.md` — documentação.

## Testes efetivamente executados
- `node --check` validou os três JavaScripts alterados, sem erros sintáticos.
- Chromium com recursos reais resolvidos por interceptação de URL em memória: 130/130 recursos gerais carregados, sem erro JavaScript; posição do HP à direita e especial à esquerda verificada em desktop e viewport menor.
- Cenário de 9 inimigos derrotados: estados sucessivos (0 carga + 1/3, 0 + 2/3, 1/3, ... 3/3 cargas) e preenchimentos de 11,11% até 100%. A regra vale para NPCs comuns e temáticos durante o chefão.
- Teste funcional dos quatro especiais: Jones, Érika, Ana e Janones executaram 13 hits cada (Tariflávio 40 → 27 HP em cada teste), sem avançar o relógio nem a posição da fase; sequência retornou ao Jones.
- Teste offline independente do Janones no Chromium: passou pelo card, carga, finalização e 13 eventos de impacto únicos (40 → 27 HP), sem erros JavaScript.
- As pranchas de poeira possuem transparência real e são selecionadas em loop no motor; renderização em duas camadas conferida no código.

## Limitação
A navegação de Chromium diretamente a um servidor HTTP local foi bloqueada pelo ambiente (`ERR_BLOCKED_BY_ADMINISTRATOR`). Os testes funcionais foram realizados no Chromium com scripts reais e os bytes dos recursos locais via interceptação, sem alegar teste end-to-end no GitHub Pages ou em aparelho físico.

## Estado do projeto
Mantida a versão Alpha 0.9.4. Nenhuma publicação, commit ou push no GitHub.
