# Revisão técnica — Alpha 0.9.5 (sem nova versão oficial)

Projeto: **Lula – Correndo pela Democracia**

## Alterações implementadas

1. **Benefícios no relatório final:** a tela de resultados voltou a enumerar os 13 bônus originais, com seus nomes e quantidades individuais. O PNG 1080 × 1350 inclui os ícones reais do atlas `bonus_13x4.webp`, mantendo as estatísticas gerais.
2. **Origem dos dados:** `game.js` já capturava `bonusCounts` no snapshot final. O módulo `mission_report.js` agora consome os 13 contadores congelados no fim da partida, sem valores predefinidos para o jogador. Zeros são apresentados como zeros.
3. **Ortografia do prólogo:** `à solta`, `Bolsa Família`, inicial maiúscula nas falas, pontuação e vocativo revisados; nome **Érika Hilton** acentuado. A ordem dos personagens e a fala das terras raras foram preservadas.
4. **Estrela do prólogo:** gradiente vermelho, brilho avermelhado em três camadas e raios branco/vermelho; animação existente mantida.
5. **Quarto golpe confirmado:** ao atingir quatro hits reais no mesmo combo, o contato recebe uma estrela vermelha animada, com halo, contorno luminoso e onda de expansão em Canvas 2D. O efeito não interfere no dano nem no fôlego.
6. **Tariflávio:** poeira RGBA em loop é desenhada sobre os pixels inferiores das esteiras; base média do boss reduzida verticalmente na tela (deslocamento para baixo), com os enquadramentos dos especiais atualizados para a mesma posição.
7. **Laboratório offline:** `teste_relatorio_beneficios_offline.html` inclui campos editáveis para os 13 bônus, para demonstrar que a arte muda conforme os dados de entrada. Esses valores são de teste e não fazem parte da partida real.

## Arquivos alterados

- `js/game.js`
- `js/opening_dialogue.js`
- `css/opening_dialogue.css`
- `js/reports/mission_report.js`
- `css/mission_report.css`
- `index.html` (cache dos arquivos alterados)
- `teste_relatorio_beneficios_offline.html` (novo teste independente)
- `CHANGELOG.md` (registro dos refinamentos)

## Testes efetivamente executados

- `node --check` em todos os arquivos JavaScript: **aprovado**.
- `tests/combat_stamina.test.cjs`: **aprovado** (sequência 1–2–3–1, fôlego e recarga).
- `tests/scenery_npcs.test.js`: **aprovado** (7 catálogos, 28 sprites, renderização, scroll e reset).
- `tests/sidewalk_runners.test.js`: **aprovado** (12 imagens, direção/velocidade, boss e reset).
- Chromium, laboratório HTML offline: **13 bônus em vitória e derrota**; com valores simulados 3, 2 e 7, total capturado **12**; PNG gerado com **1080 × 1350** e tipo de imagem válido; **0 erros JavaScript** detectados.
- Chromium, resolução de 390 × 844: **sem estouro horizontal** do painel final.

## Limitação de validação

A navegação do Chromium para o site local foi bloqueada pelo ambiente. Uma tentativa de teste do jogo completo por interceptação de recursos excedeu o tempo disponível. Portanto, a execução integral da batalha, da nova estrela de combo e do movimento do chefão **ainda precisa de validação na página publicada e em um smartphone físico**. Não se deve considerar esses testes completos.

Nenhum commit, push ou publicação foi realizado. Versão oficial mantida: **Alpha 0.9.5**.
