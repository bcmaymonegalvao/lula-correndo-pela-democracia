# Teste dos NPCs em PNG — Alpha 0.9.5 (revisão sem versionamento)

## Alterações
- Os 28 frames dos sete conjuntos de NPCs decorativos foram disponibilizados em PNG RGBA 192×192 com cantos transparentes.
- `js/assets.js` agora aponta para os PNGs, e não para os WebP, no cenário.
- `js/reports/mission_report.js` usa os novos PNGs na multidão do epílogo.
- `index.html` recebeu revisão das URLs dos scripts para renovar o cache no GitHub Pages.
- `js/mechanics/scenery_npcs.js` carrega os PNGs com nova chave de cache.
- Os WebP anteriores foram preservados apenas como fallback histórico; o jogo integrado referencia PNGs.

## Verificações
- 28 PNGs presentes, resolução 192×192, transparência RGBA confirmada nos quatro cantos.
- Verificação de integridade ZIP e presença de `index.html` na raiz.
- Teste offline incorporado: `Teste_NPCs_PNG_Offline.html` mostra as 7 animações e confere os 28 frames.

## Limitação
O navegador de testes deste ambiente bloqueia a navegação direta por HTTP local e por `file://`; o fluxo completo do jogo ainda exige teste real no GitHub Pages. Esta revisão ainda não foi publicada.
