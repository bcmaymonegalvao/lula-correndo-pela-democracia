# Atualização técnica — sem mudança na versão Alpha 0.9.4

- HP de Tariflávio: HUD vertical à direita, contador 0..40 e atualização em tempo real inclusive nos especiais.
- Especial: HUD vertical preservada à esquerda. Cada NPC derrotado durante a luta com Tariflávio — Tesourinha e seis variantes — contribui uma vez, independentemente da flag `summoned`; 3 NPCs por carga, 3 cargas para ativação. O progresso fracionário é apresentado visualmente.
- Poeira: loop RGBA de 4 quadros sob as esteiras e névoa leve à frente, sem parar quando a máquina está imóvel; acompanha o movimento vertical.
- Janones: retrato 520×980 apresentado na íntegra com aspect ratio preservado, carregamento com sprite do corpo fixo (energia independente) e comemoração sem o retângulo azul do fundo.
- Preservados: 4 especiais alternados (Jones, Érika, Ana Eliza, Janones), 13 hits por especial, 3/3 cargas, combate, fôlego, cenário, bônus, mobile e desktop.
- Não houve publicação ou alteração de versão.
