# Lula – Correndo pela Democracia · Alpha 0.8.8

## O que mudou

- Os encontros da fase agora alternam **Tesourinha → NPC aleatório → Tesourinha → NPC aleatório**, escolhendo o NPC entre **Miliciano, Petróleo Privatizado, Desmatamento, Terras Raras, Fake News, Orçamento Secreto e Repressão**. O gado eleitoral não foi incluído.
- O sorteio evita repetir o mesmo tipo entre dois encontros sucessivos de NPCs não tesoura.
- **Todos nascem completamente fora da borda direita da tela**, entrando da direita para a esquerda. A posição inicial foi padronizada para `x_tela = 1135 px` em um canvas lógico de largura `960 px`.
- A fase só gera um novo inimigo quando a morte/destruição do anterior tiver terminado e ele tiver sido removido.
- Após 10.000 pontos, Tariflávio permanece fixo no canto direito e **invoca a mesma alternância** (Tesourinha / NPC sorteado). Ele só envia outro após o anterior desaparecer.
- Todos os inimigos normais da fase têm 3 HP. Durante a batalha final, Tesourinha mantém 3 HP, e os sete outros tipos têm 20 HP, preservando a resistência dos NPCs enviados pelo chefão.
- Após 3 derrotas de NPCs *invocados* por Tariflávio, ganha-se uma carga do especial Maromba's Comunista; o especial segue aplicando 13 hits no chefão.
- O antigo sprite `enemy_heavy` foi removido do carregador de imagens, galeria de animações, manifesto e assets de publicação. `enemy_walk`, `enemy_hit`, `enemy_die` continuam representando **a Tesourinha atual**.

## Arquivos alterados
- `js/game.js`: alternância, lógica de invocação, origem direita, movimento horizontal, contagem do especial.
- `js/assets.js`: remove o robô-tesoura antigo.
- `assets/manifest.json`: lista os NPCs ativos e remove referência obsoleta.
- `animacoes.html`: catálogo atualizado com os sete tipos e Tesourinha atual.
- `index.html`, `VERSAO.txt`, `README.md`, `CHANGELOG.md`: marcação consistente Alpha 0.8.8.

## Testes realizados
- Sintaxe JavaScript verificada com Node.js.
- 100% dos caminhos de assets referenciados em `js/assets.js` encontrados no projeto.
- Todos os WebP verificados como imagens válidas com Pillow.
- Fluxo lógico testado em Chromium com recursos de imagem em memória (sem navegação HTTP): o jogo iniciou sem exceções; 12 NPCs da fase e 6 invocados confirmaram alternância, aparecimento com X >= 960 px, e escolha aleatória dos tipos; três derrotas de NPCs invocados carregaram o especial; este aplicou exatamente 13 hits ao chefão (40 → 27 HP).
- Os testes lógicos com imagens em memória não substituem um teste visual completo da publicação no GitHub Pages e no celular. Publicação remota não efetuada.
