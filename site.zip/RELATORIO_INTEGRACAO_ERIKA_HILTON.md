# Integração — Diva Guerreira (Érika Hilton) com Maromba's Comunist (Jones Manoel)

## Estado

Base: `site.zip` da Alpha 0.9.4 mais recente fornecida (incluindo correção do medidor e combate por fôlego). **Nenhuma nova versão criada**, nenhum commit, push ou publicação.

## Arquivos adicionados

- `js/specials/erika_diva_special.js`: adaptação do módulo `erika_diva_special_v2_ErikaHilton.js` para scripts globais do motor atual, sem `requestAnimationFrame` próprio.
- `assets/specials/erika_hilton/hero_8_frames.png`: sprites corrigidos de Érika, 8 células 320×320.
- `assets/specials/erika_hilton/rainbow_projectile_8_frames.png`: animação corrigida do disparo, 8 células 320×320.
- `assets/specials/erika_hilton/rainbow_impact_6_frames.png`: seis quadros 256×256 de impacto.
- `assets/specials/erika_hilton/erika_portrait.png`: retrato usado no cut-in.
- `assets/specials/erika_hilton/manifest.json`: metadados de tempo/células.
- `teste_erika_diva_guerreira.html`: HTML offline corrigido do pacote original, com card ERIKA HILTON.
- `README_ESPECIAIS.md` e `docs/ESPECIAIS_SEQUENCIAIS_INTEGRACAO.md`: contrato de integração.

## Arquivos alterados

- `js/game.js`: instancia o segundo especial, implementa alternância Jones → Érika → Jones; o mesmo botão e teclas C/L/V acionam o próximo especial, só com 3/3 cargas; mundo congelado em ambas as cinematográficas; 13 eventos de dano da Érika deduplicados por ID; conclusão libera a movimentação normal sem reposicionar elementos.
- `index.html`: importa o módulo antes de `game.js`, atualiza a dica de controles.
- `css/style.css`: oculta HUD comum durante o especial da Érika e corrige bloco @media não fechado que impedia os estilos cinematográficos em telas desktop.
- `README.md`, `README_JONES.md`, `docs/ESPECIAL_JONES_INTEGRACAO.md`, `CHANGELOG.md`: documentação vigente. Histórico de integração anterior permanece arquivado com indicação de que foi superado.

## Ordem de execução dos especiais

1. O especial inicial continua sendo **Maromba's Comunist** — Jones Manoel, 13 hits, exige 3/3 cargas.
2. Após Jones terminar, o medidor volta a 0/3. A próxima especialidade liberada após recarregar a barra completamente é **Diva Guerreira** — Érika Hilton, Bandeira da Diversidade.
3. Depois de Érika terminar, a sequência retorna para Jones.
4. Não há execução simultânea, nem dois botões. Cada um consome 3 cargas completas; 1 e 2 cargas não habilitam o especial.
5. Cada carga continua sendo concedida após três NPCs invocados eliminados na batalha contra Tariflávio.

## Animação Érika (5,70 s)

Cut-in e vento / entrada / carregamento / disparo horizontal / 13 impactos sequenciais / explosão e restauração. As camadas de impacto, efeito e chefão são separadas; o boss é redesenhado apenas nos frames de flash para evitar duplicação visual. O texto **ERIKA HILTON**, **DIVA GUERREIRA** e **BANDEIRA DA DIVERSIDADE** está na animação real.

## Testes efetivamente executados

- `node --check` em todos os JS da integração: **aprovado**.
- Layout das spritesheets: 2560×320, 2560×320, 1536×256; cada célula possui bordas alfa vazias em ambas as extremidades: **aprovado**.
- Teste HTML offline corrigido em Chromium/Playwright: a página carrega sem exceções de JavaScript.
- Teste de integração no Chromium, em HTML carregado na memória com código real e 35 imagens reais relevantes (incluindo **Jones, Érika, Tariflávio, cenário e Lula**) e placeholders para outras imagens: carregamento, Jones primeiro, barra zerada, Diva como próxima ação apenas após nova carga completa, congelamento de mundo e tempo, **13 hits** (40 → 27 → 14 HP), ausência de exceções JS, retorno ao Jones: **aprovado**.
- Mobile simulado em Chromium, viewport 844×390 touch: Diva inicia sem erros e HUD some durante cut-in; sem erros JS observados.
- Servidor HTTP local de desenvolvimento: respostas HTTP 200 para `index.html`, módulos de ambos especiais, 4 sprites da Érika e teste standalone: **aprovado**.
- Limitação: neste ambiente, o Chromium pode bloquear navegação direta para endereço `localhost` por política administrativa. Portanto, a execução funcional em navegador foi feita com recursos reais essenciais carregados em memória e o servidor HTTP foi verificado separadamente. **Ainda é necessário testar o ZIP publicado no GitHub Pages, especialmente em celular real**.

## Critérios de regressão mantidos

Todos os arquivos da versão-base foram preservados; nenhum outro movimento, efeito, NPC, bônus, combo ou cenário foi apagado para integrar a Diva Guerreira. O Jones continua com o mesmo módulo/cinemática e a mesma quantidade de impactos.
