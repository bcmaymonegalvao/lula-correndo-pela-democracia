# Especiais cinematográficos — integração sequencial sem publicação

A base é o site.zip recebido (Alpha 0.9.4, sem alterar numeração de versão).

## Ordem / controles

- Um único botão especial e teclas `C`, `L` (`V` também funciona).
- **1. Maromba's Comunist — Jones Manoel** (livros de história; 13 hits).
- **2. Diva Guerreira — Érika Hilton** (bandeira da diversidade; 13 hits).
- **3. Justiça Popular — Ana Eliza** (balança, energia rosa; 13 hits).
- **4. Mobilização Popular — Janones** (onda e multidão; 13 hits).
- Após Janones, retorna a Jones.
- Cada uso consome 3/3 cargas; derrotar 3 NPCs convocados dá 1 carga.
- Todos se alternam em sequência, nunca ao mesmo tempo.

## Arquitetura

- `js/specials/erika_diva_special.js` — adaptação do módulo v2 enviado, com sprites originais e maquina de estados, utiliza o único rAF existente.
- `assets/specials/erika_hilton/` — spritesheets 8×320, 8×320, 6×256, retrato e manifesto.
- `js/game.js` — alternância sequencial, condições de carga, callbacks de dano único, congelamento da partida, botões e HUD.
- `teste_erika_diva_guerreira.html` — laboratório offline enviado pelo usuário com card e nome ERIKA HILTON.
- O especial Jones, sua lógica e sprites foram preservados.
- `docs/ESPECIAIS_SEQUENCIAIS_INTEGRACAO.md` — decisões técnicas e limitações de testes.

## Critérios

1. Jones precisa ser usado integralmente antes de a Diva ficar disponível.
2. Erika aparece no card: ERIKA HILTON / DIVA GUERREIRA / BANDEIRA DA DIVERSIDADE.
3. 13 eventos de dano deduplicados por ID.
4. Simulação, cenário, NPCs e timers congelados no especial, sem rAF adicional.
5. Ao terminar, restaura o mundo sem reposicionar personagens.
6. Nenhum commit nem publicação remota.

## Integração V3

Consultar `docs/INTEGRACAO_ANA_ELIZA_JANONES_V3.md`.
