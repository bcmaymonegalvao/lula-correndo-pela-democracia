# NPCs — Correção de referência RGBA V4 (Alpha 0.9.5)

Problema: pacotes de referência divergentes. O pacote site-candidato-qa.zip (gerado posteriormente) ainda utilizava 28 WebP antigos em js/assets.js. A variante V3 utilizava 28 PNG RGBA de melhor integridade visual.

Correção: parte da variante Alpha 0.9.5 com PNGs originais V3, transportados para uma pasta V4 de caminho inédito; substitui as 28 referências em js/assets.js e renova o cache-busting em index.html e scenery_npcs.js.
Mantém sprites PNG 192×192 sem reconstrução/redesenho. Os 28 quadros foram verificados individualmente por resolução, existência dos pixels transparentes e opacos e transparência dos quatro cantos.
Motor Canvas: composição `source-over` explicitada, escala final arredondada e validação do alfa aplicada ao pixel real (0,0).

Verificações possíveis neste ambiente: análise de pixels e geração de composições sobre fundos reais do jogo; `node --check`; validação estática dos caminhos; teste de integridade ZIP.
Limitação: browser Chromium do ambiente bloqueou tanto HTTP local quanto navegação file:// com ERR_BLOCKED_BY_ADMINISTRATOR; portanto, não foi possível certificar visualmente o jogo em execução no navegador de destino.

Teste: suba o conteúdo na raiz do GitHub Pages, recarregue sem cache e abra com `?test&npcdebug=1`. Consulte no console `__game.sceneryNpcs.debugState()`: esperado `loaded`=4 para cada um dos sete grupos.
A publicação/commit não foram realizados.

Total de quadros: 28 PNG RGBA.
