# Lula – Correndo pela Democracia — Alpha 0.9.5

Runner 2D HTML5/JavaScript para celular e computador. Versão preparada para testes pelo fluxo ZIP do GitHub Pages.

## Novidades

- Prólogo animado entre Janones, Jones Manoel, Erika Hilton, Ana Eliza e Lula no início da partida (pode avançar/pular).
- 7 grupos de NPCs de calçada com animações idle, decorativos.
- 2 novos NPCs rápidos no fundo da calçada (corredor fazendo joinha e caminhão).

A lógica principal do jogo e os 4 especiais pré-existentes permanecem no código.

**Publicação:** substitua o site.zip no repositório e execute seu workflow manualmente, se quiser atualizar GitHub Pages. Esta entrega não executou deploy.

**Documentação detalhada:** `docs/ESPECIFICACOES_ALPHA_095.md`.
