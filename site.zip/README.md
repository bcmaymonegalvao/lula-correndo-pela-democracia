# Lula – Correndo pela Democracia — Alpha 0.9.4

Runner HTML5 Canvas para navegador móvel e desktop, publicável no GitHub Pages.

## Controles
- PC: ESPAÇO pula, W/↑ sobe de plano, S/↓ desce de plano, Z ou X ataca, C/L usa especial contra o chefão, P pausa.
- Celular: botões SUBIR/DESCER, PULAR e GOLPE na parte inferior. Especial aparece somente com Tariflávio.

## Correções 0.9.2
- Tesourinha e Tariflávio reconstruídos dos sprites originais, sem perfurações de transparência nas áreas internas.
- Rua mais larga no Canvas: começa em G-100 e é desenhada com 240 pixels de altura, cobrindo os três planos de movimentação.
- Animação de abertura usa a mesma projeção da rua.
- Backup técnico completo em `docs/BACKUP_ESPECIFICACOES_ALPHA_092.md`.

## Funcionalidades mantidas da 0.9.1
- Abertura animada com Lula correndo por Brasília, coletáveis em movimento e sprites de logo e frase de início piscante.
- Três ataques usam os últimos quatro quadros originais, 05.webp–08.webp.
- NPCs possuem fundo transparente, hit-stun (0,78 s), planos verticais e quatro HP (exceto Tesourinha).
- Cada bônus concede +1 HP e mantém a superpontuação.
- Tariflávio usa 11 sprites novos para movimento, dano e destruição, com entrada gradual pela direita e fundo de mapa em segundo plano.
- 13 bônus, sistemas de combo, duplo pulo e especial de 13 hits preservados.

## Instalação no GitHub Pages
O `site.zip` contém `index.html` na raiz, mais `js/`, `css/` e `assets/`. Envie o arquivo para a raiz do repositório onde já usa `deploy-zip-pages.yml`, substituindo o antigo `site.zip`.

Projeto independente de ficção e sátira, sem vínculo oficial com governo, partido ou campanha.

## Backup recuperável
As especificações completas e os dois PNGs de arte originais estão em `docs/BACKUP_ESPECIFICACOES_ALPHA_092.md` e `docs/fontes_originais/`, dentro deste `site.zip`.

### Mudanças Alpha 0.9.4
- Poeira/terra animada em quatro quadros com transparência RGBA por baixo das esteiras de Tariflávio; o efeito acompanha a máquina nas mudanças de faixa e varia a opacidade durante o deslocamento.
- NPC atingido permanece atordoado por 0,78 segundo, sem atacar ou andar. A posição no mundo acompanha a velocidade da corrida, mantendo o NPC no alcance para um combo contínuo (um acerto por movimento).
- O especial, os 13 bônus, o pulo duplo, o comando de subir/descer e a transição nítida de Brasília permanecem. A trava antiga de 0,5 segundo após o terceiro golpe foi substituída pelo sistema experimental de fôlego, descrito abaixo.
- Backup atual: `docs/BACKUP_ESPECIFICACOES_ALPHA_094.md`. Prancha original: `docs/fontes_originais/poeira_terra_original.png`.

## Especiais cinematográficos sequenciais (ajuste não versionado)
- A barra vertical aparece durante a luta contra Tariflávio; **3/3 cargas são necessárias por ativação**.
- Primeiro vem **Maromba's Comunist**, Hadouken de Livros de História do Jones Manoel (13 hits).
- Depois de usar Jones e encher novamente a barra, é liberada **Diva Guerreira — Bandeira da Diversidade**, executada por Érika Hilton (13 hits).
- Terminada a Diva, o ciclo retorna a Jones. O botão único muda de nome e ícone automaticamente.
- A história do especial anterior Maromba's Comunista permanece substituída; não foi restaurada.
- Teclas C / L (V como alias) ativam apenas o próximo especial da sequência. Não ocorre execução simultânea.
- Consulte `README_ESPECIAIS.md` e `docs/ESPECIAIS_SEQUENCIAIS_INTEGRACAO.md`.


## Ajuste experimental de combate (sem alterar o número da Alpha)
- O quarto golpe está liberado imediatamente após o terceiro; a sequência visual segue 1→2→3→1→2...
- O personagem começa com 100 de fôlego e consome 18 por golpe; após uma sequência rápida, uma recuperação de 0,25 s repõe o fôlego.
- Durante a recuperação há uma janela defensiva de 0,34 s, para não sofrer dano antes de retomar os ataques.
- Uma tecla pressionada continuamente não dispara golpes automáticos; o buffer aceita no máximo um comando antecipado.
- Sem ataques por 0,4 s, o fôlego começa a regenerar. A barra de fôlego aparece no botão GOLPE.
- Os NPCs atingidos ficam atordoados por 0,78 s (e não mais 0,64 s); após sair do atordoamento, há uma breve espera antes de contra-atacarem.
- Arquivos ajustados: `js/combat.js`, `js/game.js`, `index.html` e `css/style.css`.
- Especificação e testes: `docs/AJUSTE_COMBATE_FOLEGO_SEM_VERSIONAMENTO.md`.

### Correção da barra de especial (sem versionamento)
Maromba's Comunist só pode ser usado com **3/3 cargas**; são consumidas as três ao ativar. Com a regra atual, cada carga exige derrotar três NPCs invocados (nove para encher do zero). Veja `docs/AJUSTE_BARRA_ESPECIAL_SEM_VERSIONAMENTO.md`.


## Mecânicas experimentais ainda não versionadas
Especial Ana Eliza (Justiça Popular) e Janones (Mobilização Popular) integrados depois de Jones e Érika, com a mesma barra de 3 cargas. Ver `docs/INTEGRACAO_ANA_ELIZA_JANONES_V3.md`.
