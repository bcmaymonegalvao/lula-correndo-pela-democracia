# Lula – Correndo pela Democracia — Alpha 0.9.4

Runner HTML5 Canvas para navegador móvel e desktop, publicável no GitHub Pages.

## Controles
- PC: ESPAÇO pula, W/↑ sobe de plano, S/↓ desce de plano, Z ou X ataca, C/L usa especial contra o chefão, P pausa.
- Celular: botões SUBIR/DESCER, PULAR e GOLPE na parte inferior. Especial aparece somente com Tariflávio.

## Correções 0.9.2
- Tesourinha e Tariflávio reconstruídos dos sprites originais, sem perfurações de transparência nas áreas internas.
- Rua mais larga no Canvas: começa em G-100 e é desenhada com 240 pixels de altura, cobrindo os três planos de movimentação.
- Animação de abertura usa a mesma projeção da rua.
- Backup técnico completo em `docs/BACKUP_ESPECIFICACOES_ALPHA_092.md`.

## Funcionalidades mantidas da 0.9.1
- Abertura animada com Lula correndo por Brasília, coletáveis em movimento e sprites de logo e frase de início piscante.
- Três ataques usam os últimos quatro quadros originais, 05.webp–08.webp.
- NPCs possuem fundo transparente, hit-stun (0,64 s), planos verticais e quatro HP (exceto Tesourinha).
- Cada bônus concede +1 HP e mantém a superpontuação.
- Tariflávio usa 11 sprites novos para movimento, dano e destruição, com entrada gradual pela direita e fundo de mapa em segundo plano.
- 13 bônus, sistemas de combo, duplo pulo e especial de 13 hits preservados.

## Instalação no GitHub Pages
O `site.zip` contém `index.html` na raiz, mais `js/`, `css/` e `assets/`. Envie o arquivo para a raiz do repositório onde já usa `deploy-zip-pages.yml`, substituindo o antigo `site.zip`.

Projeto independente de ficção e sátira, sem vínculo oficial com governo, partido ou campanha.

## Backup recuperável
As especificações completas e os dois PNGs de arte originais estão em `docs/BACKUP_ESPECIFICACOES_ALPHA_092.md` e `docs/fontes_originais/`, dentro deste `site.zip`.

### Mudanças Alpha 0.9.4
- Poeira/terra animada em quatro quadros com transparência RGBA por baixo das esteiras de Tariflávio; o efeito acompanha a máquina nas mudanças de faixa e varia a opacidade durante o deslocamento.
- NPC atingido permanece atordoado por 0,64 segundo, sem atacar ou andar. A posição no mundo acompanha a velocidade da corrida, mantendo o NPC no alcance para até três golpes (um acerto por movimento).
- O especial, os 13 bônus, o pulo duplo, o comando de subir/descer, a transição nítida de Brasília e o cooldown de 0,5 segundo após o terceiro golpe permanecem.
- Backup atual: `docs/BACKUP_ESPECIFICACOES_ALPHA_094.md`. Prancha original: `docs/fontes_originais/poeira_terra_original.png`.

## Especial único atual
- **Maromba's Comunist** substitui integralmente o antigo Maromba's Comunista.
- Jones Manoel dispara o Hadouken de Livros de História (13 hits), usando o botão 📚 e as teclas C/L (V é alias de compatibilidade).
- Uma barra vertical aparece apenas na batalha de Tariflávio; uma carga por uso.
