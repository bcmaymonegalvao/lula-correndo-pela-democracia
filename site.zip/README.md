# Lula – Correndo pela Democracia — Alpha 0.9.5 / NPC RGBA V5

Artefato `site.zip` compativel com o workflow existente `.github/workflows/cloudflare-pages-qa.yml`.

- A raiz do ZIP possui `index.html`, `assets/`, `js/`, `css/`, `tests/` e `_headers`.
- QA: Actions > Cloudflare Pages - QA > Run workflow > **validar**.
- Publicacao em Cloudflare Pages e separada: selecione **publicar-qa**, mediante autorizacao; usa `cloudflare-qa` e os segredos configurados no GitHub. Nao inclui tokens ou secrets.
- O workflow extrai, valida, executa os 3 testes e remove os arquivos internos antes do upload a `lula-correndo-democracia-qa`.
- Colocar `site.zip` em `main` pode disparar automaticamente o workflow *GitHub Pages* legado. O workflow Cloudflare QA nao publica em commits/pushes; apenas por `workflow_dispatch`.

Alteracoes: 28 PNGs NPC RGBA V5; offsets individuais dos pes; refinamento das bordas; cache-busting aplicado ao HTML, `GAME_ASSETS` e modulo de NPC; adicionada suite de testes obrigatorios.

Esta entrega nao realizou commit nem deploy.
