# Lula - Correndo pela Democracia · Alpha 0.4

**Runner 2D (180 segundos) para navegador e celular, hospedável no GitHub Pages.** Projeto independente e satírico, não oficial.

## O que mudou na Alpha 0.4

- **Corrida:** 16 quadros (antes 8), agora seguindo ciclo com dois tempos de passada reorganizados e quadros intermediários.
- **Pulo:** 12 quadros (antes 6), sem mudar a física de pulo duplo.
- **Três golpes visivelmente diferentes por arma:** varredura lateral, ataque vertical e finalização dupla. Há **12 quadros em cada golpe** para foice+martelo e bandeira. Ao pressionar três vezes, os três movimentos são executados na ordem; um toque só executa um golpe, sem auto-combo. Toques rápidos entram na fila de até dois golpes.
- **Organização do projeto:** arquivos de código em `js/`, CSS em `css/`, imagens em `assets/`, controle de quadros em `js/animations/`.
- **Otimização:** 100 arquivos WebP individuais de 384×384, com âncora comum, em vez de dezenas de imagens 768×768 (redução no uso de memória gráfica).
- **Prévia das animações:** `animacoes.html` permite reproduzir cada movimento e examinar os frames.

## Estrutura do projeto

```text
index.html                 # Interface principal do jogo
animacoes.html             # Console de testes para os sprites
css/style.css              # Controles e layout mobile
js/game.js                 # Motor: estados, física, colisões, HUD e tela
js/combat.js               # Combos: filas, janelas de ataque, hitboxes
js/animations/draw.js      # Âncora e enquadramento dos quadros
js/animations/timeline.js  # Cadência da corrida e seleção de quadros
js/assets.js               # Manifesto / caminhos dos recursos
js/fases.js                # Regiões e capitais do mapa
js/memorias.js             # Conteúdo educativo experimental
assets/backgrounds/*.webp  # Paisagens
assets/sprites/animacoes/  # 8 clipes, 100 sprites 384×384 WebP
tests/*.cjs                # Testes Node sem dependências externas
```

## Testar localmente

```bash
python3 -m http.server 8000
```

Abra `http://localhost:8000/`. Para inspecionar poses: `http://localhost:8000/animacoes.html`.

Execute os testes de lógica e recursos:

```bash
node tests/combat.test.cjs
node tests/runtime.test.cjs
```

> Testes em Node verificam sintaxe, manifesto de imagens, combo, comandos, carregamento simulado e regras. Ainda é necessária uma rodada de testes em navegador real e num aparelho Android.

## Publicar no GitHub Pages

Seu repositório `bcmaymonegalvao/lula-correndo-pela-democracia` atualmente hospeda apenas um `index.html` autônomo da Alpha 0.3. Para migrar à estrutura **modular**, faça upload do conteúdo do **ZIP Pages** (não o ZIP em si) diretamente na raiz do repositório, **substituindo `index.html`** e adicionando `js/`, `css/`, `assets/` e `animacoes.html`. O GitHub Pages voltará a publicar quando o commit na branch `main` for concluído. Mantenha os caminhos relativos inalterados.

## Sobre as memórias

Os dados das propostas são conteúdo educacional experimental e precisam ser conferidos em fontes oficiais antes de distribuição pública ampla. O jogo não representa governo, campanha ou partido político.
