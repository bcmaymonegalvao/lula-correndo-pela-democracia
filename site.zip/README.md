# Lula – Correndo pela Democracia — Alpha 0.9.2

Runner HTML5 Canvas para navegador móvel e desktop, publicável no GitHub Pages.

## Controles
- PC: ESPAÇO pula, W/↑ sobe de plano, S/↓ desce de plano, Z ou X ataca, C/L usa especial contra o chefão, P pausa.
- Celular: botões SUBIR/DESCER, PULAR e GOLPE na parte inferior. Especial aparece somente com Tariflávio.

## Correções 0.9.2
- Tesourinha e Tariflávio reconstruídos dos sprites originais, sem perfurações de transparência nas áreas internas.
- Rua mais larga no Canvas: começa em G-100 e é desenhada com 240 pixels de altura, cobrindo os três planos de movimentação.
- Animação de abertura usa a mesma projeção da rua.
- Backup técnico completo em `docs/BACKUP_ESPECIFICACOES_ALPHA_092.md`.

## Funcionalidades mantidas da 0.9.1
- Abertura animada com Lula correndo por Brasília, coletáveis em movimento e sprites de logo e frase de início piscante.
- Três ataques usam os últimos quatro quadros originais, 05.webp–08.webp.
- NPCs possuem fundo transparente, recuo mais forte a cada acerto, planos verticais e quatro HP (exceto Tesourinha).
- Cada bônus concede +1 HP e mantém a superpontuação.
- Tariflávio usa 11 sprites novos para movimento, dano e destruição, com entrada gradual pela direita e fundo de mapa em segundo plano.
- 13 bônus, sistemas de combo, duplo pulo e especial de 13 hits preservados.

## Instalação no GitHub Pages
O `site.zip` contém `index.html` na raiz, mais `js/`, `css/` e `assets/`. Envie o arquivo para a raiz do repositório onde já usa `deploy-zip-pages.yml`, substituindo o antigo `site.zip`.

Projeto independente de ficção e sátira, sem vínculo oficial com governo, partido ou campanha.

## Backup recuperável
As especificações completas e os dois PNGs de arte originais estão em `docs/BACKUP_ESPECIFICACOES_ALPHA_092.md` e `docs/fontes_originais/`, dentro deste `site.zip`.
