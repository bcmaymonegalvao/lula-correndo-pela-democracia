# Lula – Correndo pela Democracia — Alpha 0.9.5 · Patch QA4

**Assinatura publica:** Bruno Galvão · © 2026 — Todos os direitos reservados.

**Autor identificado civilmente nos avisos legais:** Bruno César Maymone Galvão.

**Contato:** GitHub @bcmaymonegalvao (nenhum e-mail de divulgação foi informado).

**Licenca:** software proprietario/freeware para jogar, sem autorizacao geral de redistribuicao ou modificacoes; ver `LICENSE`, `AUTHORS` e `COPYRIGHT`.

**Patch:** Alpha 0.9.5 · Patch QA4 (menu Sobre / Créditos, identidade publica e avisos de licenca).

A identificação de autoria não altera os direitos de terceiros sobre recursos eventualmente utilizados.

Artefato `site.zip` compativel com o workflow existente `.github/workflows/cloudflare-pages-qa.yml`.

- A raiz do ZIP possui `index.html`, `assets/`, `js/`, `css/`, `tests/` e `_headers`.
- QA: Actions > Cloudflare Pages - QA > Run workflow > **validar**.
- Publicacao em Cloudflare Pages e separada: selecione **publicar-qa**, mediante autorizacao; usa `cloudflare-qa` e os segredos configurados no GitHub. Nao inclui tokens ou secrets.
- O workflow extrai, valida, executa os 3 testes e remove os arquivos internos antes do upload a `lula-correndo-democracia-qa`.
- Colocar `site.zip` em `main` pode disparar automaticamente o workflow *GitHub Pages* legado. O workflow Cloudflare QA nao publica em commits/pushes; apenas por `workflow_dispatch`.

Histórico: NPCs V5, Estrela do Povo KOF e revisão QA2 de especiais preservados. Este patch acrescenta a tela Sobre/Créditos e padroniza autoria publica, versao e copyright na abertura, pausa, HUD e relatório final (incluindo PNG).

Esta entrega nao realizou commit nem deploy.
