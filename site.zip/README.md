# Lula – Correndo pela Democracia · Alpha 0.8.9

Runner 2D mobile/desktop (HTML5 Canvas) com fase em Brasília, votos e 13 bônus colecionáveis.

## Oponentes

- **Tesourinha atual**, com 3 HP e sprites `enemy_walk`, `enemy_hit`, `enemy_die`.
- **7 NPCs**: Miliciano, Petróleo Privatizado, Desmatamento, Terras Raras, Fake News, Orçamento Secreto e Repressão.
- **Todos** surgem da direita e alternam: Tesourinha, NPC aleatório, Tesourinha, NPC aleatório. Um de cada vez.
- **Tariflávio** chega aos 10.000 pontos; ele invoca inimigos da mesma sequência pela direita. Após 3 derrotados, o jogador ganha uma carga do especial Maromba's Comunista (13 hits no chefão).

## Controles

- Celular: PULAR, GOLPE, ESPECIAL.
- PC: Espaço/W/↑ pula; Z/X/Enter/J/K ataca; C/L aciona especial; P/Esc pausa.

`index.html`: jogo. `animacoes.html`: testes dos sprites.

O jogo é uma obra independente de ficção e sátira e não é produto oficial de governo, partido ou campanha.

### Alterações da Alpha 0.8.9
- ESPECIAL aparece apenas na batalha final.
- NPCs mais lentos; golpes agora com apenas os quadros 05 a 08.
- Prévia dedicada: `teste_especial.html`, incorporada em `animacoes.html`.
