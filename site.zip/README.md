# Lula – Correndo pela Democracia · Alpha 0.8.3

Jogo runner 2D HTML5/Canvas, compatível com navegadores de computador e celular. Obra independente de ficção e sátira, sem vínculo oficial com qualquer governo, partido ou campanha.

## Novidade: sete encontros consecutivos

A fase começa com 14 segundos de corrida em Brasília, coleta de votos e bônus, pulo duplo e robôs-tesoura. Depois, começa uma sequência fixa de seis antagonistas ilustrados, seguidos pelo chefão final da máquina de escavação. **Somente um chefe pode estar presente por vez**; o próximo aparece após a derrota e a saída do anterior.

| Ordem | Chefe | Acertos para derrotar |
|---|---|---:|
| 1 | Guardião da Escala 6×1 | 20 |
| 2 | Conde da Aposentadoria | 20 |
| 3 | Colosso da Saúde e Educação | 20 |
| 4 | Barão da Privatização | 20 |
| 5 | Marionetista | 20 |
| 6 | Sentinela do Punitivismo | 20 |
| 7 | Tariflávio – Escavadeira | 40 |

- Cada ataque registrado retira 1 HP; o mesmo golpe não causa dano repetido ao mesmo inimigo. Os três golpes em sequência e o combate aéreo permanecem ativos.
- A barra de vida exibe pontos restantes durante cada luta. Cada chefe pisca ao receber dano e produz efeitos de contato. Ataques à distância aparecem como esferas de energia, evitáveis com pulo ou pulo duplo.
- Cada chefe vencido recupera até uma vida (máximo 3). Cada mini-chefe vencido concede 2.500 super pontos e o final concede 10.000.
- O jogo preserva os 13 bônus colecionáveis, os votos e o relatório final das quantidades por política. A derrota encerra a partida como antes. Vencer o sétimo chefe apresenta uma **tela de vitória**, junto ao mesmo resumo completo.
- Os quatro cenários de Brasília continuam alternando suavemente ao longo da fase, e o piso de rua em pixel art rola continuamente.

## Publicação via ZIP no GitHub Pages

O arquivo `site.zip` contém `index.html` diretamente na raiz do ZIP, com pastas `assets/`, `js/`, `css/` e página `animacoes.html`.

Substitua o `site.zip` anterior no repositório e acione o workflow de publicação por ZIP já configurado. Em seguida teste `/animacoes.html` no mesmo endereço do jogo, incluindo a nova seção dos chefes.

## Estrutura dos sprites

- `assets/bosses/<id>/01.webp` a `08.webp` — cada vilão intermediário, 224×224 RGBA, do material original fornecido.
- `assets/bosses/final/01.webp` a `04.webp` — chefão da escavadeira, 660×510 RGBA, extraído da imagem enviada.
- `assets/bosses/manifest_bosses.json` — ID, ordem e HP.
- `js/bosses.js` — definições e fábrica dos chefes.
- `js/game.js` — geração sequencial, IA básica de projéteis, colisões, vida, vitória e efeitos.

A fase continua funcional caso uma imagem opcional de chefe falhe, usando temporariamente um sprite de robô como substituto. Os sprites fundamentais do personagem permanecem obrigatórios no carregamento inicial.
