# Lula – Correndo pela Democracia — Alpha 0.9.5

Runner 2D HTML5/JavaScript para celular e computador. Versão preparada para testes pelo fluxo ZIP do GitHub Pages.

## Novidades

- Prólogo animado entre Janones, Jones Manoel, Erika Hilton, Ana Eliza e Lula no início da partida (pode avançar/pular).
- 7 grupos de NPCs de calçada com animações idle, decorativos.
- 2 novos NPCs rápidos no fundo da calçada (corredor fazendo joinha e caminhão).

A lógica principal do jogo e os 4 especiais pré-existentes permanecem no código.

**Publicação:** substitua o site.zip no repositório e execute seu workflow manualmente, se quiser atualizar GitHub Pages. Esta entrega não executou deploy.

**Documentação detalhada:** `docs/ESPECIFICACOES_ALPHA_095.md`.


### Arte dinâmica de fim de partida
A tela de resultados gera PNG de 1080×1350 com estatísticas reais. Para experimentar isoladamente, abra `teste_relatorio_dinamico.html` (valores de laboratório, não vinculados a uma partida). Consulte `docs/ESPECIFICACOES_RELATORIO_DINAMICO.md`.


## Epílogo experimental (Alpha 0.9.5)
Os novos fluxos de vitória e derrota geram relatório visual PNG de 1080 × 1350. Consulte `docs/ESPECIFICACOES_EPILOGO_DINAMICO.md` e `teste_epilogo.html`. Nenhum dado fictício é usado no jogo integrado.
