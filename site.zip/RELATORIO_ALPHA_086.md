# Alpha 0.8.6 — Simplificação da fase

## Alterações
- **Apenas os monstrinhos da tesoura** aparecem como inimigos comuns.
- Os seis vilões intermediários ficam **desativados**. Seus sprites são preservados no projeto completo para uso futuro.
- **Tariflávio** aparece uma única vez quando a pontuação total chega a **10.000 pontos**, e **somente depois de desaparecer o último monstrinho da pista**.
- O chefão mantém **40 HP** e, ao ser derrotado, a tela de vitória é exibida.
- Corrigida a transparência indesejada dos monstrinhos: a antiga remoção dos pixels pretos apagava partes do corpo, olhos e contornos. Os quadros foram refeitos a partir da fonte RGBA, preservando os pretos e a opacidade.
- O chefão utiliza quadro visual fixo, ancorado no chão; avança e recua somente no eixo horizontal, eliminando a sensação de salto causada pela alternância dos desenhos.
- Permanecem: corrida, pulo duplo, três golpes em um botão, impacto, votos, 13 bônus, ciclo de Brasília e teclado no PC.

## Testes
- `node --check` nos arquivos JavaScript do jogo.
- Teste da tela inicial e de início da partida no Chromium, com recursos servidos por interceptação local, sem falhas de JavaScript.
- Teste da regra: não surge antes de 10.000, espera monstrinho desaparecer, surge somente uma vez, tem 40 HP, aceita 40 acertos e aciona vitória.
- Checagem visual dos novos quadros do monstrinho.
- Verificação das versões 0.8.6 no HTML, CSS e JS.

## Publicação
Substitua `site.zip` no repositório GitHub Pages e acione o workflow configurado.
