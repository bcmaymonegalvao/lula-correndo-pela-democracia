# Atualizar o GitHub Pages para Alpha 0.4

Repositório existente: `bcmaymonegalvao/lula-correndo-pela-democracia`.

## Método web (sem terminal)

1. Extraia `Lula_Correndo_pela_Democracia_Alpha_04_GitHub_Pages.zip` no computador.
2. Entre no repositório do GitHub, branch `main`.
3. Clique em **Add file > Upload files** (ou acesse `https://github.com/bcmaymonegalvao/lula-correndo-pela-democracia/upload/main`).
4. Arraste os **arquivos e pastas extraídos** (não o ZIP, nem a pasta que contém tudo): `index.html`, `animacoes.html`, `css/`, `js/`, `assets/`, `tests/`, etc. Marque sobrescrever `index.html`.
5. Clique em **Commit changes**. Aguarde o GitHub Pages concluir a atualização.
6. Abra `https://bcmaymonegalvao.github.io/lula-correndo-pela-democracia/` e o console `.../animacoes.html`.

O repositório antigo continha somente um `index.html` autônomo. Na Alpha 0.4, esse arquivo sozinho não funciona: precisa carregar os arquivos dos diretórios `assets/`, `css/` e `js/`. Preserve os caminhos e os nomes.

## Alternativa pelo Git em computador

Se tiver Git configurado com permissão de push:

```bash
git clone https://github.com/bcmaymonegalvao/lula-correndo-pela-democracia.git
cd lula-correndo-pela-democracia
# Copie para esta pasta todo o conteúdo extraído do ZIP Pages.
git add -A
git commit -m "Alpha 0.4: 100 sprites, alternancia de corrida e tres golpes por combo"
git push origin main
```

Não remova `Settings > Pages > Deploy from a branch > main / (root)`.

## Verificações pós-upload

- O botão "JOGAR AGORA" desbloqueia depois que 106 imagens terminam de carregar (100 sprites + 6 cenários).
- O console de animações mostra corrida (16), salto (12), foice+martelo (3×12), bandeira (3×12).
- Ao pressionar o botão de ataque uma, duas e três vezes, observe três movimentos distintos.
- Se ainda visualizar a Alpha 0.3, atualize forçadamente a página (Ctrl+Shift+R) ou abra em aba privativa.
