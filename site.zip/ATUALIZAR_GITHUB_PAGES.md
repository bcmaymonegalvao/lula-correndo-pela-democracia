# Atualizar GitHub Pages — Alpha 0.8.9

1. Envie o novo `site.zip` à raiz do repositório do jogo, substituindo o antigo.
2. Execute o workflow GitHub Actions já configurado para extrair e publicar o ZIP.
3. Espere a execução terminar com sucesso.
4. Acesse o jogo e `animacoes.html` para testar no celular e no computador. Atualize sem cache se ainda aparecer a versão anterior.

**Atenção:** o arquivo `index.html` fica na raiz do `site.zip`.
