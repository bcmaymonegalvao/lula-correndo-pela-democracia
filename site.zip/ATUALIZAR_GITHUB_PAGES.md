Versão atual: Alpha 0.8.6. Substitua o site.zip no repositório e acione o workflow de deploy.

Versão atual: Alpha 0.8.6. Substitua o site.zip no repositório e acione o workflow de deploy.

Versão atual: Alpha 0.8.5

# Atualizar GitHub Pages com Alpha 0.8.5

1. Baixe `site.zip` desta conversa.
2. Acesse o repositório do jogo pelo GitHub (celular ou desktop).
3. Substitua o arquivo **site.zip** na mesma localização utilizada pelo workflow de publicação ZIP anterior.
4. Faça o commit e aguarde a conclusão do GitHub Actions.
5. Recarregue a página do jogo e teste `SEU_ENDERECO/animacoes.html`.

Os caminhos de arquivos do site são relativos ao `index.html`, permitindo publicação em repositórios do tipo `usuario.github.io/projeto/`.

## Se o GitHub Pages continuar mostrando a versão anterior

1. Confira se o `site.zip` novo foi enviado para o mesmo caminho esperado pelo workflow e se houve commit.
2. Veja se a Action de deploy terminou com sucesso.
3. Recarregue o site sem cache ou teste em aba anônima.
4. Confirme o selo **ALPHA 0.8.5** na página inicial.
