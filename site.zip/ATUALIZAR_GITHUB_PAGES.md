Versão atual: Alpha 0.8.4

# Atualizar GitHub Pages com Alpha 0.8.3

1. Baixe `site.zip` desta conversa.
2. Acesse o repositório do jogo pelo GitHub (celular ou desktop).
3. Substitua o arquivo **site.zip** na mesma localização utilizada pelo workflow de publicação ZIP anterior.
4. Faça o commit e aguarde a conclusão do GitHub Actions.
5. Recarregue a página do jogo e teste `SEU_ENDERECO/animacoes.html`.

Os caminhos de arquivos do site são relativos ao `index.html`, permitindo publicação em repositórios do tipo `usuario.github.io/projeto/`.
