# Alpha 0.9.1 — Atualização do jogo

## Modificações
1. Ataques preservam exclusivamente os arquivos de sprite 05 a 08 (4 quadros por golpe).
2. Tela inicial substituída por animação em Canvas sobre Brasília, com personagem correndo, itens coletáveis, logo flutuando e frase de início piscante (sprites `assets/intro/logo.png` e `press_start.png`).
3. Jogabilidade em três faixas verticais contínuas no estilo beat 'em up, com W/↑ e S/↓ ou botões touch.
4. NPCs sem backing preto; empurrão para trás por golpe; quatro HP nos NPCs especiais, três na Tesourinha.
5. Cada bônus recupera exatamente +1 HP.
6. Tariflávio animado com 4 quadros de movimento, 3 de dano e 4 de destruição, na meia altura e entrando gradualmente da direita.
7. Barra do especial permanece exclusiva da batalha final.

## Verificação
Sintaxe JS, existência de assets e testes em Chromium com todos os gráficos carregados localmente por URLs de dados. Foi testado: início, coleta +1 HP, controle vertical, aparição progressiva de chefe, barra condicionada e quatro quadros para cada ataque. Publicação efetiva no GitHub Pages ainda depende do upload do arquivo.
