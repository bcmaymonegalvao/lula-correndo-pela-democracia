# Correções de sprites

- Preenchidos pequenos furos indevidos de transparência nos NPCs decorativos e corredores da calçada.
- Espelhados os frames do caminhão para que o veículo fique voltado para a direita durante o deslocamento da esquerda para a direita.
