# Alpha 0.8.7 — Tariflávio com invocação de NPCs e especial global

## Implementações realizadas

1. **Batalha final refeita**
   - Tariflávio foi mantido como único chefão.
   - Agora ele fica fixo no lado direito da tela durante o confronto.
   - O ataque direto do chefão foi substituído por uma mecânica de invocação contínua de NPCs.

2. **NPCs da arte de referência implementados**
   Foram adicionados, com exceção do gado eleitoral:
   - Miliciano
   - Petróleo Privatizado
   - Desmatamento
   - Terras Raras
   - Fake News
   - Orçamento Secreto
   - Repressão

3. **Fluxo da luta do chefão**
   - Tariflávio invoca 1 NPC por vez.
   - Quando o NPC atual é derrotado, outro aleatório é enviado.
   - Cada NPC invocado possui 20 HP, telegraph de ataque e movimentação apenas no eixo horizontal.

4. **Especial global**
   - Novo botão **ESPECIAL** para mobile.
   - Novo atalho no PC: **C** ou **L**.
   - A cada 3 NPCs derrotados, 1 carga de especial é adicionada.
   - O especial chama o **Maromba's Comunista**, que cruza a tela e aplica **13 hits** no Tariflávio.
   - Foi criada uma sobreposição cinematográfica inspirada em golpes especiais de *Marvel vs Capcom*.

5. **HUD / UX**
   - Barra de especial adicionada abaixo da barra de vida do chefão.
   - Mensagem dinâmica informando quantos NPCs faltam para carregar o próximo especial.
   - Botão de especial ganha destaque visual quando está pronto para uso.

## Arquivos principais alterados

- `index.html`
- `css/style.css`
- `js/assets.js`
- `js/bosses.js`
- `js/game.js`
- `assets/sprites/boss_minions/*`

## Observações

- Os novos NPCs foram recortados a partir da arte de referência enviada e convertidos em sprites utilizáveis no jogo.
- O jogo continua com a progressão de Brasília, votos, bônus e boss battle aos 10.000 pontos.
