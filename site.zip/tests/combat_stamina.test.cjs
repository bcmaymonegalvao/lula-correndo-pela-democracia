const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const context={window:{}};
vm.runInNewContext(fs.readFileSync(path.join(__dirname,'..','js','combat.js'),'utf8'),context);
const C=context.window.GameCombat;
const c=C.create();
assert.equal(C.MOVES.length,3);
assert.equal(c.state.stamina,100);
let sequence=[];let serials=0, comboCalls=0;
// buffer one attack at a time with a rhythmic button press
assert.equal(c.press('combo'),true);
for(let elapsed=0;elapsed<5.5;elapsed+=.01){
  c.update(.01);
  if (c.state.step && c.state.queue===0 && c.state.left<.1) c.press('combo');
  if(c.state.serial!==serials){sequence.push(c.state.step);serials=c.state.serial;}
  if(c.state.cooldown>0) break;
}
assert.deepEqual(sequence.slice(0,5),[1,2,3,1,2]);
assert.equal(c.state.cooldown>0,true,'fatigue should interrupt held tapping');
assert.equal(c.isRecoveryProtected(),true,'guard protects player during recovery');
assert.equal(c.state.step,0);
for(let i=0;i<40;i++) c.update(.01);
assert.equal(c.state.cooldown,0);
assert.equal(c.isRecoveryProtected(),false);
assert.equal(c.state.stamina>=C.STAMINA_REFILL,true);
assert.equal(c.press('combo'),true,'can resume combo after short recovery');
assert.equal(c.state.step,1);
// Debounce + one attack buffer (cannot queue whole combo at once)
const b=C.create();assert.equal(b.press('combo'),true);assert.equal(b.press('combo'),false);
b.update(.12);assert.equal(b.press('combo'),true);b.update(.12);assert.equal(b.press('combo'),false);
// one new attack, each with distinct hitTargets collection
const serialStart=b.state.serial;b.update(.25);assert.equal(b.state.serial,serialStart+1);
assert.equal(b.state.step,2);assert.equal(b.state.hitTargets.size,0);
// reset original and verify 4th hit safe w/o cooldown
const n=C.create();let steps=[];
n.press('combo');
for(let i=0;i<4;i++){
 const previous=n.state.serial;
 n.update(.13);n.press('combo');
 while(n.state.serial===previous) n.update(.01);
 steps.push(n.state.step);
}
assert.deepEqual(steps,[2,3,1,2]);
assert.equal(n.state.cooldown,0,'fourth hit must not be blocked by recovery');
assert.equal(n.state.stamina,10);
console.log(JSON.stringify({status:'ok',sequence,firstRecoveryAtAttack:5,cooldown:C.COOLDOWN_SECONDS,guard:C.RECOVERY_GUARD,fourthHit:n.state.step,regen:C.STAMINA_REGEN},null,2));
