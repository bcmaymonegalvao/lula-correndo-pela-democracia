'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const root=path.resolve(__dirname,'..');
const window={};
vm.runInNewContext(fs.readFileSync(path.join(root,'js/combat.js'),'utf8'),{window},{filename:'js/combat.js'});
const combat=window.GameCombat;

test('Quatro ataques preservam a sequencia, buffer e caixas de colisao',()=>{
 const c=combat.create();
 assert.equal(c.press('combo'),true);
 assert.equal(c.state.step,1);
 assert.equal(c.state.stamina,combat.MAX_STAMINA-combat.ATTACK_COST);
 const box=c.hitbox(100,420);
 assert.equal(typeof box.x,'number');
 assert.ok(box.w>0);
 c.update(.11);
 assert.equal(c.press('combo'),true);
 c.update(.39);
 assert.equal(c.state.step,2,'ataque enfileirado vira segundo golpe');
 c.update(.50);
 assert.equal(c.state.step,0);
 assert.equal(c.press('combo'),true);
 assert.equal(c.state.step,3);
 assert.equal(c.move().clip,'flying_kick');
});

test('Folego diminui em ataques e regenera depois de uma pausa',()=>{
 const c=combat.create();
 assert.equal(c.press('outro'),false);
 assert.equal(c.press('combo'),true);
 const before=c.state.stamina;
 c.update(.41);
 c.update(.45);
 assert.ok(c.state.stamina>=before,'regenera durante descanso');
 assert.ok(c.state.stamina<=combat.MAX_STAMINA);
 c.reset();
 assert.equal(c.state.stamina,combat.MAX_STAMINA);
});

test('Combate nao depende de internet nem browser e define protecao na recuperacao',()=>{
 const c=combat.create();
 assert.equal(c.isRecoveryProtected(),false);
 assert.equal(c.begin(0),false);
 assert.equal(c.begin(5),false);
 assert.equal(c.move(),null);
 // Abaixo do custo minimo de golpe, ativar recuperacao controlada.
 c.state.stamina=1;
 assert.equal(c.press('combo'),false);
 assert.equal(c.isRecoveryProtected(),true);
 c.update(combat.COOLDOWN_SECONDS+.01);
 assert.ok(c.state.stamina>=combat.STAMINA_REFILL);
});
