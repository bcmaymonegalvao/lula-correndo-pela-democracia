'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const root=path.resolve(__dirname,'..');
const ctx={window:{}};
vm.runInNewContext(fs.readFileSync(path.join(root,'js/combat.js'),'utf8'),ctx);
vm.runInNewContext(fs.readFileSync(path.join(root,'js/mechanics/estrela_povo.js'),'utf8'),ctx);
vm.runInNewContext(fs.readFileSync(path.join(root,'js/assets.js'),'utf8'),ctx);
const {GameCombat,GameEstrelaPovo,GAME_ASSETS}=ctx.window;
test('selecao: soco1 soco2 chute esquerdo soco4 soco1, um input por ataque',()=>{
 const combat=GameCombat.create();let started=0;
 for(const move of [1,2,3,4,1]){
  assert.equal(combat.press('combo'),true);
  assert.equal(combat.state.step,move);
  assert.equal(combat.move().impact,`estrela_povo_${move}`);
  started++;
  assert.equal(combat.state.serial,started);
  const currentSerial=combat.state.serial;
  combat.update(combat.move().duration+.002);
  assert.equal(combat.state.step,0);
  assert.equal(combat.state.serial,currentSerial,'sem ataque automatico');
 }
 assert.equal(GameCombat.MOVES[2].clip,'flying_kick');
 assert.equal(GameCombat.MOVES[3].clip,'left_punch');
});
test('Hitbox conserva quatro etapas por golpe e oito quadros de corpo',()=>{
 const c=GameCombat.create();
 assert.equal(c.press('combo'),true);
 assert.ok(c.hitbox(100,423).x>=100);
 assert.equal(c.frame(),0);assert.equal(c.visualFrame(),0);
 c.update(.2);assert.ok(c.frame()<4);assert.ok(c.visualFrame()<8);
 assert.equal(GameCombat.MOVES.length,4);
 for(const clip of ['left_punch','front_punch','flying_kick']){
  assert.equal(GAME_ASSETS.sprites[clip].length,8);
 }
});
test('16 PNGs RGBA, 256x256, origens 100% transparentes',()=>{
 assert.equal(Object.keys(GAME_ASSETS.estrelaPovo).length,4);
 for (const [k,frames] of Object.entries(GAME_ASSETS.estrelaPovo)){
  assert.equal(frames.length,4,k);
  for(const file of frames){
   const b=fs.readFileSync(path.join(root,file));
   assert.equal(b.subarray(1,4).toString(),'PNG');
   assert.equal(b.readUInt32BE(16),256);
   assert.equal(b.readUInt32BE(20),256);
   assert.equal(b[25],6);
  }
 }
});
test('Estrela do Povo: quatro quadros discretos e sem RAF',()=>{
 for(let step=1;step<=4;step++){
  const e=GameEstrelaPovo.spawn(step,210,312,3,'target');
  assert.equal(e.targetId,'target');
  for(let frame=0;frame<4;frame++){
   e.age=e.duration*(frame+.1)/4;
   assert.equal(GameEstrelaPovo.frameOf(e),frame);
  }
  e.age=e.duration;
  const fake={save(){},restore(){},drawImage(){throw Error('Nao deveria renderizar depois do ultimo frame')}};
  assert.equal(GameEstrelaPovo.draw(fake,[],e,210,312),false);
 }
 assert.ok(GameEstrelaPovo.SIZE.every(x=>x<=108));
});
test('hitTargets: deduplicacao por alvo e novo golpe limpa conjunto',()=>{
 const c=GameCombat.create();assert.ok(c.press('combo'));
 c.state.hitTargets.add(123);assert.equal(c.state.hitTargets.has(123),true);
 // o mesmo serial preserva o estado da colisao ate terminar o movimento
 c.update(.25);assert.equal(c.state.hitTargets.has(123),true);
 c.update(.25);assert.equal(c.state.step,0);
 assert.ok(c.press('combo'));assert.equal(c.state.hitTargets.has(123),false);
});
test('nao ha disparo automatico dos FX de contato no inicio do golpe',()=>{
 const game=fs.readFileSync(path.join(root,'js/game.js'),'utf8');
 assert.match(game,/GameEstrelaPovo\.spawn\(combat\.state\.step,hitX,hitY,combat\.state\.serial,e\.id\)/);
 assert.ok(game.includes('if(combat.state.hitTargets.has(e.id))return'));
 assert.doesNotMatch(game,/swingAtNewAttack\(\);/);
});
