/* node tests/scenery_npcs.test.js */
const assert = require('node:assert/strict');
const { runInNewContext } = require('node:vm');
const { readFileSync } = require('node:fs');
const code = readFileSync('js/mechanics/scenery_npcs.js','utf8');
class ImageMock {
  set src(path) { this._src = path; this.naturalWidth = 192; this.naturalHeight = 192; this.onload?.(); }
  get src(){return this._src;}
}
const scene = { window: {}, Image: ImageMock };
runInNewContext(code, scene);
const api=scene.window.GameSceneryNpcs;
assert.equal(api.ids.length, 7);
const paths=Object.fromEntries([...api.ids].map(id=>[id,[1,2,3,4].map(i=>`assets/${id}/idle_0${i}.webp`)]));
const errors=[];
const plugin=api.create({spritePaths:paths,onAssetError:(...x)=>errors.push(x)});
assert.equal(errors.length, 0);
const before=plugin.debugState();
assert.equal(before.entries.length,2);
assert([...api.ids].every(id=>before.loaded[id]===4));
const ctx={globalAlpha:1,imageSmoothingEnabled:true,draws:[],save(){},restore(){},drawImage(...args){this.draws.push(args)}};
plugin.render(ctx);
assert(ctx.draws.length>0);
for (let i=1;i<=12000;i++) plugin.update(1/120,i*214/120);
const late=plugin.debugState();
assert(late.entries.length<=8);
assert(Object.values(late.loaded).every(n=>n===4));
assert(late.entries.every(e=>api.ids.includes(e.id)));
plugin.reset(0);
assert.equal(plugin.debugState().entries.length, 2);
plugin.setEnabled(false);
const oldTime=plugin.debugState().animationTime;
plugin.update(1,50);
assert.equal(plugin.debugState().animationTime,oldTime);
plugin.setEnabled(true);
plugin.update(0.5,50);
assert.equal(plugin.debugState().animationTime,oldTime+0.5);
plugin.dispose();
assert.equal(plugin.debugState().entries.length, 0);
const missing=api.create({});
assert.equal(missing.debugState().loaded.eleitores_l,0);
missing.render(ctx); // failures of optional assets cannot throw
assert.equal(Object.keys(api.definitions).length, 7);
console.log('OK: catálogo(7), carregamento(28), render, scroll, reset, pause, descarte, fallback.');
