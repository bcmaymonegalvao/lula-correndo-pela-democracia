'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const root = path.resolve(__dirname, '..');

function browserContext() {
  class FakeImage {
    constructor() { this.naturalWidth = 192; this.naturalHeight = 192; this.width = 192; this.height = 192; }
    set src(url) { this.url = url; if (typeof this.onload === 'function') this.onload(); }
  }
  const window = {};
  const document = { baseURI: 'https://example.test/', createElement(type) {
    assert.equal(type, 'canvas');
    return {getContext() { return { drawImage() {}, getImageData() { return {data:[0,0,0,0]}; } }; }};
  }};
  const context = vm.createContext({window, Image:FakeImage, document, location:{search:''}, URL, URLSearchParams, console});
  for (const script of ['js/assets.js', 'js/mechanics/scenery_npcs.js']) {
    vm.runInContext(fs.readFileSync(path.join(root,script),'utf8'), context, {filename:script});
  }
  return window;
}
function fakeCanvas() {
  const calls=[];
  const ctx={globalAlpha:1,imageSmoothingEnabled:true, globalCompositeOperation:'multiply',
    save(){this._saved={alpha:this.globalAlpha,smoothing:this.imageSmoothingEnabled,operation:this.globalCompositeOperation};},
    restore(){this.globalAlpha=this._saved.alpha;this.imageSmoothingEnabled=this._saved.smoothing;this.globalCompositeOperation=this._saved.operation;},
    drawImage(...args){calls.push({args,smoothing:this.imageSmoothingEnabled,operation:this.globalCompositeOperation});}};
  return {ctx,calls};
}

test('V5: assets e 28 PNGs RGBA 192x192 estao presentes',()=>{
  const w=browserContext();
  assert.match(w.NPC_SPRITE_BUILD,/V5/);
  assert.equal(Object.keys(w.GAME_ASSETS.sceneryNpcs).length,7);
  for (const [id,frames] of Object.entries(w.GAME_ASSETS.sceneryNpcs)) {
    assert.equal(frames.length,4,id);
    for (const asset of frames){
      assert.match(asset,/^assets\/sprites\/npc_rgba_v5\//);
      const b=fs.readFileSync(path.join(root,asset));
      assert.equal(b.subarray(1,4).toString(),'PNG');
      assert.equal(b.readUInt32BE(16),192);
      assert.equal(b.readUInt32BE(20),192);
      assert.equal(b[25],6,'PNG colorType 6 (RGBA)');
    }
  }
});

test('NPCs carregam, preservam pixel art e usam o offset de cada grupo',()=>{
  const w=browserContext();
  const npcs=w.GameSceneryNpcs.create({spritePaths:w.GAME_ASSETS.sceneryNpcs});
  const state=npcs.debugState();
  assert.match(state.spriteBuild,/V5/);
  assert.equal(Object.values(state.loaded).reduce((a,b)=>a+b,0),28);
  const {ctx,calls}=fakeCanvas();
  npcs.render(ctx,{world:0,floorY:423,screenWidth:960,playerScreenX:190,sidewalkOffsetY:-78});
  assert.ok(calls.length>=2);
  assert.ok(calls.every(v=>!v.smoothing&&v.operation==='source-over'));
  // IDs in reset order: eleitores_l, trompetista. Pixel-position rounded precisely as in Canvas.
  const expectedY=(id)=>{const cfg=w.GameSceneryNpcs.definitions[id];return Math.round(423-78-176*cfg.scale+(cfg.feetShiftY||0)*cfg.scale);};
  assert.equal(calls[0].args[2],expectedY('eleitores_l'));
  assert.equal(calls[1].args[2],expectedY('trompetista'));
  assert.equal(ctx.imageSmoothingEnabled,true,'Canvas state restored');
  npcs.update(.5,100);
  assert.ok(npcs.debugState().animationTime>0);
  npcs.dispose();
  assert.equal(npcs.debugState().disposed,true);
});

test('carregamento incompleto de um frame e seguro para a execucao',()=>{
  const w=browserContext();
  const paths=Object.fromEntries(Object.entries(w.GAME_ASSETS.sceneryNpcs).map(([k,v])=>[k,[...v]]));
  paths.trompetista[0]='';
  const issues=[];
  const npcs=w.GameSceneryNpcs.create({spritePaths:paths,onAssetError:(...args)=>issues.push(args)});
  assert.ok(issues.some(e=>e[0]==='trompetista'));
  const {ctx,calls}=fakeCanvas();
  assert.doesNotThrow(()=>npcs.render(ctx));
  assert.ok(calls.length);
});
