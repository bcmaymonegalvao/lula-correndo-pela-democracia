const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root=path.join(__dirname,'..');

test('identidade publica, copyright e patch centralizados em build_info',()=>{
 const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
 const original=fs.readFileSync(path.join(root,'js/build_info.js'),'utf8');
 const attrs=[...html.matchAll(/data-game-build="(credits|version|copyright)"/g)].map(m=>m[1]);
 assert.equal(attrs.filter(x=>x==='credits').length,3);
 assert.equal(attrs.filter(x=>x==='version').length,4);
 assert.equal(attrs.filter(x=>x==='copyright').length,3);
 const credits={textContent:'',getAttribute:()=> 'credits'};
 const version={textContent:'',getAttribute:()=> 'version'};
 const copyright={textContent:'',getAttribute:()=> 'copyright'};
 let ready;
 const window={};
 const document={readyState:'loading',addEventListener:(ev,cb)=>{assert.equal(ev,'DOMContentLoaded');ready=cb;},querySelectorAll:()=>[credits,version,copyright]};
 vm.runInNewContext(original,{window,document});
 assert.equal(window.GameBuildInfo.version,'Alpha 0.9.5');
 assert.equal(window.GameBuildInfo.patch,'QA4');
 assert.equal(window.GameBuildInfo.author,'Bruno Galvão');
 assert.equal(window.GameBuildInfo.github,'@bcmaymonegalvao');
 ready();
 assert.match(credits.textContent,/Bruno Galvão/);
 assert.equal(version.textContent,'Alpha 0.9.5 · Patch QA4');
 assert.match(copyright.textContent,/© 2026 Bruno Galvão/);
});

test('relatorio final e PNG com assinatura publica sem alterar estatisticas',()=>{
 const src=fs.readFileSync(path.join(root,'js/reports/mission_report.js'),'utf8');
 assert.match(src,/const owner=build\?\.author/);
 assert.match(src,/const release=build\?\.label/);
 assert.match(src,/Desenvolvido por \$\{owner\} · © 2026/);
 assert.match(src,/data-game-build="version"/);
});
