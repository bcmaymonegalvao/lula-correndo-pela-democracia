const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const ROOT=path.join(__dirname,'..');
function read(name){return fs.readFileSync(path.join(ROOT,name),'utf8');}
test('tela de abertura e pausa possuem acesso ao menu Sobre / Créditos',()=>{
 const html=read('index.html');
 for(const id of ['aboutFromStart','aboutFromPause','aboutOverlay','aboutClose','aboutDismiss']){
  assert.ok(html.includes(`id="${id}"`),`faltando ${id}`);
 }
 assert.match(html, /role="dialog" aria-modal="true"/);
 assert.match(html, /js\/about\.js\?rev=qa4/);
 assert.match(html, /GitHub: <span data-game-build="github">@bcmaymonegalvao<\/span>/);
 assert.match(html, /Sobre \/ Créditos/);
});
test('licenca de uso gratuito mantem direitos autorais originais e ressalva terceiros',()=>{
 const lic=read('LICENSE'),authors=read('AUTHORS'),copyright=read('COPYRIGHT');
 assert.match(lic,/gratuita para jogar|jogar a versao/i);
 assert.match(lic,/TERCEIROS/);
 assert.match(lic,/redistribuicao|republicar|distribuir/i);
 assert.match(authors,/Bruno César Maymone Galvão/);
 assert.match(authors,/Bruno Galvão/);
 assert.match(copyright,/2026 Bruno César Maymone Galvão/);
});
test('nenhum email de contato ficticio foi publicado',()=>{
 const html=read('index.html');
 assert.doesNotMatch(html,/mailto:/i);
});
