const assert=require('node:assert/strict');const vm=require('node:vm');const fs=require('node:fs');const path=require('node:path');
const root=path.join(__dirname,'..');
const nodes=new Map();
function node(id){
 if(nodes.has(id))return nodes.get(id);
 const set=new Set(id==='game'?['hidden']:[]);
 const n={id,style:{},classList:{contains:c=>set.has(c),add:c=>set.add(c),remove:c=>set.delete(c),toggle:(c,v)=>v?set.add(c):set.delete(c)},
  textContent:'',innerHTML:'',disabled:false,children:[],addEventListener(){},replaceChildren(){this.children=[]},appendChild(c){this.children.push(c)},getBoundingClientRect(){return {width:960,height:540}}};
 nodes.set(id,n);return n;
}
const grad={addColorStop(){}};
const ctx=new Proxy({canvas:{}},{get(t,p){if(p==='createLinearGradient'||p==='createRadialGradient')return ()=>grad;if(p==='measureText')return ()=>({width:0});if(p==='globalAlpha')return t[p]??1;if(p==='imageSmoothingEnabled')return false;return t[p]??(()=>{});},set(t,p,v){t[p]=v;return true;}});
const canvas={width:960,height:540,getContext(){return ctx}};nodes.set('canvas',canvas);
const pending=[];
function Image(){const im={onload:null,onerror:null,width:384,height:384};Object.defineProperty(im,'src',{set(v){pending.push(v);if(!fs.existsSync(path.join(root,v)))setImmediate(()=>im.onerror?.());else setImmediate(()=>im.onload?.());}});return im;}
const env={console,Image,URLSearchParams,location:{search:'?test'},document:{getElementById:node,createElement:()=>node('elem-'+Math.random()),addEventListener(){},hidden:false},requestAnimationFrame:()=>1,cancelAnimationFrame(){},devicePixelRatio:1,addEventListener(){}};env.window=env;
vm.createContext(env);
for(const f of ['js/assets.js','js/fases.js','js/memorias.js','js/animations/draw.js','js/animations/timeline.js','js/combat.js','js/game.js'])vm.runInContext(fs.readFileSync(path.join(root,f),'utf8'),env,{filename:f});
(async()=>{
 for(let i=0;i<30;i++)await new Promise(r=>setImmediate(r));
 const g=env.__game;assert.ok(g);
 assert.equal(pending.length,106);
 assert.equal(node('startBtn').disabled,false);
 function clear(){g.start();g.state.obj=[];g.state.pickup=[];}
 function steps(sec){for(let i=0;i<Math.round(sec*120);i++)g.update(1/120)}
 clear();assert.equal(node('clock').textContent,'03:00');assert.equal(g.state.lives,3);
 g.action('jump');steps(.12);assert(g.state.playerY<420);steps(1.2);assert(g.state.onGround);
 clear();g.action('hammer');g.action('hammer');g.action('hammer');assert.equal(g.combat.state.queue,2);
 steps(.43);assert.equal(g.combat.state.step,2);
 steps(.49);assert.equal(g.combat.state.step,3);
 steps(.62);assert.equal(g.state.attack,'');
 clear();g.state.obj=[{type:'crate',x:118,w:44,h:46,done:false}];g.action('hammer');steps(.25);assert.equal(g.state.obj[0].done,true);
 clear();g.state.score=1000;g.checkFlag();assert.equal(g.state.flagUnlocked,true);g.action('flag');assert.equal(g.combat.state.weapon,'flag');
 clear();g.pause();const t=g.state.elapsed;steps(2);assert.equal(g.state.elapsed,t);g.pause();steps(.3);assert(g.state.elapsed>t);
 console.log('OK: runtime mock browser, 106 assets resolved, jump, combo, collision, flag, pause.');
})().catch(e=>{console.error(e);process.exit(1)});
