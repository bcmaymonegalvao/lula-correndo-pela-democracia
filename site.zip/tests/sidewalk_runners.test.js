'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const root=path.resolve(__dirname,'..');
function setup() {
 class FakeImage {
   constructor(){this.naturalWidth=384;this.naturalHeight=512;this.width=384;this.height=512;}
   set src(value){this.url=value;this.onload?.();}
 }
 const window={};
 const context=vm.createContext({window,Image:FakeImage,location:{search:''}});
 for(const name of ['js/assets.js','js/mechanics/sidewalk_runners.js'])
   vm.runInContext(fs.readFileSync(path.join(root,name),'utf8'),context,{filename:name});
 const runner=window.GameSidewalkRunners.create({spritePaths:window.GAME_ASSETS.sidewalkRunners});
 return {runner,window};
}

test('Carrega os quadros dos dois NPCs corredores',()=>{
 const {runner}=setup();
 const state=runner.debugState();
 assert.equal(state.loaded.corredor_joinha,8);
 assert.equal(state.loaded.caminhao,4);
});

test('Movimento progride e colisao com chefe apenas remove NPCs decorativos',()=>{
 const {runner}=setup();
 assert.equal(runner.spawn('corredor_joinha'),true);
 const old=runner.debugState().participants[0].x;
 runner.update(.05,{screenWidth:960});
 assert.ok(runner.debugState().participants[0].x>old);
 const calls=[];
 const ctx={imageSmoothingEnabled:true,globalAlpha:1,save(){},restore(){},drawImage(...args){calls.push(args);}};
 runner.render(ctx,{screenWidth:960});
 // starts just off-screen so no drawing is expected yet; after moving the object appears.
 runner.update(.05,{screenWidth:960});
 runner.render(ctx,{screenWidth:960});
 assert.ok(calls.length>=1);
 runner.update(.01,{bossActive:true});
 assert.equal(runner.debugState().participants.length,0);
 assert.equal(runner.spawn('tipo_inexistente'),false);
 runner.dispose();
 assert.equal(runner.debugState().disposed,true);
});

test('Desabilitar renderizacao apenas limpa corredores decorativos',()=>{
 const {runner}=setup();
 runner.spawn('caminhao');
 runner.setEnabled(false);
 assert.equal(runner.debugState().participants.length,0);
 assert.equal(runner.spawn('caminhao'),false);
 runner.setEnabled(true);
 assert.equal(runner.spawn('caminhao'),true);
});
