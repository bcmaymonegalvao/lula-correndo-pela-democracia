const assert=require('node:assert/strict');
const fs=require('node:fs');const path=require('node:path');const vm=require('node:vm');
const root=path.join(__dirname,'..'); const sandbox={window:{}}; vm.createContext(sandbox);
for(const file of ['js/assets.js','js/animations/draw.js','js/animations/timeline.js','js/combat.js']){
 vm.runInContext(fs.readFileSync(path.join(root,file),'utf8'),sandbox,{filename:file});
}
const assets=sandbox.window.GAME_ASSETS;
const combo=sandbox.window.GameCombat;
const anim=sandbox.window.GameAnimation;
const ok=(v,msg)=>assert.ok(v,msg);
let tests=0;function test(label,fn){fn();tests++;console.log('OK',label);}
function time(c,n){for(let i=0;i<Math.round(n*120);i++)c.update(1/120);}
test('8 clipes com total de 100 imagens físicas',()=>{
 assert.equal(Object.keys(assets.sprites).length,8);
 assert.deepEqual(JSON.parse(JSON.stringify(Object.values(assets.sprites).map(v=>v.length))),[16,12,12,12,12,12,12,12]);
 for(const arr of Object.values(assets.sprites))for(const relative of arr)ok(fs.existsSync(path.join(root,relative)),relative);
});
test('ciclo de 16 quadros percorre as duas passadas e fecha o loop',()=>{
 assert.equal(anim.frame({clipId:'run',elapsed:0}),0);
 ok([0,1,2,3,4,5,6,7].every(i=>anim.frame({clipId:'run',elapsed:i/19})===i));
 assert.equal(anim.frame({clipId:'run',elapsed:16/19}),0);
});
test('pulo tem doze quadros incluindo aterrissagem',()=>{
 assert.equal(anim.frame({clipId:'jump',landing:.1}),11);
 assert.equal(anim.frame({clipId:'jump',landing:0,jumpAge:.07,velocityY:-500}),2);
});
test('um toque não dispara golpes 2 e 3 automaticamente',()=>{
 const c=combo.create();ok(c.press('hammer',false));time(c,.5);assert.equal(c.state.weapon,'');assert.equal(c.state.nextStep,2);
});
test('três toques rápidos formam 3 ataques diferentes em sequência',()=>{
 const c=combo.create();ok(c.press('hammer',false));ok(c.press('hammer',false));ok(c.press('hammer',false));ok(!c.press('hammer',false));
 assert.equal(c.state.queue,2);assert.equal(c.state.step,1);
 time(c,.43);assert.equal(c.state.step,2);assert.equal(c.state.queue,1);
 time(c,.49);assert.equal(c.state.step,3);assert.equal(c.state.queue,0);
 time(c,.6);assert.equal(c.state.weapon,'');
 ok(c.press('hammer',false));assert.equal(c.state.step,1);
});
test('toques espaçados respeitam janela de combo e reiniciam depois de pausa',()=>{
 const c=combo.create();ok(c.press('hammer',false));time(c,.44);
 ok(c.press('hammer',false));assert.equal(c.state.step,2);time(c,.5);
 time(c,1);ok(c.press('hammer',false));assert.equal(c.state.step,1);
});
test('segundo e terceiro ataques usam clipes e hitboxes diferentes',()=>{
 const c=combo.create();const hits=[];
 c.press('hammer',false);
 for(let i=1;i<=3;i++){
  const m=combo.MOVES[i-1];
  c.state.weapon='hammer';c.state.step=i;c.state.left=m.duration-(m.active[0]+m.active[1])/2;
  const key=anim.clip({attack:'hammer',step:i});
  assert.equal(key,'hammer_'+i);assert.equal(assets.sprites[key].length,12);
  const hit=c.hitbox(100,420);ok(hit);hits.push(JSON.stringify(hit));
 }
 assert.equal(new Set(hits).size,3);
});
test('bandeira depende de desbloqueio e mantém três movimentos',()=>{
 const c=combo.create();assert.equal(c.press('flag',false),false);
 ok(c.press('flag',true));ok(c.press('flag',true));ok(c.press('flag',true));time(c,2);
 assert.equal(c.state.weapon,'');assert.equal(c.state.step,3);
});
test('combos não misturam armas enquanto animação em andamento',()=>{
 const c=combo.create();c.press('hammer',true);assert.equal(c.press('flag',true),false);
});
test('sprites pertencem somente a assets/, e código está fora do diretório de imagens',()=>{
 for(const paths of Object.values(assets.sprites))for(const p of paths){ok(p.startsWith('assets/sprites/'));ok(!p.startsWith('js/'))}
});
console.log('\nPASSARAM',tests,'TESTES');
