const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const source=fs.readFileSync(path.join(__dirname,'../js/about.js'),'utf8');

test('Abrir e fechar Sobre/Creditos nao altera partida ou pausa',()=>{
 class El {
  constructor(id='') {this.id=id;this.hidden=false;this.events={};this.attrs={};this.isConnected=true;this.active=false;
   this.classList={store:new Set(),add:(c)=>this.classList.store.add(c),remove:(c)=>this.classList.store.delete(c),contains:(c)=>this.classList.store.has(c)}; }
  addEventListener(name,cb){this.events[name]=cb;}
  click(){this.events.click?.({currentTarget:this,target:this});}
  focus(){this.document.activeElement=this;}
  closest(selector){return this.id==='start'?'button':null;}
  querySelector(){return this.card;}
  querySelectorAll(){return [close,dismiss];}
  getClientRects(){return [1];}
 }
 const dialog=new El('aboutOverlay'),card=new El('card'),close=new El('aboutClose'),dismiss=new El('aboutDismiss'),start=new El('aboutFromStart'),pause=new El('aboutFromPause');
 dialog.card=card;dialog.classList.add('hidden');
 const all={aboutOverlay:dialog,aboutClose:close,aboutDismiss:dismiss,aboutFromStart:start,aboutFromPause:pause};
 const document={activeElement:null,addEventListener(name,cb){this.events[name]=cb;},events:{},getElementById:id=>all[id]||null};
 for(const e of Object.values(all))e.document=document;
 const game={score:12,paused:true};
 vm.runInNewContext(source,{document,HTMLElement:El});
 start.click();assert.equal(dialog.classList.contains('hidden'),false);assert.equal(document.activeElement,close);
 dismiss.click();assert.equal(dialog.classList.contains('hidden'),true);assert.equal(document.activeElement,start);
 pause.click();assert.equal(dialog.classList.contains('hidden'),false);
 document.events.keydown({key:'Escape',preventDefault(){},stopPropagation(){}});
 assert.equal(dialog.classList.contains('hidden'),true);
 assert.deepEqual(game,{score:12,paused:true});
});
