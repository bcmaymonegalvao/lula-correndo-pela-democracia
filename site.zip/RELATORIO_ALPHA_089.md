# Relatório de atualização — Alpha 0.8.9

Fonte: `site (1).zip` (Alpha 0.8.8), sem reconstrução do jogo.

## Alterações

1. A barra e o botão do especial são ocultados antes do aparecimento de Tariflávio e após a sua derrota/fim da partida. O título do medidor é **ESPECIAL**. Mantido o carregamento de 1 carga a cada três NPCs invocados derrotados.
2. Velocidade efetiva de avanço na tela reduzida de aproximadamente 300–350 px/s para **125 px/s** nos sete NPCs e **148 px/s** na Tesourinha. Ataques inimigos têm aviso de 0,70 s, e o recuo após hit ficou mais visível.
3. Os três ataques usam exclusivamente os arquivos **05, 06, 07 e 08**. Foram excluídos os 12 quadros antigos da publicação, atualizados atlas/manifesto, duração e hitboxes para quatro quadros. Os efeitos de impacto de quatro quadros continuam como estavam.
4. Criado `js/special_fx.js` para compartilhar o desenho e a sequência de 13 impactos do especial entre o jogo e a prova. Criado `teste_especial.html` e incorporado em `animacoes.html`.
5. Atualizadas referências de versão no cache para `0.8.9`.

## Validações

- `9` arquivos JavaScript com sintaxe válida (`node --check`).
- `120` caminhos de imagens existentes, verificados com distinção entre maiúsculas e minúsculas.
- Rotas HTTP 200 para `index.html`, `animacoes.html`, `teste_especial.html` e arquivos essenciais.
- Teste Chromium em página montada em memória com **recursos reais embutidos**: início, HUD, visibilidade condicional do especial, sequência de três golpes, velocidades medidas (148 e 125 px/s), aparição do chefão, ativação e execução de **13 hits**, ocultação do HUD no fim e ausência de erros JS.
- Prévia visual executada no Chromium com arquivos reais embutidos: a animação mostrou o contador avançando e reiniciando sem erros.

**Limitação do ambiente:** o navegador Chromium bloqueia navegação direta para URLs locais e `file://` por política administrativa. Por isso, o jogo foi servido por HTTP e seus caminhos testados, e a validação funcional do navegador utilizou o HTML e os assets reais embutidos diretamente no documento em memória. O teste final na URL publicada no GitHub Pages ainda deve ser executado após o upload.
