# Maromba's Comunist — Jones Manoel

Jones continua sendo o **primeiro especial** da batalha contra Tariflávio; seu módulo e seus sprites não foram alterados.

- Barra deve estar em **3/3**; botão especial ou teclas **C/L** (V como alias).
- Executa Hadouken de Livros de História, 13 eventos de dano.
- Ao terminar, o **próximo** especial será a Diva Guerreira de Érika Hilton, mas apenas depois de a barra voltar a **3/3**.
- Após a Diva Guerreira, o ciclo retorna ao Jones.
- O jogo usa um só `requestAnimationFrame`, com estado do mundo congelado durante qualquer cinematográfica.
- Os recursos e teste original do Jones seguem em `assets/specials/jones/` e `teste_jones_hadouken.html`.
- Leia `README_ESPECIAIS.md` para a regra vigente.
