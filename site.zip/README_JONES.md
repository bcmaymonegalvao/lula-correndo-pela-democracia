# Jones Manoel — Hadouken de Livros de História

Integração experimental **não publicada** no jogo Lula – Correndo pela Democracia.

## Testes

Abra `teste_jones_hadouken.html` diretamente: laboratório offline autocontido com os sprites e o **mesmo código de módulo**. Há botões para reproduzir, pausar e restaurar HP.

## Controles no jogo

- Durante a luta contra Tariflávio e havendo cargas: **V** ou botão **📚 JONES**.
- Especial anterior **Maromba's Comunista**: **C/L** ou botão **💥 ESPECIAL**.
- Ambos consomem uma carga da mesma barra, mas não podem ocorrer simultaneamente.
- Hadouken só inicia se o chefe entrou completamente em cena e Lula não está executando golpe/cooldown.

## Arquitetura

- `js/specials/jones_hadouken.js`: máquina de estados e renderização, sem `requestAnimationFrame` próprio.
- `js/game.js`: integração, congelamento do mundo, gasto de carga e callback de dano.
- `assets/specials/jones/`: artes reais fornecidas, sem usar o boss e o cenário provisórios do laboratório.
- `docs/ESPECIAL_JONES_INTEGRACAO.md`: contrato de integração completo.
- `docs/referencias/Teste_Original_Hadouken_Jones_CutIn_13_Hits_Offline.html`: protótipo original fornecido como referência.

As demais funcionalidades da Alpha 0.9.4 foram mantidas.
